-- select * from CompanyProceduresMapping where categoryid = 24 and itemid = 187437 and itemcode = 'SME1168' and serviceid=11


--update CompanyProceduresMapping set itemname = 'SWAB GUAZE 5X5CMX2" 8PLY PLAIN STERILE' where id = 20559