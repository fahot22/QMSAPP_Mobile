

--select 

----a.billno,

--SUM(s
--(a.editprice * a.editquantity) -
--(a.discount * a.editquantity) -
--(a.DeductableAmount * a.editquantity) 
--)
--from aripbillitemdetail a
--inner join aripbill b on a.billno = b.billno
--inner join oldinpatient oip on b.ipid = oip.ipid --and oip.RegistrationNo not in (1829903, 1831288, 1828390)
--where b.categoryid in (91,24)
--and b.InvoiceDateTime >= '01-SEP-2021' and b.InvoiceDateTime < '01-OCT-2021'
--and b.HasCompanyLetter = 1
--and b.companyid not in (select companyid from ARADMIN.WSL_ExcludedCompany where deleted = 0)




----group by a.BillNo
----order by a.billno

--SELECT * FROM ArCompanyBillDetail
--where 


---- 1372369.84326192
---- 1710830.75326192
---- 28766.12000000
---- 
---- 1175137.67464287
----28766.12000000
---- 338460.91000000
---- 1175137.67464287


----select * from company where id in (17563,22540)


select SUM(TOTCLAIMGRSAMT) AS GROSS, SUM(TOTCLAIMNETAMT) AS NET  from WSLMIDTABLES_06012018..wsl_geninfo
where claimtype = 'O'
and CLAIMDATE >= '01-SEP-2021'




select 
	SUM(billamount)
from ArCompanyBillDetail where BillDateTime >= '01-SEP-2021'
and BillDateTime < '01-OCT-2021'
and categoryid IN (24, 91)
--and companyid not in (select companyid from ARADMIN.WSL_ExcludedCompany where deleted = 0)

select 
	SUM(billamount)
from ArCompanyBillDetail where BillDateTime >= '01-SEP-2021'
and BillDateTime < '01-OCT-2021'
and companyid in (select companyid from ARADMIN.WSL_ExcludedCompany where deleted = 0)


3,807,428.81

446,512.92


93,453.44

select * from company where id in (
select companyid from ARADMIN.WSL_ExcludedCompany where deleted = 0)