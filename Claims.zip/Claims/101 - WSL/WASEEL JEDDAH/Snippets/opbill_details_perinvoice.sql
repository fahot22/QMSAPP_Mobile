select * from arcompanybilldetail where authorityid = 5372276 and categoryid = 24
and itemid = 187437

select * from arcompanybilldetail where authorityid = 5372276 and categoryid = 24
and itemname in ('BANDAGE COTTON GAUZE ELASTIC WHITE 6CMX4M HARTMANN #3030116','
SWAB GUAZE 5X5CMX2" 8PLY PLAIN STERILE')


select * from MOHInv_CodeMappings where SFDA_Code = 'SMA1041'
select * from MOHInv_CodeMappings where SFDA_Code = 'SME1168'


--update  MOHInv_CodeMappings set deleted = 1 where id in (15489)