
delete from WSLMIDTABLES_06012018..wsl_claim_diagnosis where provclaimno in  
(
select PROVCLAIMNO from wsl_geninfo where CLAIMDATE >= '01-JUL-2021'
and PATFILENO in (1829903, 1831288, 1828390) AND Claimtype = 'I'
)  
  
delete from WSLMIDTABLES_06012018..wsl_claim_illness where provclaimno in  
(
select PROVCLAIMNO from wsl_geninfo where CLAIMDATE >= '01-JUL-2021'
and PATFILENO in (1829903, 1831288, 1828390) AND Claimtype = 'I'
)  
 
delete from WSLMIDTABLES_06012018..wsl_service_details where invoiceno in  
(select invoiceno from WSLMIDTABLES_06012018..wsl_invoices where provclaimno in  
(
select PROVCLAIMNO from wsl_geninfo where CLAIMDATE >= '01-JUL-2021'
and PATFILENO in (1829903, 1831288, 1828390) AND Claimtype = 'I'
)  	
)  
  
delete from WSLMIDTABLES_06012018..wsl_invoices where provclaimno in  
(
select PROVCLAIMNO from wsl_geninfo where CLAIMDATE >= '01-JUL-2021'
and PATFILENO in (1829903, 1831288, 1828390) AND Claimtype = 'I'
)  


delete from WSLMIDTABLES_06012018..wsl_lab_component where provclaimno in  
(
select PROVCLAIMNO from wsl_geninfo where CLAIMDATE >= '01-JUL-2021'
and PATFILENO in (1829903, 1831288, 1828390) AND Claimtype = 'I'
)  

delete from WSLMIDTABLES_06012018..wsl_claim_illness where provclaimno in  
(
select PROVCLAIMNO from wsl_geninfo where CLAIMDATE >= '01-JUL-2021'
and PATFILENO in (1829903, 1831288, 1828390) AND Claimtype = 'I'
)  



delete from WSLMIDTABLES_06012018..wsl_lab_result where provclaimno in  
(
select PROVCLAIMNO from wsl_geninfo where CLAIMDATE >= '01-JUL-2021'
and PATFILENO in (1829903, 1831288, 1828390) AND Claimtype = 'I'
)  


delete from WSLMIDTABLES_06012018..wsl_geninfo where provclaimno in  
(
select PROVCLAIMNO from wsl_geninfo where CLAIMDATE >= '01-JUL-2021'
and PATFILENO in (1829903, 1831288, 1828390) AND Claimtype = 'I'
)  




 

