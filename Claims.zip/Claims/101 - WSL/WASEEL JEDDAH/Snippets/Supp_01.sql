select SUM(TOTCLAIMNETAMT) from wsl_geninfo
where PAYERID = 'NCCI'
and CLAIMDATE >= '01-JUL-2021'
and CLAIMTYPE = 'I'

select SUBSTRING(PROVCLAIMNO, 8, LEN(PROVCLAIMNO)), TOTCLAIMNETAMT
from wsl_geninfo
where PAYERID = 'NCCI'
and CLAIMDATE >= '01-JUL-2021'
and CLAIMTYPE = 'I'



and PATFILENO in (1829903, 1831288, 1828390)


--select SUM(TOTCLAIMNETAMT) from wsl_geninfo
--where PAYERID = 'NCCI'
--and CLAIMDATE >= '01-JUL-2021'
--and CLAIMTYPE = 'O'




select * from wsl_service_details where INVOICENO in (
select INVOICENO from wsl_invoices where PROVCLAIMNO in (
select PROVCLAIMNO from wsl_geninfo where  PAYERID = 'NCCI'
and CLAIMDATE >= '01-JUL-2021')
) and servicecode = '2-1290-2016'


/*

update wsl_service_details 
set SERVICECODE = '2-1361-15'
where 
servicecode = '2-1290-2016'
and invoiceno in ('IPCR-57744118','IPCR-57744128','IPCR-57744192')

*/