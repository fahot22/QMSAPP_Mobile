select * from wsl_service_details where INVOICENO = 'INV1120205193670'
-- INV1120205173951

update a
set
	a.TOTSERVICEGRSAMT = b.BillAmount,a.UNITSERVICEPRICE = b.BillAmount/b.qty,
	a.QTY = b.qty,a.TOTSERVICEDISC = b.discount,
	a.TOTSERVICEPATSHARE = b.PaidAmount,a.TOTSERVICENETAMT = b.BillAmount - b.Discount -b.PaidAmount
from wsl_service_details a
left join
(
	select itemname, billamount, discount, paidamount, case when serviceid in (11) then ISSUEQTY else Quantity end as qty
		from his..ArCompanyBillDetail where AuthorityId = 5193670 and CategoryId = 91
	and BillDateTime >= '01-NOV-2020'
) b on a.SERVICEDESC = b.ITEMNAME
where a.INVOICENO = 'INV1120205193670'





--select itemname, billamount, paidamount, case when serviceid in (11) then ISSUEQTY else Quantity end as qty
--from his..ArCompanyBillDetail where AuthorityId = 5173951 and CategoryId = 91
--and BillDateTime >= '01-NOV-2020'
