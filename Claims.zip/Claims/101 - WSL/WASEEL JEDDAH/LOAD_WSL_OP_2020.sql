
/*
	-- IP
	
	EXEC [ARMS].[N_WSL_ClearClaim] 91, 0, '01-JAN-2022', 'NCCI-STAFF', 1, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 91, 0, '01-JAN-2022', 'NCCI-STAFF', 2, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 91, 0, '01-JAN-2022', 'NCCI-STAFF', 3, 'I'

	EXEC ARMS.N_WSL_Generate_IPClaims 91, 0 , '01-JAN-2022'

	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2022', 'NCCI', 1, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2022', 'NCCI', 2, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2022', 'NCCI', 3, 'I'

	EXEC ARMS.N_WSL_Generate_IPClaims 24, 0 , '01-JAN-2022'

	EXEC [ARMS].[N_WSL_Generate_Update_PayerID] 'NCCI-STAFF', 'NCCI', '01-JAN-2022'

	-- SBG

	EXEC [ARMS].[N_WSL_ClearClaim] 98, 0, '01-JAN-2022', 'NCCI', 1, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 98, 0, '01-JAN-2022', 'NCCI', 2, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 98, 0, '01-JAN-2022', 'NCCI', 3, 'I'

	EXEC ARMS.N_WSL_Generate_IPClaims 98, 0 , '01-JAN-2022'

	EXEC [ARMS].[N_WSL_Generate_Update_PayerID] 'NCCI-SBG', 'NCCI', '01-JAN-2022'

*/

/*
	-- OP

	EXEC [ARMS].[N_WSL_ClearClaim] 91, 0, '01-JAN-2022', 'NCCI', 1, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 91, 0, '01-JAN-2022', 'NCCI', 2, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 91, 0, '01-JAN-2022', 'NCCI', 3, 'O'

	EXEC [ARMS].[N_WSL_Generate_OPClaims] 91, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Invoice] 91, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details] 91, 0, '01-JAN-2022'

	
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Diagnosis] 91, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory] 91, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory_Component] 91, 0, '01-JAN-2022'

	-- NCCI

	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2022', 'NCCI', 1, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2022', 'NCCI', 2, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2022', 'NCCI', 3, 'O'

	EXEC [ARMS].[N_WSL_Generate_OPClaims] 24, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Invoice] 24, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details] 24, 0, '01-JAN-2022'

	EXEC [ARMS].[N_WSL_Generate_OPClaims_Diagnosis] 24, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory] 24, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory_Component] 24, 0, '01-JAN-2022'


	-- NCCI - SBG 98

	-- NCCI

	EXEC [ARMS].[N_WSL_ClearClaim] 98, 0, '01-JAN-2022', 'NCCI', 1, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 98, 0, '01-JAN-2022', 'NCCI', 2, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 98, 0, '01-JAN-2022', 'NCCI', 3, 'O'

	EXEC [ARMS].[N_WSL_Generate_OPClaims] 98, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Invoice] 98, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details] 98, 0, '01-JAN-2022'

	EXEC [ARMS].[N_WSL_Generate_OPClaims_Diagnosis] 98, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory] 98, 0, '01-JAN-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory_Component] 98, 0, '01-JAN-2022'

	EXEC [ARMS].[N_WSL_Generate_Update_PayerID] 'NCCI-SBG', 'NCCI', '01-JAN-2022'

*/


/*
	JEDDAH

	NCCI 24
	NCCI STAFF
	91

	-- EXEC [ARMS].[N_WSL_Generate_OPClaims_Details_IT] 91, 0, '01-JAN-2022', 5306828
	-- EXEC [ARMS].[N_WSL_Generate_OPClaims_Details_Manual] 91, 0, '01-JAN-2022'



	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details_IT] 24, 0, '01-JAN-2022'


*/




