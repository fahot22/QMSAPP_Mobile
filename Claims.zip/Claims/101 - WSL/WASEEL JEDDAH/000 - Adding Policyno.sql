DECLARE 
	@FDate DATETIME = '01-SEP-2021',
	@TDate DATETIME = '01-OCT-2021' 


/*
select distinct authorityid, CO.PolicyNo AS PolicyNo
INTO #TMP_POLICYNO
from arcompanybilldetail A
left join dbo.company CO ON A.CompanyId = Co.Id
where A.BillDateTime >= @FDate and A.BillDateTime < @TDate 
AND A.CategoryId IN (24, 91)

-- SELECT * FROM  #TMP_POLICYNO


update A
set a.POLICYNO = B.PolicyNo
from WSLMIDTABLES_06012018..wsl_geninfo A
INNER JOIN (
 SELECT authorityid, PolicyNo FROM #TMP_POLICYNO
) B ON SUBSTRING(A.PROVCLAIMNO,9, LEN(A.PROVCLAIMNO)) = B.authorityid
where CLAIMDATE >= @FDate
and claimtype = 'O' AND A.POLICYNO = ''




*/

select distinct SlNo, CO.PolicyNo AS PolicyNo
INTO #TMP_POLICYNO
from ARIPBILL A
left join dbo.company CO ON A.CompanyId = Co.Id
where A.InvoiceDateTime >= @FDate and A.InvoiceDateTime < @TDate 
AND A.CategoryId IN (24, 91)


--update A
--set a.POLICYNO = B.PolicyNo
--from WSLMIDTABLES_06012018..wsl_geninfo A
--INNER JOIN (
-- SELECT authorityid, PolicyNo FROM #TMP_POLICYNO
--) B ON SUBSTRING(A.PROVCLAIMNO,9, LEN(A.PROVCLAIMNO)) = B.authorityid
--where CLAIMDATE >= @FDate
--and claimtype = 'I' AND A.POLICYNO = ''




DROP TABLE #TMP_POLICYNO