--select * from wsl_invoices where INVOICENO = 'INV1120205173951'

--select *
--from wsl_service_details where INVOICENO = 'INV1120205173951'
select * from wsl_geninfo

--select
--SUM(TOTSERVICEGRSAMT) GROSS, SUM(TOTSERVICEDISC) DISC, SUM(TOTSERVICEPATSHARE) AS DED,
--SUM(TOTSERVICENETAMT)
--from wsl_service_details where INVOICENO = 'INV1120205173951'



--update wsl_invoices 
--set TOTINVGRSAMT = 988.88,
--	TOTINVDISC = 49.45,
--	TOTINVPATSHARE = 100.00,
--	TOTINVNETAMT = 839.43
	
--where INVOICENO = 'INV1120205173951'


--UPDATE A 
--	TOTINVGRSAMT = SUM(TOTSERVICEGRSAMT),

--FROM wsl_invoices A
--INNER JOIN wsl_service_details B ON A.INVOICENO = B.INVOICENO

--WHERE PROVCLAIMNO IN (
--	SELECT PROVCLAIMNO
--	FROM WSLMIDTABLES_06012018..wsl_geninfo 
--	WHERE CLAIMTYPE = 'O'
--	AND CLAIMDATE >= '01-NOV-2020' 
--)
