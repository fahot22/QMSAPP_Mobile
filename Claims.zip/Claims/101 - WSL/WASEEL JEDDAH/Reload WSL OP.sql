delete from wsl_claim_diagnosis where provclaimno in  
(select provclaimno from wsl_geninfo where claimdate >= '01-AUG-2020' and claimdate < '01-SEP-2020' and payerid = 'NCCI')  
  
delete from wsl_claim_illness where provclaimno in  
(select provclaimno from wsl_geninfo where claimdate >= '01-AUG-2020' and claimdate < '01-SEP-2020' and payerid = 'NCCI')   
  
delete from wsl_service_details where invoiceno in  
(select invoiceno from wsl_invoices where provclaimno in  
(select provclaimno from wsl_geninfo where claimdate >= '01-AUG-2020' and claimdate < '01-SEP-2020' and payerid = 'NCCI')  )  
  
delete from wsl_invoices where provclaimno in  
(select provclaimno from wsl_geninfo where claimdate >= '01-AUG-2020' and claimdate < '01-SEP-2020' and payerid = 'NCCI')   
  
delete from wsl_lab_result where provclaimno in  
(select provclaimno from wsl_geninfo where claimdate >= '01-AUG-2020' and claimdate < '01-SEP-2020' and payerid = 'NCCI')  
  
delete from wsl_lab_component where provclaimno in  
(select provclaimno from wsl_geninfo where claimdate >= '01-AUG-2020' and claimdate < '01-SEP-2020' and payerid = 'NCCI')  
  
delete from wsl_geninfo where provclaimno in  
(select provclaimno from wsl_geninfo where claimdate >= '01-AUG-2020' and claimdate < '01-SEP-2020' and payerid = 'NCCI')   