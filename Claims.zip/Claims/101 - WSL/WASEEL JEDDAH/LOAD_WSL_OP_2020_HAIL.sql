
/*
	-- IP

	EXEC [ARMS].[N_WSL_ClearClaim] 85, 36447, '01-JAN-2021', 'NCCI', 1, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 85, 36447, '01-JAN-2021', 'NCCI', 2, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 85, 36447, '01-JAN-2021', 'NCCI', 3, 'I'

	EXEC ARMS.N_WSL_Generate_IPClaims 85, 36447, '01-JAN-2021'


	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2021', 'NCCI', 1, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2021', 'NCCI', 2, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2021', 'NCCI', 3, 'I'

	EXEC ARMS.N_WSL_Generate_IPClaims 24, 0 , '01-JAN-2021'

*/

/*
	-- OP
	-- STAFF

	EXEC [ARMS].[N_WSL_ClearClaim] 85, 36447, '01-JAN-2021', 'NCCI-STAFF', 1, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 85, 36447, '01-JAN-2021', 'NCCI-STAFF', 2, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 85, 36447, '01-JAN-2021', 'NCCI-STAFF', 3, 'O'

	EXEC [ARMS].[N_WSL_Generate_OPClaims] 85, 36447, '01-JAN-2021'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Invoice] 85, 36447, '01-JAN-2021'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details] 85, 36447, '01-JAN-2021'

	EXEC [ARMS].[N_WSL_Generate_OPClaims_Diagnosis] 85, 36447, '01-JAN-2021'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory] 85, 36447, '01-JAN-2021'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory_Component] 85, 36447, '01-JAN-2021'


	-- STANDARD

	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2021', 'NCCI', 1, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2021', 'NCCI', 2, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-JAN-2021', 'NCCI', 3, 'O'

	EXEC [ARMS].[N_WSL_Generate_OPClaims] 24, 0, '01-JAN-2021'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Invoice] 24, 0, '01-JAN-2021'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details] 24, 0, '01-JAN-2021'

	EXEC [ARMS].[N_WSL_Generate_OPClaims_Diagnosis] 24, 0, '01-JAN-2021'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory] 24, 0, '01-JAN-2021'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory_Component] 24, 0, '01-JAN-2021'

	EXEC [ARMS].[N_WSL_Generate_Update_PayerID] 'NCCI-STAFF', 'NCCI', '01-JAN-2021'

*/


/*

	HAIL

	NCCI 24
	NCCI STAFF 394Y - 85 - 36447
	TAWUSTAFF

	select * from company where code = '394Y'

	select * from category where id = 85

*/




