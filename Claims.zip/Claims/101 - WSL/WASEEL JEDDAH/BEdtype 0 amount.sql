--select distinct servicecode, servicedescription from ARADMIN.TMP_WSL_BEDTYPE_MAPPING


--DELETE FROM WSLMIDTABLES_06012018..wsl_service_details WHERE INVOICENO IN (
--select * from WSLMIDTABLES_06012018..wsl_service_details where invoice 
	select * FROM WSLMIDTABLES_06012018..wsl_service_details 
	where invoiceno in (
	select INVOICENO FROM WSLMIDTABLES_06012018..wsl_invoices
	WHERE provclaimno IN ( 

	SELECT provclaimno FROM 
	WSLMIDTABLES_06012018..wsl_geninfo 
	WHERE CLAIMTYPE = 'I'
	AND CLAIMDATE >= '01-SEP-2020'
	)
	)
	--and servicecode = ''
	and UNITSERVICEPRICE = 0

--)

select * from WSLMIDTABLES_06012018..wsl_service_details where invoiceno = 'IPCR-53675787' and servicecode = ''
select * from WSLMIDTABLES_06012018..wsl_service_details where invoiceno = 'IPCR-53675788' and servicecode = ''
select * from WSLMIDTABLES_06012018..wsl_service_details where invoiceno = 'IPCR-53676128' and servicecode = ''
select * from WSLMIDTABLES_06012018..wsl_service_details where invoiceno = 'IPCR-53676343' and servicecode = ''
select * from WSLMIDTABLES_06012018..wsl_service_details where invoiceno = 'IPCR-53866640' and servicecode = ''


--UPDATE WSLMIDTABLES_06012018..wsl_service_details SET SERVICECODE = 'FMADM-9902' where invoiceno = 'IPCR-53675787' and servicecode = ''
--UPDATE WSLMIDTABLES_06012018..wsl_service_details SET SERVICECODE = 'FMADM-9902' where invoiceno = 'IPCR-53675788' and servicecode = ''
--UPDATE WSLMIDTABLES_06012018..wsl_service_details SET SERVICECODE = 'FMADM-9915' where invoiceno = 'IPCR-53676128' and servicecode = ''
--UPDATE WSLMIDTABLES_06012018..wsl_service_details SET SERVICECODE = 'FMADM-9902' where invoiceno = 'IPCR-53676343' and servicecode = ''
--UPDATE WSLMIDTABLES_06012018..wsl_service_details SET SERVICECODE = 'FMADM-9910' where invoiceno = 'IPCR-53866640' and servicecode = ''