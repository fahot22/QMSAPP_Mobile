CREATE TABLE [wslmidtables].[dbo].[wsl_claim_attachment](
	[PROVCLAIMNO] [varchar](16) NOT NULL,
	[FILENAME] [nvarchar](50) NOT NULL,
	[FILECONTENT] [varbinary](max) NOT NULL
) ON [PRIMARY]

GO


ALTER TABLE [wslmidtables].[dbo].[wsl_claim_attachment]  WITH CHECK ADD  CONSTRAINT [FK_GENINFO_ATTACHMENT] FOREIGN KEY([PROVCLAIMNO])
REFERENCES [wslmidtables].[dbo].[wsl_geninfo] ([PROVCLAIMNO])
GO

ALTER TABLE [wslmidtables].[dbo].[wsl_claim_attachment] CHECK CONSTRAINT [FK_GENINFO_ATTACHMENT]
GO
