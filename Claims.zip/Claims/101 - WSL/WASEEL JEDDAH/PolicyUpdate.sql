--select * from wsl_geninfo where 
--CLAIMDATE >= '01-AUG-2021'
--and claimtype = 'O' and POLICYNO = ''


select distinct companyid, AuthorityId, b.policyno
INTO #TMPCOMP_POL
from his..arcompanybilldetail A 
INNER JOIN his..Company B ON A.CompanyId = B.Id
where 
A.CategoryId in (91,24) and A.BillDateTime >= '01-AUG-2021' and A.BillDateTime < '01-SEP-2021'
AND
A.authorityid in (
select substring(provclaimno, 9, LEN(PROVCLAIMNO)) AS AuthoCode
from wsl_geninfo where POLICYNO = ''
and CLAIMDATE >= '01-AUG-2021'
and claimtype = 'O')

update a
set policyno = B.PolicyNo
from wsl_geninfo A
INNER JOIN #TMPCOMP_POL B ON SUBSTRING(A.PROVCLAIMNO,9, LEN(A.PROVCLAIMNO)) = B.authorityid
where A.POLICYNO = ''
and A.CLAIMDATE >= '01-AUG-2021'
and A.claimtype = 'O'





DROP TABLE #TMPCOMP_POL