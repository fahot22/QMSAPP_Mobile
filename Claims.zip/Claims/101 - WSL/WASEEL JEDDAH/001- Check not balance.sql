

select PROVCLAIMNO into #tmp_gen from wsl_geninfo where CLAIMTYPE = 'O' and CLAIMDATE >='01-MAR-2021'


select * from wsl_geninfo where PROVCLAIMNO in (select provclaimno from #tmp_gen) AND
TOTCLAIMDISC = TOTCLAIMGRSAMT


select * from wsl_invoices where PROVCLAIMNO in (select provclaimno from #tmp_gen)
and TOTINVGRSAMT = TOTINVDISC

select * from wsl_service_details where invoiceno in (
select INVOICENO from wsl_invoices where PROVCLAIMNO in (select provclaimno from #tmp_gen)
and TOTINVGRSAMT = TOTINVDISC
)

drop table #tmp_gen