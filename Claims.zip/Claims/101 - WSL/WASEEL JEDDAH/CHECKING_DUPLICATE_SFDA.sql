select * from MOHInv_CodeMappings 
where 
SFDA_Code = 'MDMA19080476'
--SGH_Code = 'MDMA19080476'

select * from MOHInv_CodeMappings 
where 
SGH_Code = 'P01ATROP2J'


select sgh_code from MOHInv_CodeMappings
where deleted = 0
group by sgh_code
having count(*) > 1


--delete from MOHInv_CodeMappings where id = 8216


select * from his..ARIPBillItemDetail where SerialNo = 54447641

IPCR-54447641
select * from his..ARIPBillItemDetail where billno = 354409 and itemid = 177143