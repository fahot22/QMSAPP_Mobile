	SELECT DISTINCT ItemId, ServiceId, ItemCode, ItemName, CategoryID

	FROM HIS..CompanyProceduresMapping
	WHERE IPOP = 2 and CategoryId = 91
	and itemid = 13973






	select serviceid, itemid from HIS..CompanyProceduresMapping
	where  IPOP = 1 and CategoryId = 24
	group by serviceid, itemid
	having count(*) > 1


	 SELECT * FROM HIS..CompanyProceduresMapping 
	 WHERE IPOP = 1 and CategoryId = 24
	 and itemid = 187519 and serviceid = 1

	 delete from CompanyProceduresMapping where id = 20901



187397
187401
187402
187480
187519