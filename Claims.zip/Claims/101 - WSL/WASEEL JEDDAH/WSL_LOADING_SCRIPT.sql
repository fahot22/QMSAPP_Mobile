USE HIS
GO
/****** Object:  StoredProcedure ARMS.N_WSL_Generate_IPClaims    Script Date: 5/15/2020 1:08:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROC ARMS.N_WSL_Generate_IPClaims
	@CategoryId INT,
	@CompanyId INT,
	@FDate DATETIME
AS
BEGIN
	SET NOCOUNT ON;


	
	SET XACT_ABORT ON;
	BEGIN TRY
		BEGIN TRAN

			DECLARE @ProviderId VARCHAR(32) = 'SGHJ',
					@PayerId VARCHAR(32) = 'NCCI'

			SELECT DISTINCT ItemId, ServiceId, ItemCode, ItemName, CategoryID
			INTO #TMP_COMPANYMAP
			FROM HIS..CompanyProceduresMapping
			WHERE IPOP = 1 and CategoryId = @CategoryId

			-- CLEAR LAST BATCH
	
			SELECT 
				A.ServiceID, A.ItemID, A.ItemCode, A.ItemName,	A.EditOrderDateTime,
				B.CategoryId, B.IPID, B.InvoiceDateTime, A.SerialNo,
				@ProviderId														AS Provider, 
				@PayerId														AS PayerID, 
				'N/A'															AS TPAID,
				RIGHT('00' + 
				CONVERT(VARCHAR(2), DATEPART(MONTH, @FDate)), 2) + 
				CONVERT(VARCHAR(256), DATEPART(YEAR,@FDate)) + '/' +  
				CONVERT(VARCHAR(256), B.BillNo)									AS ClaimRefNo,

				B.SlNo															AS InvoiceNo,

				SUBSTRING(ISNULL(CF.MedicalIdNumber, '0'),1,15)					AS MemID,
				SUBSTRING(CO.PolicyNo,1,20)										AS PolicyNo,
				''																AS PlanType,
				SUBSTRING(OIP.TITLE + ' ' + 
				OIP.FIRSTNAME + ' ' + 
				ISNULL(OIP.MIDDLENAME,'') + ' ' + 
				ISNULL(OIP.LASTNAME,''), 1, 100)								AS MemName,
				SUBSTRING(OIP.FIRSTNAME,1,30)									AS FirstName,
				SUBSTRING(ISNULL(OIP.MIDDLENAME,''),1,30)						AS MiddleName,
				SUBSTRING(ISNULL(OIP.LASTNAME,''),1,30)							AS LastName,
				OIP.RegistrationNo												AS PatFileNo,
				''																AS AccountCode,
				PT.DateOfBirth													AS DateOfBirth,
				OIP.Age															AS Age,
				SUBSTRING(AT.Name,1,20)											AS AgeType,
				SUBSTRING(SX.Name,1,1)											AS Gender,
				SUBSTRING(NT.Name,1,120)										AS Nationality,
				OIP.DoctorID													AS DoctorId,
				SUBSTRING(DE.Name,1,60)											AS DoctorName,
				DE.DeptCode														AS DeptCode,
				''																AS VisitType,
				CONVERT(DATETIME, 
				CONVERT(VARCHAR, B.InvoiceDateTime, 104), 104)					AS ClaimDate,

				'I'																AS ClaimType,
				B.BillNo														AS MainClaimRefNo,
				''																AS EligRefNo,
				''																AS AppRefNo,										
				UPPER(REPLACE(
				CONVERT(VARCHAR(50),OIP.AdmitDateTime , 106),' ','-'))			AS AdmissionDate,
				LTRIM(RIGHT(CONVERT(CHAR(20), OIP.AdmitDateTime, 22), 11))		AS AdmissionTime,
				UPPER(REPLACE(
				CONVERT(VARCHAR(50),OIP.DischargeDateTime , 106),' ','-'))		AS DischargeDate,
				LTRIM(RIGHT(CONVERT(CHAR(20), OIP.DischargeDateTime, 22), 11))	AS DischargeTime,
				DATEDIFF(d, OIP.AdmitDateTime, OIP.DischargeDateTime)			AS LengthOfStay,
				SUBSTRING((
						SELECT top 1 B.Name 
						FROM bedtransfers A 
							LEFT JOIN dbo.Bed B 
							ON A.BedId = B.id
						WHERE A.IPID = B.IPID
						ORDER BY ToDateTime
					),1,15)														AS RoomNumber,
					
					SUBSTRING ((
						SELECT top 1 B.Name 
						FROM bedtransfers A 
							LEFT JOIN dbo.Bed B 
							ON A.BedId = B.id
						WHERE A.IPID = B.IPID
						ORDER BY ToDateTime
					),1,10)															AS BedNumber,

			NULL AS SignificantSign, NULL AS OtherCond, NULL AS DurationOfIllness,
			NULL AS UnitOfDuration, 0 AS Temperature, NULL AS BloodPressure,
			0 AS Pulse, NULL AS RespiratoryRate, 0 AS Weigh,
			NULL AS LastMenstruationPeriod,  '' AS RadioReport, '' AS ComReport,
			CO.Code AS CoID,  '' AS Reference, '' AS OtherReference,
			A.EditQuantity AS EditQuantity,
			A.EditPrice * A.EditQuantity AS Gross,
			A.Discount * A.EditQuantity AS Discount,
			A.DeductableAmount * A.EditQuantity AS Deductible,
			(A.EditPrice * A.EditQuantity) - 
			(A.Discount * A.EditQuantity) -
			(A.DeductableAmount * A.EditQuantity) AS NetAmount,

			ISNULL(IPT.TaxPercentage,0)					AS VatPercentage,
			ISNULL(IPT.PatientTaxAmount, 0)				AS PatientVatAmount,
			ISNULL(IPT.CompanyTaxAmount, 0)				AS CompanyVatAmount
	
			INTO #TMP_IPBILL
			FROM dbo.ARIPBillItemDetail A
				INNER JOIN dbo.ARIPBill B ON A.BillNo = B.BillNo
				INNER JOIN dbo.OldInpatient OIP ON B.IPID = OIP.IPID
				INNER JOIN dbo.Company CO ON B.CompanyID = CO.Id
				INNER JOIN dbo.Patient PT ON OIP.RegistrationNo = PT.Registrationno
				LEFT JOIN dbo.AgeType AT ON OIP.AgeType = AT.Id
				LEFT JOIN dbo.Sex SX ON OIP.Sex = SX.Id
				LEFT JOIN dbo.Nationality AS NT ON OIP.Nationality = NT.ID
				LEFT JOIN dbo.Employee DR ON OIP.DoctorID = DR.Id
				LEFT JOIN dbo.Department DE ON DR.DepartmentID = DE.ID
				LEFT JOIN 
				(
					SELECT DISTINCT LTRIM(RTRIM(MedIdNumber)) AS MedicalIdNumber, CategoryId, CompanyId, GradeId, RegNo
					FROM ClaimFileId (NOLOCK)
					WHERE CategoryId = @CategoryId
				) CF ON CF.CategoryId = B.CategoryId AND CF.CompanyId = B.CompanyId AND CF.GradeId = B.GradeId AND CF.RegNo = OIP.RegistrationNo
				LEFT JOIN dbo.ARIPTaxDetails IPT ON B.BillNo = IPT.IPBillId AND A.SerialNo = IPT.SerialNo
					AND A.ServiceId = IPT.ServiceId AND A.DepartmentId = IPT.DepartmentId AND A.ItemId = IPT.ItemId
					AND A.EditOrderDateTime = IPT.DateTIme
			WHERE 
				B.InvoiceDateTime >= @FDate AND B.InvoiceDateTime < DATEADD(M,1,@FDate)
				AND B.CategoryID = @CategoryId AND (@CompanyId = 0 OR B.CompanyID = @CompanyId)
				AND B.HasCompanyLetter > 0
				AND B.CompanyId NOT IN (SELECT CompanyId FROM HIS.ARADMIN.WSL_ExcludedCompany WHERE Deleted = 0)
--
			----------------------------------------------------------------------------------
			-- INSERT HEADER INFORMATION
			----------------------------------------------------------------------------------
			PRINT 'BEFORE HEADER'
			INSERT INTO WSLMIDTABLES_06012018..wsl_geninfo
			(
				PROVIDERID			,PAYERID		,TPAID				,PROVCLAIMNO		,MEMBERID
				,POLICYNO			,PLANTYPE		,FULLNAME			,FIRSTNAME			,MIDDLENAME
				,LASTNAME			,PATFILENO		,ACCCODE			,MEMBERDOB			,MEMBERAGE
				,UNITAGE			,GENDER			,NATIONALITY		,PHYID				,PHYNAME
				,PHYCATEGORY		,DEPTCODE		,VISITTYPE			,CLAIMDATE			,CLAIMTYPE
				,MAINCLAIMREFNO		,ELIGREFNO		,APPREFNO			,ADMISSIONDATE		,ADMISSIONTIME
				,DISCHARGEDATE		,DISCHARGETIME	,LENGTHOFSTAY		,UNITOFSTAY			,ROOMNO
				,BEDNO				,MAINSYMPTOM	,SIGNIFICANTSIGN	,OTHERCOND			,DURATIONOFILLNESS
				,UNITOFDURATION		,TEMPERATURE	,BLOODPRESSURE		,PULSE				,RESPIRATORYRATE
				,WEIGH				,LASTMENSTRUATIONPERIOD				,TOTCLAIMGRSAMT		,TOTCLAIMDISC
				,TOTCLAIMPATSHARE	,TOTCLAIMNETAMT	,RADIOREPORT		,COMMREPORT			,EXTRACTION_DATE
				,TOTCLAIMNETVATAMOUNT ,TOTCLAIMPATSHAREVATAMOUNT
			)
			SELECT 
				A.Provider			,A.PayerID		,A.TPAID			,A.ClaimRefNo		,SUBSTRING(A.MemID,1,30)			
				, A.PolicyNo		,A.PlanType		,A.MemName			,A.FirstName		,A.MiddleName	
				, A.LastName		,A.PatFileNo	,''					,A.DateOfBirth		,A.Age
				, A.AgeType			,A.Gender		,A.Nationality		,A.DoctorId			,A.Doctorname 
				,'CONSULTANT'		,A.DeptCode		,A.VisitType		,A.ClaimDate		,A.ClaimType
				,A.MainClaimRefNo	,A.EligRefNo	,A.AppRefNo			,A.AdmissionDate	,A.AdmissionTime
				,A.DischargeDate	,A.DischargeTime ,A.LengthOfStay	,A.UnitOfDuration	,A.RoomNumber 
				,A.BedNumber		,''				,A.SignificantSign  ,A.OtherCond		,A.DurationOfIllness 
				,A.UnitOfDuration	,A.Temperature  ,A.BloodPressure	,A.Pulse			,A.RespiratoryRate 
				,A.Weigh,A.LastMenstruationPeriod	,SUM(A.Gross)		,SUM(A.Discount)	
				,SUM(A.Deductible)  ,SUM(A.NetAmount) ,A.RadioReport	,A.ComReport		,GETDATE()			
				,SUM(A.CompanyVatAmount)  ,SUM(A.PatientVatAmount) 
			FROM #TMP_IPBILL A
			GROUP BY
				A.Provider, A.PayerID, A.TPAID, A.ClaimRefNo, A.MemID, A.PolicyNo	
				, A.PlanType, A.MemName, A.FirstName, A.MiddleName, A.LastName
				, A.PatFileNo , A.DateOfBirth ,A.Age ,A.AgeType ,A.Gender 
				,A.Nationality ,A.DoctorId,A.Doctorname ,A.DeptCode 
				,A.VisitType,A.ClaimDate,A.ClaimType ,A.MainClaimRefNo
				,A.EligRefNo,A.AppRefNo ,A.AdmissionDate 
				,A.AdmissionTime  ,A.DischargeDate  ,A.DischargeTime ,A.LengthOfStay 
				,A.UnitOfDuration ,A.RoomNumber ,A.BedNumber ,A.SignificantSign
				,A.OtherCond ,A.DurationOfIllness ,A.UnitOfDuration 
				,A.Temperature ,A.BloodPressure	,A.Pulse ,A.RespiratoryRate
				,A.Weigh, A.LastMenstruationPeriod, A.RadioReport, A.ComReport

			PRINT 'AFTER HEADER'
			----------------------------------------------------------------------------------
			-- INSERT INVOICES
			----------------------------------------------------------------------------------
			INSERT INTO WSLMIDTABLES_06012018..WSL_INVOICES
			(	
				INVOICENO,		PROVCLAIMNO,	INVOICEDATE,	INVOICEDEPT,		TOTINVGRSAMT,	
				TOTINVDISC,		TOTINVPATSHARE, TOTINVNETAMT,	TOTINVNETVATAMOUNT,	TOTINVPATSHAREVATAMOUNT 
			)

			SELECT
				'IPCR-' + CONVERT(VARCHAR(256), A.SerialNo) AS INVOICENO,
				B.PROVCLAIMNO,
				A.ClaimDate,
				A.DeptCode,
				SUM(A.Gross) AS TOTINVGRSAMT,
				SUM(A.Discount) AS TOTINVDISC,
				SUM(A.Deductible) AS TOTINVPATSHARE,
				SUM(A.NetAmount) AS TOTINVNETAMT,
				SUM(A.CompanyVatAmount) AS TOTINVNETVATAMOUNT,
				SUM(A.PatientVatAmount) AS TOTINVPATSHAREVATAMOUNT
			FROM #TMP_IPBILL A
			LEFT JOIN WSLMIDTABLES_06012018..wsl_geninfo B ON A.ClaimRefNo = B.PROVCLAIMNO
			GROUP BY A.SerialNo, B.PROVCLAIMNO, A.ClaimDate, A.DeptCode

			PRINT 'DONE INVOICE'
			----------------------------------------------------------------------------------
			-- INSERT SERVICE DETAILS
			----------------------------------------------------------------------------------
			INSERT INTO WSLMIDTABLES_06012018..WSL_SERVICE_DETAILS
			(
				INVOICENO,				SERVICECODE,		SERVICEDATE,			SERVICEDESC,		UNITSERVICEPRICE,
				UNITSERVICETYPE,		QTY,				TOOTHNO,				TOTSERVICEGRSAMT,	TOTSERVICEDISC,
				TOTSERVICEPATSHARE,		TOTSERVICENETAMT,	TOTSERVICENETVATRATE,
				TOTSERVICENETVATAMOUNT, TOTSERVICEPATSHAREVATRATE,					TOTSERVICEPATSHAREVATAMOUNT
			)  

			SELECT 
				'IPCR-' + CONVERT(VARCHAR(256), A.SerialNo) AS INVOICENO,
				SUBSTRING(
					CASE WHEN A.ServiceID IN (5, 37) THEN
						CASE WHEN LEN(LTRIM(RTRIM(ISNULL(SFDA.SFDA_Code,'')))) = 0 THEN A.ItemCode
						ELSE ISNULL(SFDA.SFDA_Code, A.ItemCode)
						END
					ELSE
						ISNULL(M.ItemCode, A.ItemCode)
					END, 1,20
				)
				AS SERVICECODE, 

				CONVERT(DATETIME,CONVERT(NVARCHAR,A.InvoiceDateTime,105),105)  AS SERVICEDATE,
				SUBSTRING(A.ItemName,1,80) AS SERVICEDESC, 
				SUM(A.Gross / A.EditQuantity) AS UNITSERVICEPRICE, 'N/A' AS UNITSERVICETYPE,
				SUM(A.EditQuantity) AS QTY, 
				'' AS TOOTHNO, 
				SUM(A.Gross) AS TOTSERVICEGRSAMT,
				SUM(A.Discount) AS TOTSERVICEDISC,
				SUM(A.Deductible) AS TOTSERVICEPATSHARE,
				SUM(A.NetAmount) AS TOTSERVICENETAMT,
				MIN(A.VatPercentage) AS TOTSERVICENETVATRATE,
				SUM(A.CompanyVatAmount) AS TOTSERVICENETVATRATE,
				MIN(A.VatPercentage) AS TOTSERVICEPATSHAREVATRATE,
				SUM(A.PatientVatAmount) AS TOTSERVICEPATSHAREVATAMOUNT
			FROM #TMP_IPBILL A
			LEFT JOIN WSLMIDTABLES_06012018..wsl_geninfo B ON A.ClaimRefNo = B.PROVCLAIMNO
			LEFT JOIN #TMP_COMPANYMAP M ON A.ItemId = M.ItemID AND A.CategoryID = M.CategoryID AND A.ServiceId = M.ServiceID
			LEFT JOIN HIS..MOHInv_CodeMappings SFDA ON A.ITEMCODE = SFDA.SGH_Code and SFDA.Deleted = 0

			GROUP BY A.ServiceID, A.itemCode, A.ItemName, 
			A.SerialNo, SFDA.SFDA_Code, M.ItemCode,
			M.ItemCode, A.InvoiceDateTime

			PRINT 'DONE SERVICE DETAILS'
			----------------------------------------------------------------------------------
			-- INSERT DIAGNOSIS
			----------------------------------------------------------------------------------
			INSERT INTO WSLMIDTABLES_06012018..wsl_claim_diagnosis
			(
				PROVCLAIMNO ,DIAGNOSISCODE  ,DIAGNOSISDESC
			)

			SELECT 
				B.PROVCLAIMNO, SUBSTRING(ICD.ICDCode,1, 50), SUBSTRING(ICD.ICDDescription,1, 200)
			FROM #TMP_IPBILL A
			LEFT JOIN WSLMIDTABLES_06012018..wsl_geninfo B ON A.ClaimRefNo = B.PROVCLAIMNO
			LEFT JOIN dbo.IPICDDetail ICD (NOLOCK) ON A.IPID = ICD.IPID
			GROUP BY B.PROVCLAIMNO, SUBSTRING(ICD.ICDCode,1, 50), SUBSTRING(ICD.ICDDescription,1, 200)

			PRINT 'DONE DIAGNOSIS'
			----------------------------------------------------------------------------------
			-- INSERT LAB RESULTS
			----------------------------------------------------------------------------------

			SELECT
				B.PROVCLAIMNO, 
				SUBSTRING(A.ItemCode, 1, 15) AS LABTESTCODE,
				--A.SerialNo AS SERIAL,
				ROW_NUMBER() OVER (Order by A.itemcode) AS SERIAL,
				MIN(CONVERT(DATETIME,CONVERT(NVARCHAR,TR.DateTime,105),105)) AS LABTESTDATE,
				SUBSTRING(A.itemname,1,255) AS LABDESC    
			INTO #TMP_LABRESULT
			FROM  #TMP_IPBILL A
				LEFT JOIN WSLMIDTABLES_06012018..wsl_geninfo B ON A.ClaimRefNo = B.PROVCLAIMNO
				LEFT JOIN dbo.TestRequisition TR ON A.IPID = TR.IPID
				INNER JOIN dbo.RequestedTest R ON TR.Id = R.OrderId AND R.TestDonedateTime IS NOT NULL
					AND A.ItemID = R.Serviceid
				LEFT JOIN dbo.TestParameter P ON R.ServiceId = P.TestId
				LEFT JOIN dbo.Parameter PR ON P.ParameterId = PR.Id

				INNER JOIN dbo.TestResult1 TR1 ON R.ServiceId = TR1.ServiceId AND P.ParameterId = TR1.ParameterId
					AND R.OrderId = TR1.OrderId AND LEN(LTRIM(RTRIM(TR1.Result))) > 0
					AND TR1.Result NOT IN ('--Select--')
			WHERE A.itemCode LIKE 'FMLAB%'

			GROUP BY B.PROVCLAIMNO, SUBSTRING(A.ItemCode, 1, 15),
			SUBSTRING(A.itemname,1,255),
			A.ItemCode --, CONVERT(DATETIME,CONVERT(NVARCHAR,TR.DateTime,105),105)
			--,A.SerialNo 

			SELECT * 
			--INTO ARADMIN.WSL_TMP_LABRESULT
			FROM #TMP_LABRESULT

			INSERT INTO WSLMIDTABLES_06012018..WSL_LAB_RESULT  
			(
				PROVCLAIMNO, LABTESTCODE, SERIAL,
				LABTESTDATE, LABDESC
			)
			SELECT 
				PROVCLAIMNO, LABTESTCODE, SERIAL,
				LABTESTDATE, LABDESC
			FROM #TMP_LABRESULT
			
			

			PRINT 'DONE LAB RESULT'
			----------------------------------------------------------------------------------
			-- INSERT LAB COMPONENT
			----------------------------------------------------------------------------------

			SELECT
				LC.PROVCLAIMNO, LC.LABTESTCODE, LR.SERIAL,
				LC.LABCOMPCODE, LC.LABCOMPDESC, LC.LABRESULT, 
				LC.LABRESULTUNIT,
				LC.LABRESULTCOMMENT,
				LC.LABTESTDATE
			INTO #TMP_LABCOMP
			FROM
			(
				SELECT
					B.PROVCLAIMNO AS PROVCLAIMNO, 
					SUBSTRING(A.ItemCode, 1, 15) AS LABTESTCODE,
					PR.ID AS LABCOMPCODE, 
					SUBSTRING(PR.Name,1,255) AS LABCOMPDESC,
					SUBSTRING(TR1.Result,1,15)  AS LABRESULT, 
					SUBSTRING(TR1.Units,1,15) AS LABRESULTUNIT,
					NULL AS LABRESULTCOMMENT,
					CONVERT(DATETIME,CONVERT(NVARCHAR,TR.DateTime,105),105) AS LABTESTDATE--,
					--A.SerialNo AS SERIAL
				FROM  #TMP_IPBILL A
				LEFT JOIN WSLMIDTABLES_06012018..wsl_geninfo B ON A.ClaimRefNo = B.PROVCLAIMNO
				LEFT JOIN dbo.TestRequisition TR ON A.IPID = TR.IPID
				INNER JOIN dbo.RequestedTest R ON TR.Id = R.OrderId AND R.TestDonedateTime IS NOT NULL
				LEFT JOIN dbo.TestParameter P ON R.ServiceId = P.TestId
				LEFT JOIN dbo.Parameter PR ON P.ParameterId = PR.Id

				INNER JOIN dbo.TestResult1 TR1 ON R.ServiceId = TR1.ServiceId AND P.ParameterId = TR1.ParameterId
					AND R.OrderId = TR1.OrderId AND LEN(LTRIM(RTRIM(TR1.Result))) > 0
					AND TR1.Result NOT IN ('--Select--')
				WHERE A.itemCode LIKE 'FMLAB%'

				GROUP BY 
					B.PROVCLAIMNO, SUBSTRING(A.ItemCode, 1, 15), PR.ID,
					SUBSTRING(PR.Name,1,255), SUBSTRING(TR1.Result,1,15),
					SUBSTRING(TR1.Units,1,15), CONVERT(DATETIME,CONVERT(NVARCHAR,TR.DateTime,105),105)--,
					--A.SerialNo
			) AS LC
			INNER JOIN WSLMIDTABLES_06012018..WSL_LAB_RESULT LR
			ON LC.ProvClaimNo = LR.ProvClaimNo and LC.LabTestCode = LR.LabTestCode 
			and LC.LABTESTDATE = LR.LABTESTDATE



			SELECT * 
			FROM #TMP_LABRESULT

			SELECT * 
			FROM #TMP_LABCOMP

			INSERT INTO WSLMIDTABLES_06012018..WSL_LAB_COMPONENT  
			(
				PROVCLAIMNO, LABTESTCODE, SERIAL,
				LABCOMPCODE, LABCOMPDESC, LABRESULT,
				LABRESULTUNIT,	LABRESULTCOMMENT
			)
			SELECT 
				LC.PROVCLAIMNO, LC.LABTESTCODE, LC.SERIAL,
				LC.LABCOMPCODE, LC.LABCOMPDESC, LC.LABRESULT, 
				LC.LABRESULTUNIT,
				LC.LABRESULTCOMMENT
			FROM #TMP_LABCOMP LC
			

			PRINT 'DONE LAB COMPONENT'

			DROP TABLE #TMP_IPBILL
			DROP TABLE #TMP_COMPANYMAP
			DROP TABLE #TMP_LABRESULT
			DROP TABLE #TMP_LABCOMP
	COMMIT TRAN
	END TRY
	BEGIN CATCH
		DECLARE @ErrMsg NVARCHAR(2048)
		SELECT @ErrMsg = 'Error No ' + CONVERT(VARCHAR(50), ERROR_NUMBER()) + ': ' + ERROR_MESSAGE()
		IF XACT_STATE() = - 1
			OR XACT_STATE() = 1
			ROLLBACK TRANSACTION;

		RAISERROR (@ErrMsg, 16, 1);
	END CATCH
	SET XACT_ABORT OFF;

END
/*

	EXEC ARMS.N_WSL_Generate_IPClaims 24, 0 , '01-APR-2020'

	SELECT * FROM ARIPBILL WHERE categoryId = 24 and hascompanyletter = 1 and invoicedatetime >= '01-APR-2020'

*/