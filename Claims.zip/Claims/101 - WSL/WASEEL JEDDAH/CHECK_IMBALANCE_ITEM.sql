DECLARE
	@CategoryId INT = 91,
	@CompanyId INT = 0,
	@FDate DATETIME = '01-OCT-2020',
	@SLNo INT = 54216433

	DECLARE @ProviderId VARCHAR(32) = 'SGHJ',
	@PayerId VARCHAR(32) = 'NCCI'

		IF(@CategoryId = 24)  BEGIN SET @PayerId = 'NCCI' END
		IF(@CategoryId = 91)  BEGIN SET @PayerId = 'NCCI-STAFF' END

		SELECT DISTINCT ItemId, ServiceId, ItemCode, ItemName, CategoryID, SGH_Code
		INTO #TMP_COMPANYMAP
		FROM HIS..CompanyProceduresMapping
		WHERE IPOP = 1 and CategoryId = @CategoryId

		SELECT DISTINCT
			SGH_Code, SFDA_Code
		INTO #TMP_SFDA
		FROM HIS..MOHInv_CodeMappings
		WHERE Deleted = 0
		
		-- CLEAR LAST BATCH
	
		SELECT 
			A.ServiceID, A.EditItemId, A.ItemCode, A.ItemName,	A.EditOrderDateTime,
			B.CategoryId, B.IPID, B.InvoiceDateTime, A.SerialNo,
			@ProviderId														AS Provider, 
			@PayerId														AS PayerID, 
			'N/A'															AS TPAID,
			'I'+ RIGHT('00' + 
			CONVERT(VARCHAR(2), DATEPART(MONTH, @FDate)), 2) + 
			CONVERT(VARCHAR(256), DATEPART(YEAR,@FDate)) +  
			CONVERT(VARCHAR(256), B.BillNo)									AS ClaimRefNo,

			B.SlNo															AS InvoiceNo,

			SUBSTRING(ISNULL(CF.MedicalIdNumber, '0'),1,15)					AS MemID,
			SUBSTRING(CO.PolicyNo,1,20)										AS PolicyNo,
			''																AS PlanType,
			SUBSTRING(OIP.TITLE + ' ' + 
			OIP.FIRSTNAME + ' ' + 
			ISNULL(OIP.MIDDLENAME,'') + ' ' + 
			ISNULL(OIP.LASTNAME,''), 1, 100)								AS MemName,
			SUBSTRING(OIP.FIRSTNAME,1,30)									AS FirstName,
			SUBSTRING(ISNULL(OIP.MIDDLENAME,''),1,30)						AS MiddleName,
			SUBSTRING(ISNULL(OIP.LASTNAME,''),1,30)							AS LastName,
			OIP.RegistrationNo												AS PatFileNo,
			''																AS AccountCode,
			PT.DateOfBirth													AS DateOfBirth,
			OIP.Age															AS Age,
			SUBSTRING(AT.Name,1,20)											AS AgeType,
			SUBSTRING(SX.Name,1,1)											AS Gender,
			SUBSTRING(NT.Name,1,120)										AS Nationality,
			OIP.DoctorID													AS DoctorId,
			SUBSTRING(DE.Name,1,60)											AS DoctorName,
			DE.DeptCode														AS DeptCode,
			''																AS VisitType,
			CONVERT(DATETIME, 
			CONVERT(VARCHAR, B.InvoiceDateTime, 104), 104)					AS ClaimDate,

			'I'																AS ClaimType,
			B.BillNo														AS MainClaimRefNo,
			''																AS EligRefNo,
			''																AS AppRefNo,										
			UPPER(REPLACE(
			CONVERT(VARCHAR(50),OIP.AdmitDateTime , 106),' ','-'))			AS AdmissionDate,
			LTRIM(RIGHT(CONVERT(CHAR(20), OIP.AdmitDateTime, 22), 11))		AS AdmissionTime,
			UPPER(REPLACE(
			CONVERT(VARCHAR(50),OIP.DischargeDateTime , 106),' ','-'))		AS DischargeDate,
			LTRIM(RIGHT(CONVERT(CHAR(20), OIP.DischargeDateTime, 22), 11))	AS DischargeTime,
			DATEDIFF(d, OIP.AdmitDateTime, OIP.DischargeDateTime)			AS LengthOfStay,
			SUBSTRING((
					SELECT top 1 B.Name 
					FROM bedtransfers A 
						LEFT JOIN dbo.Bed B 
						ON A.BedId = B.id
					WHERE A.IPID = B.IPID
					ORDER BY ToDateTime
				),1,15)														AS RoomNumber,
					
				SUBSTRING ((
					SELECT top 1 B.Name 
					FROM bedtransfers A 
						LEFT JOIN dbo.Bed B 
						ON A.BedId = B.id
					WHERE A.IPID = B.IPID
					ORDER BY ToDateTime
				),1,10)															AS BedNumber,

		NULL AS SignificantSign, NULL AS OtherCond, NULL AS DurationOfIllness,
		NULL AS UnitOfDuration, 0 AS Temperature, NULL AS BloodPressure,
		0 AS Pulse, NULL AS RespiratoryRate, 0 AS Weigh,
		NULL AS LastMenstruationPeriod,  '' AS RadioReport, '' AS ComReport,
		CO.Code AS CoID,  '' AS Reference, '' AS OtherReference,

		A.EditQuantity AS EditQuantity,
		A.EditPrice * A.EditQuantity AS Gross,
		A.Discount * A.EditQuantity AS Discount,
		A.DeductableAmount * A.EditQuantity AS Deductible,
		(A.EditPrice * A.EditQuantity) - 
		(A.Discount * A.EditQuantity) -
		(A.DeductableAmount * A.EditQuantity) AS NetAmount,

		ISNULL(IPT.TaxPercentage,0)					AS VatPercentage,
		ISNULL(IPT.PatientTaxAmount, 0)				AS PatientVatAmount,
		ISNULL(IPT.CompanyTaxAmount, 0)				AS CompanyVatAmount
	
		INTO #TMP_IPBILL
		FROM dbo.ARIPBillItemDetail A
			INNER JOIN dbo.ARIPBill B ON A.BillNo = B.BillNo
			INNER JOIN dbo.OldInpatient OIP ON B.IPID = OIP.IPID
			INNER JOIN dbo.Company CO ON B.CompanyID = CO.Id
			INNER JOIN dbo.Patient PT ON OIP.RegistrationNo = PT.Registrationno
			LEFT JOIN dbo.AgeType AT ON OIP.AgeType = AT.Id
			LEFT JOIN dbo.Sex SX ON OIP.Sex = SX.Id
			LEFT JOIN dbo.Nationality AS NT ON OIP.Nationality = NT.ID
			LEFT JOIN dbo.Employee DR ON OIP.DoctorID = DR.Id
			LEFT JOIN dbo.Department DE ON DR.DepartmentID = DE.ID
			LEFT JOIN 
			(
				SELECT DISTINCT LTRIM(RTRIM(MedIdNumber)) AS MedicalIdNumber, CategoryId, CompanyId, GradeId, RegNo
				FROM ClaimFileId (NOLOCK)
				WHERE CategoryId = @CategoryId
			) CF ON CF.CategoryId = B.CategoryId AND CF.CompanyId = B.CompanyId AND CF.GradeId = B.GradeId AND CF.RegNo = OIP.RegistrationNo
			LEFT JOIN dbo.ARIPTaxDetails IPT ON B.BillNo = IPT.IPBillId AND A.SerialNo = IPT.SerialNo
				AND A.ServiceId = IPT.ServiceId AND A.DepartmentId = IPT.DepartmentId AND A.EditItemId = IPT.ItemId
				AND A.EditOrderDateTime = IPT.DateTIme
		WHERE 
			B.InvoiceDateTime >= @FDate AND B.InvoiceDateTime < DATEADD(M,1,@FDate)
			AND B.CategoryID = @CategoryId AND (@CompanyId = 0 OR B.CompanyID = @CompanyId)
			AND B.HasCompanyLetter > 0
			AND B.CompanyId NOT IN (SELECT CompanyId FROM HIS.ARADMIN.WSL_ExcludedCompany WHERE Deleted = 0)
			AND A.EditPrice > 0
			AND A.SerialNo = @SLNo


		SELECT 
				A.Provider			,A.PayerID		,A.TPAID			,A.ClaimRefNo		,SUBSTRING(A.MemID,1,30)			
				, A.PolicyNo		,A.PlanType		,A.MemName			,A.FirstName		,A.MiddleName	
				, A.LastName		,A.PatFileNo	,''					,A.DateOfBirth		,A.Age
				, A.AgeType			,A.Gender		,A.Nationality		,A.DoctorId			,A.Doctorname 
				,'CONSULTANT'		,A.DeptCode		,A.VisitType		,A.ClaimDate		,A.ClaimType
				,A.MainClaimRefNo	,A.EligRefNo	,A.AppRefNo			,A.AdmissionDate	,A.AdmissionTime
				,A.DischargeDate	,A.DischargeTime ,A.LengthOfStay	,A.UnitOfDuration	,A.RoomNumber 
				,A.BedNumber		,''				,A.SignificantSign  ,A.OtherCond		,A.DurationOfIllness 
				,A.UnitOfDuration	,A.Temperature  ,A.BloodPressure	,A.Pulse			,A.RespiratoryRate 
				,A.Weigh,A.LastMenstruationPeriod	
				,CAST(SUM(A.Gross)	 AS NUMERIC(18,4)) 	
				,CAST(SUM(A.Discount)	 AS NUMERIC(18,4)) 
				,CAST(SUM(A.Deductible) AS NUMERIC(18,4))  
				,CAST(SUM(A.NetAmount)  AS NUMERIC(18,4)) 
				,A.RadioReport	,A.ComReport		,GETDATE()			
				,CAST(SUM(A.CompanyVatAmount)  AS NUMERIC(18,4))   
				,CAST(SUM(A.PatientVatAmount)   AS NUMERIC(18,4)) 
			FROM #TMP_IPBILL A
			GROUP BY
				A.Provider, A.PayerID, A.TPAID, A.ClaimRefNo, A.MemID, A.PolicyNo	
				, A.PlanType, A.MemName, A.FirstName, A.MiddleName, A.LastName
				, A.PatFileNo , A.DateOfBirth ,A.Age ,A.AgeType ,A.Gender 
				,A.Nationality ,A.DoctorId,A.Doctorname ,A.DeptCode 
				,A.VisitType,A.ClaimDate,A.ClaimType ,A.MainClaimRefNo
				,A.EligRefNo,A.AppRefNo ,A.AdmissionDate 
				,A.AdmissionTime  ,A.DischargeDate  ,A.DischargeTime ,A.LengthOfStay 
				,A.UnitOfDuration ,A.RoomNumber ,A.BedNumber ,A.SignificantSign
				,A.OtherCond ,A.DurationOfIllness ,A.UnitOfDuration 
				,A.Temperature ,A.BloodPressure	,A.Pulse ,A.RespiratoryRate
				,A.Weigh, A.LastMenstruationPeriod, A.RadioReport, A.ComReport


		SELECT
				'IPCR-' + CONVERT(VARCHAR(256), A.SerialNo) AS INVOICENO,
				B.PROVCLAIMNO,
				A.ClaimDate,
				A.DeptCode,
				SUM(A.Gross) AS TOTINVGRSAMT,
				SUM(A.Discount) AS TOTINVDISC,
				SUM(A.Deductible) AS TOTINVPATSHARE,
				SUM(A.NetAmount) AS TOTINVNETAMT,
				SUM(A.CompanyVatAmount) AS TOTINVNETVATAMOUNT,
				SUM(A.PatientVatAmount) AS TOTINVPATSHAREVATAMOUNT
			FROM #TMP_IPBILL A
			LEFT JOIN WSLMIDTABLES_06012018..wsl_geninfo B ON A.ClaimRefNo = B.PROVCLAIMNO
			GROUP BY A.SerialNo, B.PROVCLAIMNO, A.ClaimDate, A.DeptCode


		SELECT 
				'IPCR-' + CONVERT(VARCHAR(256), A.SerialNo) AS INVOICENO,
				SUBSTRING(
					CASE WHEN A.ServiceID IN (5, 37) THEN
						CASE WHEN LEN(LTRIM(RTRIM(ISNULL(SFDA.SFDA_Code,'')))) = 0 THEN A.ItemCode
						ELSE ISNULL(SFDA.SFDA_Code, A.ItemCode)
						END
					ELSE
						CASE WHEN A.ServiceID IN (15) THEN 'CON'
						ELSE ISNULL(M.ItemCode, A.ItemCode) END
					END, 1,20
				)
				AS SERVICECODE, 

				CONVERT(DATETIME,CONVERT(NVARCHAR,A.InvoiceDateTime,105),105)  AS SERVICEDATE,
				SUBSTRING(A.ItemName,1,80) AS SERVICEDESC, 

				SUM(A.Gross / A.EditQuantity) AS UNITSERVICEPRICE, 
				
				'N/A' AS UNITSERVICETYPE,
				SUM(A.EditQuantity) AS QTY, 
				'' AS TOOTHNO, 
				SUM(A.Gross) AS TOTSERVICEGRSAMT,
				SUM(A.Discount) AS TOTSERVICEDISC,
				SUM(A.Deductible) AS TOTSERVICEPATSHARE,
				SUM(A.NetAmount) AS TOTSERVICENETAMT,
				MIN(A.VatPercentage) AS TOTSERVICENETVATRATE,
				SUM(A.CompanyVatAmount) AS TOTSERVICENETVATRATE,
				MIN(A.VatPercentage) AS TOTSERVICEPATSHAREVATRATE,
				SUM(A.PatientVatAmount) AS TOTSERVICEPATSHAREVATAMOUNT
			FROM #TMP_IPBILL A
			LEFT JOIN WSLMIDTABLES_06012018..wsl_geninfo B ON A.ClaimRefNo = B.PROVCLAIMNO
			LEFT JOIN #TMP_COMPANYMAP M ON A.EditItemId = M.ItemID AND A.CategoryID = M.CategoryID AND A.ItemCode = M.SGH_Code --AND A.ServiceId = M.ServiceID
			LEFT JOIN #TMP_SFDA SFDA ON A.ITEMCODE = SFDA.SGH_Code

			GROUP BY A.ServiceID, A.itemCode, A.ItemName, 
			A.SerialNo, SFDA.SFDA_Code, M.ItemCode,
			M.ItemCode, A.InvoiceDateTime

		DROP TABLE #TMP_IPBILL
		DROP TABLE #TMP_COMPANYMAP
		DROP TABLE #TMP_SFDA