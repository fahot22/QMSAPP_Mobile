--select * from DHSRadiology_Details where ProIdClaim = 1428846

--select * from DHSService_Details where ProIdClaim = 1428846 and departmentid = 111



WITH CTE(
	ServiceCode, 
    ServiceDescription, 
	RadiologyResult,
	VisitDate,
	ProIdClaim,
	DuplicateCount)
AS (SELECT 
	ServiceCode, 
    ServiceDescription, 
	RadiologyResult,
	VisitDate,
	ProIdClaim,
           ROW_NUMBER() OVER(PARTITION BY 
		   ServiceCode, 
			ServiceDescription, 
			RadiologyResult,
			VisitDate,
			ProIdClaim
           ORDER BY ID) AS DuplicateCount
    FROM DHSRadiology_Details
	WHERE ProIdClaim = 1428846
	)
	SELECT * FROM CTE WHERE DuplicateCount > 1

--DELETE FROM CTE
--WHERE DuplicateCount > 1;