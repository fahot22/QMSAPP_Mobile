select PROVCLAIMNO
into #tmp_bill
from wsl_geninfo where CLAIMTYPE = 'O'
and CLAIMDATE >= '01-MAR-2021'

select PROVCLAIMNO, INVOICENO
into #tmp_wsl_invoice_x
from wsl_invoices  A
where PROVCLAIMNO in (select PROVCLAIMNO from #tmp_bill)
group by PROVCLAIMNO, INVOICENO

--select 
--	SUM(A.TOTINVGRSAMT) INVGROSS,  SUM(A.TOTINVDISC) AS INVDISC,  SUM(A.TOTINVNETAMT) AS INVNET, A.PROVCLAIMNO
--into #tmp_wsl_invoice
--from wsl_invoices  A
--where PROVCLAIMNO in (select PROVCLAIMNO from #tmp_bill)
--group by PROVCLAIMNO




select 
	SUM(TOTSERVICEGRSAMT) SERVICEGROSS,  SUM(TOTSERVICEDISC) AS SERVICEDISC,  SUM(TOTSERVICENETAMT) AS SERVICENET,INVOICENO
into #tmp_wsl_service_details
from wsl_service_details
where invoiceno in (
SELECT INVOICENO FROM #tmp_wsl_invoice_x)
group by INVOICENO


select 
	SUM(A.TOTINVGRSAMT) INVGROSS,  SUM(A.TOTINVDISC) AS INVDISC,  SUM(A.TOTINVNETAMT) AS INVNET, A.INVOICENO
into #tmp_wsl_invoice_2x
from wsl_invoices  A
where PROVCLAIMNO in (select PROVCLAIMNO from #tmp_bill)
group by INVOICENO


SELECT 
A.INVOICENO,
A.INVGROSS , B.SERVICEGROSS, A.INVGROSS - B.SERVICEGROSS AS SERVICEGROSSDIFF,
A.INVDISC, B.SERVICEDISC, A.INVDISC - B.SERVICEDISC AS SERVICEDISCDIFF,
A.INVNET, B.SERVICENET, A.INVNET - B.SERVICENET AS SERVICENETDIFF

FROM #tmp_wsl_invoice_2x A
LEFT JOIN #tmp_wsl_service_details B ON A.INVOICENO = B.INVOICENO





--select 
--	A.PROVCLAIMNO,
--	SUM(A.TOTCLAIMGRSAMT) HEADGROSS, SUM(B.INVGROSS) AS INVGROSS,
--	SUM(A.TOTCLAIMDISC) AS HEADDISC,  SUM(B.INVDISC) AS INVDISC,
--	SUM(A.TOTCLAIMNETAMT) AS HEADNET, SUM(B.INVNET)

--from wsl_geninfo A
--LEFT JOIN #tmp_wsl_invoice B ON A.PROVCLAIMNO = B.PROVCLAIMNO
--where A.PROVCLAIMNO in (select PROVCLAIMNO from #tmp_bill)
--group by A.PROVCLAIMNO







drop table #tmp_bill
--drop table #tmp_wsl_invoice
DROP TABLE #tmp_wsl_invoice_x
DROP TABLE #tmp_wsl_invoice_2x
drop table #tmp_wsl_service_details