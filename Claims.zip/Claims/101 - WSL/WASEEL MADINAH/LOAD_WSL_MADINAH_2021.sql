/* RUN THE SCRIPT IN SEQUENCE */
/*
	-- IP
	--------------------------------------------------------------------------------------------
	-- LOAD DATA
	-- SELECT * FROM category
	-- STEP 1 : EXEC ARMS.N_WSL_Generate_IPClaims_TEst 23, 0 , '01-JAN-2021'
	--------------------------------------------------------------------------------------------

	STEP 1 : EXEC ARMS.N_WSL_Generate_IPClaims 23, 0 , '01-JAN-2021'
	
	--------------------------------------------------------------------------------------------
	-- CLEAR DATA
	--------------------------------------------------------------------------------------------

	STEP 1 : EXEC [ARMS].[N_WSL_ClearClaim] 23, 0, '01-JAN-2021', 'NCCI', 1, 'I'
	STEP 2 : EXEC [ARMS].[N_WSL_ClearClaim] 23, 0, '01-JAN-2021', 'NCCI', 2, 'I'
	STEP 3 : EXEC [ARMS].[N_WSL_ClearClaim] 23, 0, '01-JAN-2021', 'NCCI', 3, 'I'

*/

/*
	-- OP

	--------------------------------------------------------------------------------------------
	-- LOAD DATA
	--------------------------------------------------------------------------------------------

	STEP 1 : EXEC [ARMS].[N_WSL_Generate_OPClaims] 23, 0, '01-SEP-2020'
	STEP 2 : EXEC [ARMS].[N_WSL_Generate_OPClaims_Invoice] 23, 0, '01-SEP-2020'
	STEP 3 : EXEC [ARMS].[N_WSL_Generate_OPClaims_Details] 23, 0, '01-SEP-2020'

	STEP 4 : EXEC [ARMS].[N_WSL_Generate_OPClaims_Diagnosis] 23, 0, '01-SEP-2020'
	STEP 5 : EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory] 23, 0, '01-SEP-2020'
	STEP 6 : EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory_Component] 23, 0, '01-SEP-2020'

	--------------------------------------------------------------------------------------------
	-- CLEAR DATA
	--------------------------------------------------------------------------------------------

	STEP 1 : EXEC [ARMS].[N_WSL_ClearClaim] 23, 0, '01-SEP-2020', 'NCCI', 1, 'O'
	STEP 2 : EXEC [ARMS].[N_WSL_ClearClaim] 23, 0, '01-SEP-2020', 'NCCI', 2, 'O'
	STEP 3 : EXEC [ARMS].[N_WSL_ClearClaim] 23, 0, '01-SEP-2020', 'NCCI', 3, 'O'

*/


