--SELECT DISTINCT serviceid  FROM HIS..CompanyProceduresMapping
--WHERE IPOP = 1 and CategoryId = 24
DECLARE @CategoryId INT = 91

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = @CategoryId
AND ServiceId in (1) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = @CategoryId
AND ServiceId in (2) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = @CategoryId
AND ServiceId in (5) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = @CategoryId
AND ServiceId in (6) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = v
AND ServiceId in (8) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = 24
AND ServiceId in (10) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = 24
AND ServiceId in (11) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = 24
AND ServiceId in (13) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = 24
AND ServiceId in (20) GROUP BY ItemId HAVING COUNT(ItemId) > 1

SELECT ItemId  FROM HIS..CompanyProceduresMapping
WHERE IPOP = 1 and CategoryId = 24
AND ServiceId in (24) GROUP BY ItemId HAVING COUNT(ItemId) > 1

--1
--2
--5
--6
--8
--10
--11
--13
--20
--24
