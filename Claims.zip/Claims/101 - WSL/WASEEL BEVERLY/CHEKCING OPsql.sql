select  *from OPCompanyBillDetail where AuthorityId = 4943512 and categoryid = 24

select * from OPDoctorOrder where OPBillID = 16763957

select * from ClinicalVisit where ScheduleID = 7089844

select * from WSLMIDTABLES_06012018..wsl_geninfo where payerid = 'ncci' and CLAIMDATE >= '01-APR-2020' and ISNULL(MAINSYMPTOM,'') = '' 

select PROVCLAIMNO from WSLMIDTABLES_06012018..wsl_geninfo where payerid = 'ncci' and CLAIMDATE >= '01-APR-2020' --and ISNULL(MAINSYMPTOM,'') = ''
and PROVCLAIMNO not in (select PROVCLAIMNO from WSLMIDTABLES_06012018..wsl_claim_diagnosis) 

