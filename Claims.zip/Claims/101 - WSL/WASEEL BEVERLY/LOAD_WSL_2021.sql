
/*
	-- IP
	
	EXEC [ARMS].[N_WSL_ClearClaim] 89, 0, '01-APR-2022', 'NCCI-STAFF', 1, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 89, 0, '01-APR-2022', 'NCCI-STAFF', 2, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 89, 0, '01-APR-2022', 'NCCI-STAFF', 3, 'I'

	EXEC ARMS.N_WSL_Generate_IPClaims 89, 0 , '01-APR-2022'

	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-APR-2022', 'NCCI', 1, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-APR-2022', 'NCCI', 2, 'I'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-APR-2022', 'NCCI', 3, 'I'

	EXEC ARMS.N_WSL_Generate_IPClaims 24, 0 , '01-APR-2022'

	EXEC [ARMS].[N_WSL_Generate_Update_PayerID] 'NCCI-STAFF', 'NCCI', '01-APR-2022'

*/

/*
	-- OP

	EXEC [ARMS].[N_WSL_ClearClaim] 89, 0, '01-APR-2022', 'NCCI', 1, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 89, 0, '01-APR-2022', 'NCCI', 2, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 89, 0, '01-APR-2022', 'NCCI', 3, 'O'

	EXEC [ARMS].[N_WSL_Generate_OPClaims] 89, 0, '01-APR-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Invoice] 89, 0, '01-APR-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details] 89, 0, '01-APR-2022'

	EXEC [ARMS].[N_WSL_Generate_OPClaims_Diagnosis] 89, 0, '01-APR-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory] 89, 0, '01-APR-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory_Component] 89, 0, '01-APR-2022'

	-- NCCI

	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-APR-2022', 'NCCI', 1, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-APR-2022', 'NCCI', 2, 'O'
	EXEC [ARMS].[N_WSL_ClearClaim] 24, 0, '01-APR-2022', 'NCCI', 3, 'O'

	EXEC [ARMS].[N_WSL_Generate_OPClaims] 24, 0, '01-APR-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Invoice] 24, 0, '01-APR-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details] 24, 0, '01-APR-2022'

	EXEC [ARMS].[N_WSL_Generate_OPClaims_Diagnosis] 24, 0, '01-APR-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory] 24, 0, '01-APR-2022'
	EXEC [ARMS].[N_WSL_Generate_OPClaims_Laboratory_Component] 24, 0, '01-APR-2022'


	EXEC [ARMS].[N_WSL_Generate_Update_PayerID] 'NCCI-STAFF', 'NCCI', '01-APR-2022'

*/


/*
	JEDDAH

	NCCI 24
	NCCI STAFF
	88

	EXEC [ARMS].[N_WSL_Generate_OPClaims_Details_IT] 24, 0, '01-APR-2022'
	
	select * from category where id= 88
	INV06202129811

	update A
	SET A.Age = datediff(year, a.dateofbirth, getdate()) 
	from patient A where  A.age > 999

	select registrationno, authorityid, billno, itemcode, itemname, departmentid  from arcompanybilldetail where authorityid = 29811

	SELECT 
		SUM(TOTCLAIMGRSAMT) AS GROSS,  
		SUM(TOTCLAIMNETAMT) AS NET
	FROM WSLMIDTABLES_06012018..wsl_geninfo 
	WHERE  CLAIMTYPE = 'O' AND CLAIMDATE >= '01-APR-2022' AND PAYERID = 'NCCI'


*/


SELECT * FROM WSLMIDTABLES_06012018



