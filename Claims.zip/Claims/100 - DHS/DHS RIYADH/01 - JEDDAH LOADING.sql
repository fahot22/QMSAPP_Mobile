-- 1. GET BATCH
-- select * from ARADMIN.DHS_ClaimBAtch where CorrectionLocked = 0
-- select * from ARADMIN.DHS_ClaimBAtch where batchstartdate >= '01-JAN-2022'

-- 41 42

-- 2. UPDATE OLD BATCH
-- update ARADMIN.DHS_ClaimBAtch set CorrectionLocked =1 where CorrectionLocked = 0 AND batchstartdate < '01-SEP-2020'

-- 3.LOAD TO MID TABLE
-- 40

-- EXEC ARMS.DHS_HisMid_Load 53, 0, ''

-- 4. CHECK DUPLICATE
/*

SELECT
InvoiceId, DoctorId,AuthorityId, PatientNo, categoryid, companyid, gradeid
FROM ARADMIN.DHS_Mid_OPBill_Header
WHERE ClaimBatchId = 53
GROUP BY InvoiceId, DoctorId, AuthorityId, PatientNo, categoryid, companyid, gradeid
HAVING COUNT(*) > 1

*/

-- 4. FIX DUPLICATE 
-- EXEC [ARMS].[DHS_Fix_Duplicate_Header] 79


-- 5. CHECK DATA

/*

	DECLARE @ClaimBatchId INT = 78
	SELECT
		SUM(TotalNetAmount)  AS Net
	FROM ARADMIN.DHS_Mid_OPBill_Header WHERE ClaimBatchId = @ClaimBatchId

	SELECT SUM(NetAmount)  AS Net, SUM(NetVatAmount) AS VAT
	FROM ARADMIN.DHS_Mid_OPBill_Details   WHERE ClaimBatchId = @ClaimBatchId

*/

-- 6. RELOAD THEN LOAD STEP #3

/*

DECLARE @ClaimBatchId INT = 78

DELETE FROM ARADMIN.DHS_Mid_OPBill_Diagnosis
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Lab
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Rad
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Details
WHERE ClaimBatchId = @ClaimBatchId

DECLARE @ClaimBatchId INT = 78
DELETE FROM ARADMIN.DHS_Mid_OPBill_Header 
WHERE ClaimBatchId = @ClaimBatchId

*/



-- 7. LOAD TO MID



-- 8. CHECK FINAL

/*

	DECLARE @ClaimCode VARCHAR(256) = 'BUPA-ARAMCO', @Date DATETIME = '01-11-2019', @TDate DATETIME
	
	SET @TDate = DATEADD(M,1,@Date)

	SELECT sss
		 SUM(TotalNetAmount)
	FROM DHSClaim_Header WHERE BatchStartDate >= @Date and BatchEndDate < @TDate
	AND CompanyCode = @ClaimCode


	SELECT SUM(NetAmount) AS Net , SUM(NetVatAmount) AS Vat
	FROM DHSService_Details WHERE ProIdClaim In 
	(
		SELECT ProIdClaim
		FROM DHSClaim_Header WHERE BatchStartDate >= @Date and BatchEndDate < @TDate
		AND CompanyCode = @ClaimCode
	)

*/

-- 9. CLEAR DHS TABLES

/*
DECLARE @CategoryId INT = 11,
		@FDate DATETIME = '01-JAN-2020',
		@TDate DATETIME = '01-FEB-2020',
		@CatName VARCHAR(50) = 'BUPA'

DELETE FROM DHSService_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSLab_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSRadiology_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSDiagnosis_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

-- LAST

DELETE
FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
AND BatchStartDate >= @FDate AND BatchEndDate < @TDate

*/