
select distinct serviceid 
from CompanyProceduresMapping 
where categoryid = 72 and ipop = 2

---- select *from opbservice

select itemid from CompanyProceduresMapping
where serviceid IN (3) and ipop= 2 and categoryid = 72
group by itemid having count(*) > 1

---- select * from category order by code

--select * from CompanyProceduresMapping where categoryid = 6
--and ipop = 2 and itemid = 67297 and serviceid = 11

--486
--1251
--1921
--3363

-- delete from CompanyProceduresMapping where id = 11070

select SGH_Code from MOHInv_CodeMappings
where LEN(SGH_Code) > 0
AND Deleted = 0
group by SGH_Code
having count(SGH_Code) > 1


--select SUM(
	
--	(A.EditPrice * A.EditQuantity) - 
--	(A.Discount * A.EditQuantity) -
--	(A.DeductibleAmount * A.EditQuantity)

--) from ARIPBillItemDetail A
--INNER JOIN aripbill B ON A.BillNo = B.BillNo
--where B.categoryid = 27
--AND B.InvoiceDateTime >= '01-OCT-2021' AND B.InvoiceDateTime < '01-NOV-2021'


	SELECT
		InternalCode
	FROM RCM.Integration_ItemMapping_Details 
	WHERE IntegrationItemMappingProfileId = 3 AND Deleted = 0
	group by internalcode
	having count(*) > 1



	select * from rcm.integration_setup
