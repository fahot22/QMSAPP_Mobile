-- 01. select * from ARADMIN.DHS_ClaimBAtch where batchstartdate >= '01-DEC-2021'
--  165 167 169
-- 02. EXEC [ARMS].[DHS_Generate_ARIPBillData] 183

-- 03. EXEC ARMS.DHS_HisMid_Load_IP 183