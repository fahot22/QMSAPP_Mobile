DECLARE @CategoryId INT = 6,
		@FDate DATETIME = '01-DEC-2020',
		@TDate DATETIME = '01-JAN-2021',
		@CatName VARCHAR(50) = 'MALATH',
		@ClaimType VARCHAR = 'O'

DELETE FROM DHSService_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType
)

DELETE FROM DHSLab_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType
)

DELETE FROM DHSRadiology_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType
)

DELETE FROM DHSDiagnosis_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType
)

---- LAST

DECLARE @CategoryId INT = 77,
		@FDate DATETIME = '01-DEC-2020',
		@TDate DATETIME = '01-JAN-2021',
		@CatName VARCHAR(50) = 'MALATH',
		@ClaimType VARCHAR = 'O'

DELETE
FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType