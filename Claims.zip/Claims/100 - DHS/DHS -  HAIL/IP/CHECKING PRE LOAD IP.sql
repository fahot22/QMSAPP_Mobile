	DECLARE @ClaimBatchId INT = 61
	SELECT
		SUM(TotalNetAmount)  AS Net
	FROM ARADMIN.DHS_Mid_OPBill_Header WHERE ClaimBatchId = @ClaimBatchId

	SELECT SUM(
		(LineClaimedAmount ) - 
		(LineItemDiscount ) - 
		(CoInsurance )
		
		)  AS Net, 
	
	
	SUM(NetVatAmount) AS VAT
	FROM ARADMIN.DHS_Mid_OPBill_Details   WHERE ClaimBatchId = @ClaimBatchId

	
