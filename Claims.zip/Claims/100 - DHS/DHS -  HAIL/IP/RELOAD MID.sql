-- select * from aradmin.dhs_claimbatch where batchstartdate >= '01-JUN-2020'
-- 41 | 42
DECLARE @ClaimBatchId INT = 81

DELETE FROM ARADMIN.DHS_Mid_OPBill_Diagnosis
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Lab
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Rad
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Details
WHERE ClaimBatchId = @ClaimBatchId


DECLARE @ClaimBatchId INT = 81


DELETE FROM ARADMIN.DHS_Mid_OPBill_Header 
WHERE ClaimBatchId = @ClaimBatchId