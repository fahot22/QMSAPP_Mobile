-- 01. select * from ARADMIN.DHS_ClaimBAtch where batchstartdate >= '01-OCT-2021'
-- 
-- 02. EXEC [ARMS].[DHS_Generate_ARIPBillData] 130

-- 03. EXEC ARMS.DHS_HisMid_Load_IP 130

-- 128, 130