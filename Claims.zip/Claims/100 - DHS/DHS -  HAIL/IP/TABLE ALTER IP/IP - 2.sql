
ALTER TABLE dbo.dhsclaim_header
ALTER COLUMN
	[claimedamount] [decimal](18, 6) NULL

ALTER TABLE dbo.dhsclaim_header
ALTER COLUMN
	[claimedamountsar] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsclaim_header
ALTER COLUMN
	[totalnetamount] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsclaim_header
ALTER COLUMN
	[totaldiscount] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsclaim_header
ALTER COLUMN
	[totaldeductible] [decimal](18, 6) NULL

ALTER TABLE dbo.dhsservice_details
ALTER COLUMN [lineclaimedamount] [decimal](18, 6) NULL

ALTER TABLE dbo.dhsservice_details
ALTER COLUMN
	[coinsurance] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsservice_details
ALTER COLUMN
	[copay] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsservice_details
ALTER COLUMN
	[lineitemdiscount] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsservice_details
ALTER COLUMN
	[netamount] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsservice_details
ALTER COLUMN
	[r_paidamount] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsservice_details
ALTER COLUMN
	[VatPercentage] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsservice_details
ALTER COLUMN
	[PatientVatAmount] [decimal](18, 6) NULL

	ALTER TABLE dbo.dhsservice_details
ALTER COLUMN
	[NetVatAmount] [decimal](18, 6) NULL

