ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[Admissionno] [nvarchar](50) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[AdmissionDate] [datetime] NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[AdmissionSpecialty] [nvarchar](100) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[AdmissionType] [nvarchar](100) NULL

	
ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[RoomNumber] [nvarchar](100) NULL



ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[BedNumber] [nvarchar](100) NULL

	
ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[DischargeDate] [datetime] NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[DischargeSpecialty] [nvarchar](100) NULL



ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[LengthofStay] [nvarchar](100) NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[AdmissionWeight] [nvarchar](100) NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ADD
[DischargeMode] [nvarchar](100) NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ALTER COLUMN
[ClinicalData] [nvarchar](4000) NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ALTER COLUMN
[DoctorName] [nvarchar](500) NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[ServiceDescription] [nvarchar](1000) NULL

	
ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[ServiceCode] [nvarchar](200) NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Lab
ALTER COLUMN
[LabResult] [nvarchar](4000) NULL


ALTER TABLE ARADMIN.DHS_Mid_OPBill_Rad
ALTER COLUMN
[RadiologyResult] [nvarchar](4000) NULL


-- PART 2

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ALTER COLUMN
[claimedamount] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ALTER COLUMN
[claimedamountsar] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ALTER COLUMN
[totalnetamount] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ALTER COLUMN
[totaldiscount] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Header
ALTER COLUMN
[totaldeductible] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN [lineclaimedamount] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[coinsurance] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[copay] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[lineitemdiscount] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[netamount] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[r_paidamount] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[VatPercentage] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[PatientVatAmount] [decimal](18, 6) NULL

ALTER TABLE ARADMIN.DHS_Mid_OPBill_Details
ALTER COLUMN
[NetVatAmount] [decimal](18, 6) NULL


