ALTER TABLE dbo.dhsclaim_header
ADD
	[Admissionno] [nvarchar](50) NULL

ALTER TABLE dbo.dhsclaim_header
ADD
	[AdmissionDate] [datetime] NULL


	ALTER TABLE dbo.dhsclaim_header
ADD
	[AdmissionSpecialty] [nvarchar](100) NULL

	ALTER TABLE dbo.dhsclaim_header
ADD
	[AdmissionType] [nvarchar](100) NULL

	
	ALTER TABLE dbo.dhsclaim_header
ADD
	[RoomNumber] [nvarchar](100) NULL



	ALTER TABLE dbo.dhsclaim_header
ADD
	[BedNumber] [nvarchar](100) NULL

	
ALTER TABLE dbo.dhsclaim_header
ADD
	[DischargeDate] [datetime] NULL


	ALTER TABLE dbo.dhsclaim_header
ADD
	[DischargeSpecialty] [nvarchar](100) NULL



	ALTER TABLE dbo.dhsclaim_header
ADD
	[LengthofStay] [nvarchar](100) NULL



	ALTER TABLE dbo.dhsclaim_header
ADD
	[AdmissionWeight] [nvarchar](100) NULL



	ALTER TABLE dbo.dhsclaim_header
ADD
	[DischargeMode] [nvarchar](100) NULL



	ALTER TABLE dbo.dhsclaim_header
ALTER COLUMN
	[ClinicalData] [nvarchar](4000) NULL


	ALTER TABLE dbo.dhsclaim_header
ALTER COLUMN
	[DoctorName] [nvarchar](500) NULL





		ALTER TABLE dbo.dhsservice_details
		ALTER COLUMN
	[ServiceDescription] [nvarchar](1000) NULL

	
		ALTER TABLE dbo.dhsservice_details
		ALTER COLUMN
	[ServiceCode] [nvarchar](200) NULL


	
	ALTER TABLE dbo.dhslab_details
ALTER COLUMN
	[LabResult] [nvarchar](4000) NULL


	ALTER TABLE dbo.dhsradiology_details
ALTER COLUMN
	[RadiologyResult] [nvarchar](4000) NULL


