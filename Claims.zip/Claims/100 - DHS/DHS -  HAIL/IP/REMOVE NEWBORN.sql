

--DELETE FROM DHSService_Details WHERE ProIdClaim IN(
--	select proidclaim from DHSClaim_Header
--where CompanyCode = 'BUPA'
--and ClaimType = 'I' and claimedamount = 0.01

--)

--DELETE FROM DHSLab_Details WHERE ProIdClaim IN(
--	select proidclaim from DHSClaim_Header
--where CompanyCode = 'BUPA'
--and ClaimType = 'I' and claimedamount = 0.01

--)

--DELETE FROM DHSRadiology_Details
--WHERE ProIdClaim IN(
--	select proidclaim from DHSClaim_Header
--where CompanyCode = 'BUPA'
--and ClaimType = 'I' and claimedamount = 0.01

--)

--DELETE FROM DHSDiagnosis_Details
--WHERE ProIdClaim IN(
--select proidclaim from DHSClaim_Header
--where CompanyCode = 'BUPA'
--and ClaimType = 'I' and claimedamount = 0.01

--)

--delete from DHSClaim_Header
--where CompanyCode = 'BUPA'
--and ClaimType = 'I' and claimedamount = 0.01

