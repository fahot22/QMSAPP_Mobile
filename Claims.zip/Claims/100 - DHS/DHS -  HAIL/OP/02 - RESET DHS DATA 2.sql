DECLARE @CategoryId INT = 11,
		@FDate DATETIME = '01-OCT-2020',
		@TDate DATETIME = '01-NOV-2020',
		@CatName VARCHAR(50) = 'BUPA',
		@ClaimType VARCHAR(32) = 'O'
DELETE
FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
AND ClaimType = @ClaimType