DECLARE @ClaimCode VARCHAR(256) = 'SAICO', @Date DATETIME = '01-AUG-2020', @TDate DATETIME
	
	SET @TDate = DATEADD(M,1,@Date)

	SELECT 
		 SUM(ClaimedAmount) AS GROSS,
		 SUM(TotalDiscount) AS DISC,
		 SUM(TotalDeductible) AS DED,

		  SUM(ClaimedAmount - TotalDiscount - TotalDeductible)  as netcomp,
		 SUM(TotalNetAmount) as net
	FROM DHSClaim_Header WHERE BatchStartDate >= @Date and BatchEndDate < @TDate
	AND CompanyCode = @ClaimCode
	AND ClaimType = 'O'

	SELECT SUM(
		(LineClaimedAmount ) - 
		(LineItemDiscount ) - 
		(CoInsurance )
		
		)  AS Net
	 , SUM(NetVatAmount) AS Vat
	FROM DHSService_Details WHERE ProIdClaim In 
	(
		SELECT ProIdClaim
		FROM DHSClaim_Header WHERE BatchStartDate >= @Date and BatchEndDate < @TDate
		AND CompanyCode = @ClaimCode
		AND ClaimType = 'O'
	)