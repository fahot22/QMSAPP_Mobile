DECLARE @CategoryId INT = 11,
		@FDate DATETIME = '01-JAN-2022',
		@TDate DATETIME = '01-FEB-2022',
		@CatName VARCHAR(50) = 'BUPA',
		@ClaimType VARCHAR = 'O'

DELETE FROM DHSService_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType
)

DELETE FROM DHSLab_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType
)

DELETE FROM DHSRadiology_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType
)

DELETE FROM DHSDiagnosis_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType
)

---- LAST

DECLARE @CategoryId INT = 11,
		@FDate DATETIME = '01-JAN-2022',
		@TDate DATETIME = '01-FEB-2022',
		@CatName VARCHAR(50) = 'BUPA',
		@ClaimType VARCHAR = 'O'

DELETE
FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
AND BatchStartDate >= @FDate AND BatchEndDate < @TDate AND ClaimType = @ClaimType