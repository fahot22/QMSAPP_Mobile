-- select * from aradmin.dhs_claimbatch where correctionlocked = 0
-- select * from ARADMIN.DHS_OPBill where ClaimBatchId = 43
DECLARE @ClaimBatchId INT = 43

update A
SET 
	 A.CompanyVatAmount = (A.GrossAmount -A.DiscountAmount - A.DeductibleAmount) * (dbo.Get_IPOP_VAT_Percentage(2, A.ServiceId, A.DepartmentId, A.ItemId, A.BillDateTime) / 100.0),
	 A.VatIndicator = 
		CASE WHEN A.NationalityId IN (25) THEN 0 ELSE 
		CASE WHEN (dbo.Get_IPOP_VAT_Percentage(2, A.ServiceId, A.DepartmentId, A.ItemId, A.BillDateTime) / 100.0) > 0 THEN 1 ELSE 0 END
		END,

	A.VatPercentage = (dbo.Get_IPOP_VAT_Percentage(2, A.ServiceId, A.DepartmentId, A.ItemId, A.BillDateTime)),

	A.PatientVatAmount = 
		CASE WHEN A.NationalityId IN (25) THEN 0 ELSE 
			 (A.DeductibleAmount) * (dbo.Get_IPOP_VAT_Percentage(2, A.ServiceId, A.DepartmentId, A.ItemId, A.BillDateTime) / 100.0)
		END

from aradmin.DHS_OPBill A 
WHERE ClaimBatchId = @ClaimBatchId
