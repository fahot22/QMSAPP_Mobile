 SELECT id, authorityid, doctorid,  * FROM ARADMIN.DHS_Mid_OPBill_Header 
 WHERE ClaimBatchId = 33 
 AND AuthorityId = 4801086



 -- select * from ARADMIN.DHS_OPBill where companyid = 17962 and ClaimBatchId = 34 and IsReferral = 1
 -- update  ARADMIN.DHS_OPBill set IsReferral = 1 where companyid = 17962 and ClaimBatchId = 34 and IsReferral = 0
 -- Update ARADMIN.DHS_OPBill set insurancecardno = 40051583  where authorityId = 4794232 and claimbatchid = 33
 -- EXEC [ARADMIN].[N_DhsFinalLoading_FixMidDuplicateHeader] 33, 729352, 4801086, 11167