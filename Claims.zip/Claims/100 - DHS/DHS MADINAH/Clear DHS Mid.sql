DECLARE @CategoryId INT = 83,
		@FDate DATETIME = '01-APR-2021',
		@TDate DATETIME = '01-MAY-2021',
		@CatName VARCHAR(50) = 'SAICO',


DELETE FROM DHSService_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSLab_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSRadiology_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSDiagnosis_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

---- LAST

DELETE
FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
AND BatchStartDate >= @FDate AND BatchEndDate < @TDate