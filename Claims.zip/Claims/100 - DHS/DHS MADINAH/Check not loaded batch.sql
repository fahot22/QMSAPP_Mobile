select * from aradmin.DHS_ClaimBatch where id not in (
select 
DISTINCT ClaimBatchId 
from aradmin.DHS_Mid_OPBill_Header WHERE batchstartdate >= '01-JAN-2021'

)




select * from aradmin.DHS_OPBillDiagnosis where OPBillDataId in (select id from aradmin.DHS_OPBill where AuthorityId = 1371773)


select * from 

select * from aradmin.DHS_OPBill where AuthorityId = 1371773


select * from ICDDetail where visitid = 3001264


delete from  aradmin.DHS_OPBillDiagnosis where DiagnosisCode is null