select * 
into #tmp_SFDA
from MOHInv_CodeMappings
where deleted = 0 and ISNULL(sfda_code,'') <> '' AND LEN(ISNULL(sfda_code,'')) > 0


--select distinct ITEMCODE from arcompanybilldetail where billdatetime >= '01-MAR-2021'
--and BillDateTime < '01-APR-2021'
--and HasCompanyLetter = 1 and serviceid = 11 and itemcode not in (SELECT SGH_Code FROM #tmp_SFDA)


DROP TABLE #tmp_SFDA
