--select * from CompanyProceduresMapping where itemid =3 and serviceid = 24


UPDATE A
SET 
	A.SGH_Code = C.InternalCode
FROM CompanyProceduresMapping A
INNER JOIN 
(
	SELECT B.Code AS InternalCode, B.Description AS InternalDesc, A.* FROM CompanyProceduresMapping A 
	INNER JOIN RCM.All_IPItems B ON A.ServiceID = B.ServiceId AND A.ItemID = B.Id
	WHERE A.ipop = 1
) C ON A.ServiceID = C.ServiceId AND A.ItemID = C.Id
WHERE A.ipop = 1



SELECT B.Code AS InternalCode, B.Description AS InternalDesc, A.* FROM CompanyProceduresMapping A 
INNER JOIN RCM.All_IPItems B ON A.ServiceID = B.ServiceId AND A.ItemID = B.Id
WHERE A.ipop = 1