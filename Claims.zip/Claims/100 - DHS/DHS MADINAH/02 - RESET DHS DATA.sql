DECLARE @CategoryId INT = 6,
		@FDate DATETIME = '01-FEB-2021',
		@TDate DATETIME = '01-MAR-2021',
		@CatName VARCHAR(50) = 'BUPA',
		@ClaimType VARCHAR(32) = 'I'

DELETE FROM DHSService_Details WHERE ProIdClaim IN(
	SELECT ProIdClaim  FROM DHSClaim_Header WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
	AND ClaimType = @ClaimType
)

DELETE FROM DHSLab_Details WHERE ProIdClaim IN(
	SELECT ProIdClaim FROM DHSClaim_Header 
	WHERE CompanyCode = @CatName AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
	AND ClaimType = @ClaimType
)

DELETE FROM DHSRadiology_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
	AND ClaimType = @ClaimType
)

DELETE FROM DHSDiagnosis_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
	AND ClaimType = @ClaimType
)


DELETE FROM DHSClaim_Header WHERE  ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
	AND ClaimType = @ClaimType
)
