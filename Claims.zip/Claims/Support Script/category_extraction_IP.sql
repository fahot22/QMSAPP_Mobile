DECLARE @CategoryId INT = 27,
	@CompanyId INT = 0,
	@AfterCL INT = 1,
	@FDate DATETIME = '01-OCT-2021',
	@TDate DATETIME = '31-OCT-2021'
	
	SELECT DISTINCT ItemId, ServiceId, ItemCode, ItemName, Categoryid, Price, IPOP
	INTO #TMP_COMPANYMAP
	FROM dbo.CompanyProceduresMapping
	WHERE IPOP = 1 and CategoryId = @CategoryId

	SELECT DISTINCT SGH_Code, SFDA_Code
	INTO #TMP_SFDA
	FROM dbo.MOHInv_CodeMappings
	WHERE Deleted = 0
	AND LEN(LTRIM(RTRIM(SFDA_Code))) > 0



SELECT
			SUM(
	
			(A.EditPrice * A.EditQuantity) - 
			(A.Discount * A.EditQuantity) -
			(A.DeductableAmount * A.EditQuantity)

		)


		FROM HIS.DBO.aripbillitemdetail A
			LEFT JOIN HIS.DBO.ARIPBill B ON A.BillNo = B.BillNo
			LEFT JOIN HIS.DBO.oldinpatient c ON B.ipid = c.ipid    
			LEFT JOIN HIS.DBO.company d ON c.CompanyID = d.id  
			LEFT JOIN HIS.DBO.patient e ON c.RegistrationNo = e.Registrationno   

			LEFT JOIN #TMP_COMPANYMAP M ON A.ItemId = M.ItemID 
			AND B.CategoryId = M.CategoryID AND A.ServiceId = M.ServiceID AND M.IPOP = 1

			LEFT JOIN #TMP_SFDA SFDA ON A.ITEMCODE = SFDA.SGH_Code

			LEFT JOIN dbo.OldInPatient OIP ON B.IPID = OIP.IPID
			LEFT JOIN dbo.Employee EE ON OIP.DoctorId = EE.Id
			LEFT JOIN dbo.Department DE ON EE.DepartmentID = DE.Id

		WHERE   
			CONVERT(date,B.InvoiceDateTime) >=  @FDate
			AND convert(date,B.InvoiceDateTime) < DATEADD(D,1,@TDate)
			AND B.categoryid = @CategoryId
			AND (@CompanyId = 0 OR B.CompanyID = @CompanyId)
			AND B.HasCompanyLetter = @AfterCL
			AND A.serviceid NOT IN (14, 39)
			AND B.editbillamount > 0.1
			AND A.EditPrice > 0