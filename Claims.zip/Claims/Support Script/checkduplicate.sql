--select distinct serviceid 
--from CompanyProceduresMapping 
--where categoryid = 11 and ipop = 2

---- select *from opbservice

--select itemid from CompanyProceduresMapping
--where serviceid IN (11) and ipop= 2 and categoryid = 6
--group by itemid having count(*) > 1

---- select * from category order by code

--select * from CompanyProceduresMapping where categoryid = 6
--and ipop = 2 and itemid = 67297 and serviceid = 11

--486
--1251
--1921
--3363

-- delete from CompanyProceduresMapping where id = 11070

--select SGH_Code from MOHInv_CodeMappings
--where LEN(SGH_Code) > 0
--AND Deleted = 0
--group by SGH_Code
--having count(SGH_Code) > 0


--select SUM(
	
--	(A.EditPrice * A.EditQuantity) - 
--	(A.Discount * A.EditQuantity) -
--	(A.DeductibleAmount * A.EditQuantity)

--) from ARIPBillItemDetail A
--INNER JOIN aripbill B ON A.BillNo = B.BillNo
--where B.categoryid = 27
--AND B.InvoiceDateTime >= '01-OCT-2021' AND B.InvoiceDateTime < '01-NOV-2021'
