DECLARE @CategoryId INT = 27,
	@CompanyId INT = 0,
	@AfterCL INT = 1,
	@FDate DATETIME = '01-OCT-2021',
	@TDate DATETIME = '31-OCT-2021'