create table ARADMIN.By_PassLOA
(
	Id INT PRIMARY KEY IDENTITY(1,1),
	CategoryId INT NOT NULL,
	CompanyId INT NOT NULL,
	GradeId INT NOT NULL,
	Level INT NOT NULL,
	CreatedAt DateTime NOT NULL,
	Deleted BIT
)

-- select * from category where code = 'compliment'
--insert into ARADMIN.By_PassLOA
--values(60,0,0,1,GETDaTE(), 0)