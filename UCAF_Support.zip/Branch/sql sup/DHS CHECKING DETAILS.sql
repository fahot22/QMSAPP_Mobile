DECLARE @ClaimbatchId INT = 78, @TransCategoryId INT = 84

	-- select * from category where id = 84
	SELECT DISTINCT ItemId, ServiceId, ItemCode, Categoryid, IPOP
	INTO #TMP_COMPANYMAP
	FROM dbo.CompanyProceduresMapping
	WHERE IPOP = 2 and CategoryId = @TransCategoryId

	SELECT * 
	INTO #OPBILL
	from ARADMIN.DHS_OPBill
	WHERE ClaimBatchId = @ClaimBatchId


	
	SELECT * 
	INTO #MIDHEADER
	FROM ARADMIN.DHS_Mid_OPBill_Header
	WHERE ClaimBatchId = @ClaimBatchId


	SELECT 
		B.Id, A.BillNo, A.BillDateTime, A.BillDateTime AS BDTIME,
		A.Quantity, A.GrossAmount, A.DeductibleAmount,  
		CASE WHEN A.GrossAmount - A.DiscountAmount > 0 THEN
			(A.DeductibleAmount / (A.GrossAmount - A.DiscountAmount)) * 100.00
		ELSE 0 END AS percentage
		, 
		A.DiscountAmount, (A.GrossAmount - A.DeductibleAmount - A.DiscountAmount) Net, 

		CASE WHEN (A.ServiceId = 2 AND A.CategoryId IN (11, 84))  
		THEN 'CON' 
		ELSE
			CASE WHEN A.ServiceId = 11 THEN
				-- SFDA.SFDA_Code
				--SUBSTRING(SFDA.SFDA_Code,1,200)
				''
			ELSE
				--ISNULL(M.ItemCode, SUBSTRING(A.ItemCode,1,200))
				''
			END
		END AS ItemCode, 
		
		A.ItemDescription, 

		CASE WHEN A.Serviceid = 11 
		THEN 
			--SUBSTRING(SFDA.SFDA_Code,1,200)
			''

		ELSE NULL END as SFDA, 

		NULL AS DESCR, LTRIM(RTRIM(S.Name)) AS ServiceName, 

		A.VatIndicator,

		A.VatPercentage,
		
		A.PatientVatAmount,

		A.CompanyVatAmount,
		
		A.ServiceId, A.DepartmentId,
		A.ItemId, A.BillNo as InvoiceNo, A.BillDateTime BillT,
		CASE WHEN A.DepartmentId IN (54) THEN 3 -- LAB
		WHEN A.DepartmentId IN (83) THEN 4 -- OPT
		WHEN A.DepartmentId IN (30) THEN 5 -- DNT
		ELSE
			CASE WHEN A.ServiceId IN (11) THEN 1 -- MED
			ELSE 2 END -- OTHER SERVICES
		END as DEPARTMENT,
		A.CategoryId, A.ClaimBatchId, A.Id AS OPID

	INTO #TMPX
	FROM #OPBILL A
		LEFT JOIN #MIDHEADER B ON A.InvoiceId = B.InvoiceId 
		AND A.DoctorId = B.DoctorId AND A.ClinicalData = B.ClinicalData
		AND A.AuthorityId = B.AuthorityId AND A.RegistrationNo = B.PatientNo
		AND A.CategoryId = B.CategoryId AND A.CompanyId = B.CompanyId
		AND A.GradeId = B.GradeId AND B.ClaimBatchId = @ClaimBatchId

		LEFT JOIN OPBService S ON A.ServiceId = S.id
		LEFT JOIN Patient PT ON A.RegistrationNo = PT.RegistrationNo

		-- MAPPING
		--LEFT JOIN #TMP_COMPANYMAP M ON A.ItemId = M.ItemID 
			 --AND A.ServiceId = M.ServiceID AND M.IPOP = 2

		-- SFDA
		--LEFT JOIN
		--(
		--	SELECT DISTINCT X.ItemId,
		--		CASE WHEN LEN(LTRIM(RTRIM(ISNULL(SFDA.SFDA_Code,'')))) > 0 THEN SFDA.SFDA_Code ELSE I.ItemCode END AS SFDA_Code
		--	FROM #OPBILL X
		--	LEFT JOIN item I ON X.ItemId = I.Id
		--	LEFT JOIN dbo.MOHInv_CodeMappings SFDA ON I.ITEMCODE = SFDA.SGH_Code and SFDA.Deleted = 0
		--	WHERE X.ServiceId = 11 AND X.ClaimBatchId = @ClaimBatchId AND X.CategoryId = @TransCategoryId
		--) SFDA ON A.ItemId = SFDA.ItemId 
	
		--LEFT JOIN dbo.MOHInv_CodeMappings SFDA ON I.ITEMCODE = SFDA.SGH_Code and SFDA.Deleted = 0


	WHERE
		A.ClaimBatchId = @ClaimBatchId AND A.CategoryId = @TransCategoryId
		--and a.ServiceId = 11
		--AND A.billno = 'CCR2248837'


		SELECT SUM(Net) FROM #TMPX

	--SELECT BILLNO, SFDA FROM #TMPX
	--GROUP BY BILLNO, SFDA
	--HAVING COUNT(SFDA) > 2


DROP TABLE #TMP_COMPANYMAP
DROP TABLE #MIDHEADER
DROP TABLE #OPBILL
DROP TABLE #TMPX

/*
	SELECT * FROM ARCOMPANYBILLDETAIL  WHERE BILLNO = 'CCR2249087'

	P12PIASC1C	PIASCLEDINE 300MG CAPSULE X 15
P12PIASC1C	PIASCLEDINE 300MG CAPSULE X 15
P12ROFEN1G	ROFENAC GEL 50MG TUBE
P12DIVID1C	DIVIDO 75MG CAPSULE  X 20
P04TILAX2T	TILAX 4MG TABLET  X 30
*/