INSERT INTO aradmin.tmp_moh_opmapping
select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.test i on a.sgh_id = i.id
where a.opserviceid = 3
union all
select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.Surgery i on a.sgh_id = i.id
where a.opserviceid = 4
union all
select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.PtProcedure i on a.sgh_id = i.id
where a.opserviceid = 5
union all

select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.CathProcedure i on a.sgh_id = i.id
where a.opserviceid = 6
union all

select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.OtherProcedures i on a.sgh_id = i.id
where a.opserviceid = 7

union all

select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.BloodCrossMatch i on a.sgh_id = i.id
where a.opserviceid = 13

union all

select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.BloodDonationMaster i on a.sgh_id = i.id
where a.opserviceid = 16

union all

select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.BBOtherProcedures i on a.sgh_id = i.id
where a.opserviceid = 16

 union all

select
	a.ipserviceid as ipserviceid,
	a.opserviceid as opserviceid,
	a.sgh_id as itemid, i.Code as sghcode,
	i.name as sghdescription,
	m.item_code as mohcode,
	m.item_description as mohdescription,
	m.cost_price as MohPrice, 
	m.code_type as MohType 
from [130.2.10.15].his.dbo.sgh_moh_service_mapping a
INNER join [130.2.10.15].his.dbo.moh_services m on a.moh_id = m.id
INNER join dbo.BloodIssueMaster i on a.sgh_id = i.id
where a.opserviceid = 18




--SELECT 

--* 

--FROM aradmin.tmp_moh_opmapping
-- select * from [130.2.10.15].his.dbo.moh_services