declare @counter int = 1, @rcount int = 0, @id int = 0

declare @cat as table
(
	id int identity(1,1),
	categoryid int
)

insert into @cat (categoryid)
select id from category where id  51

select @rcount = count(*) from @cat

while (@counter <= @rcount)
begin

	select @id = categoryid from @cat where id = @counter

	insert into aradmin.arpackagemaster
	(
		code, name, MinNoOfDays, MaxNoOfDays, Amount,
		SecondProcAmount, DepartmentId, 
		CategoryId, CompanyId, GradeId,
		StartDateTime, OperatorId, Deleted
	)

	select 
		code, name, 1, days, amount, 0, departmentid,
		@id, 0, 0,
		GETDATE(), 1, 0
	from ARADMIN.pd_temp_tbl

	set @counter = @counter + 1
end