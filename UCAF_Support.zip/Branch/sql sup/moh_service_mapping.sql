select * from [130.2.10.15].his.dbo.moh_services


select * from OPBService where id IN(
select distinct opserviceid from [130.2.10.15].his.dbo.sgh_moh_service_mapping
)