
select SGH_CODE, SGH_Code_Description, MOH_ItemCode, 
MOH_Price, SFDA_Code from MOHInv_CodeMappings
where SGH_Code in (
select SGH_Code from MOHInv_CodeMappings 
where deleted = 0
group by SGH_Code
having count(SGH_Code) > 1
) order by SGH_Code

