drop table aradmin.tmp_moh_opmapping

create table aradmin.tmp_moh_opmapping
(
	Id int primary key Identity(1,1),
	ServiceId INT NOT NULL,
	ItemId INT NOT NULL,
	SghCode VARCHAR(1024) NOT NULL,
	SghDescription VARCHAR(1024) NOT NULL,
	MohCode VARCHAR(1024) NOT NULL,
	MohDescription VARCHAR(1024) NOT NULL,
	MohPrice NUMERIC(18,4) NOT NULL,
	MohType VARCHAR(1024) NULL,
)