--select * from Category where id = 25


-----------------------------------------------------------------------------------------------------------------------
-- VIP
-----------------------------------------------------------------------------------------------------------------------
-- NON PH

select * from IPCompanyServiceDiscount 
-- update IPCompanyServiceDiscount set percentage = 5
where gradeid in (select Id from grade where categoryid = 25 and gradename like '%VIP%')
and serviceid NOT IN (5, 37) and Percentage > 0


select * from IPCompanyDeptDiscount 
-- update IPCompanyDeptDiscount set percentage = 5
where gradeid in (select Id from grade where categoryid = 25 and gradename like '%VIP%')
and serviceid NOT IN (5, 37) and Percentage > 0


select * from IPCompanyItemDiscount 
-- update IPCompanyItemDiscount set percentage = 5
where gradeid in (select Id from grade where categoryid = 25 and gradename like '%VIP%')
and serviceid NOT IN (5, 37) and Percentage > 0


-- PH

select  * from IPCompanyServiceDiscount 
-- update IPCompanyServiceDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and gradename like '%VIP%')
and serviceid IN (5, 37) and Percentage > 0


select * from IPCompanyDeptDiscount 
-- update IPCompanyDeptDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and gradename like '%VIP%')
and serviceid  IN (5, 37) and Percentage > 0


select * from IPCompanyItemDiscount
-- update IPCompanyItemDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and gradename like '%VIP%')
and serviceid  IN (5, 37) and Percentage > 0

-----------------------------------------------------------------------------------------------------------------------
-- A
-----------------------------------------------------------------------------------------------------------------------
-- NON PH

select * from IPCompanyServiceDiscount 
-- update IPCompanyServiceDiscount set percentage = 10
where gradeid in (select Id from grade where categoryid = 25 and name like '%A%')
and serviceid NOT IN (5, 37) and Percentage > 0


select * from IPCompanyDeptDiscount 
-- update IPCompanyDeptDiscount set percentage = 10
where gradeid in (select Id from grade where categoryid = 25 and name like '%A%')
and serviceid NOT IN (5, 37) and Percentage > 0


select * from IPCompanyItemDiscount 
-- update IPCompanyItemDiscount set percentage = 10
where gradeid in (select Id from grade where categoryid = 25 and name like '%A%')
and serviceid NOT IN (5, 37) and Percentage > 0


-- PH

select  * from IPCompanyServiceDiscount 
-- update IPCompanyServiceDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and name like '%A%')
and serviceid IN (5, 37) and Percentage > 0


select * from IPCompanyDeptDiscount 
-- update IPCompanyDeptDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and name like '%A%')
and serviceid  IN (5, 37) and Percentage > 0


select * from IPCompanyItemDiscount
-- update IPCompanyItemDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and name like '%A%')
and serviceid  IN (5, 37) and Percentage > 0


-----------------------------------------------------------------------------------------------------------------------
-- B
-----------------------------------------------------------------------------------------------------------------------
-- NON PH

select * from IPCompanyServiceDiscount 
-- update IPCompanyServiceDiscount set percentage = 15
where gradeid in (select Id from grade where categoryid = 25 and name like '%B%')
and serviceid NOT IN (5, 37) and Percentage > 0


select * from IPCompanyDeptDiscount 
-- update IPCompanyDeptDiscount set percentage = 15
where gradeid in (select Id from grade where categoryid = 25 and name like '%B%')
and serviceid NOT IN (5, 37) and Percentage > 0


select * from IPCompanyItemDiscount 
-- update IPCompanyItemDiscount set percentage = 15
where gradeid in (select Id from grade where categoryid = 25 and name like '%B%')
and serviceid NOT IN (5, 37) and Percentage > 0


-- PH

select  * from IPCompanyServiceDiscount 
-- update IPCompanyServiceDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and name like '%B%')
and serviceid IN (5, 37) and Percentage > 0


select * from IPCompanyDeptDiscount 
-- update IPCompanyDeptDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and name like '%B%')
and serviceid  IN (5, 37) and Percentage > 0


select * from IPCompanyItemDiscount
-- update IPCompanyItemDiscount set percentage = 3
where gradeid in (select Id from grade where categoryid = 25 and name like '%B%')
and serviceid  IN (5, 37) and Percentage > 0
