
--UPDATE A
--	SET A.Itemid = B.Id
--FROM RCM.TMP_NCCI_MAP A
--INNER JOIN RCM.All_OPItems B ON A.ServiceId = B.ServiceId ANd A.HISCode = B.Code

/*

select distinct serviceid  from RCM.TMP_NCCI_MAP

UPDATE RCM.TMP_NCCI_MAP SET ItemId = 1 WHERE ItemId = 0

SELECT * FROM RCM.TMP_NCCI_MAP WHERE HISCode = 'FMORDZ9998'


select * from item where itemcode = 'OldP15ACCUC6+'

select * from surgery where code = 'FMNEU-0101'

select * from RCM.All_IPItems where code = 'FMORDZ9998'

select * from ipbservice where id = 11

SELECT TOP 1 * FROM CompanyProceduresMapping

select * from category order by code
*/

--INSERT INTO CompanyProceduresMapping

--SELECT
--	A.ServiceId, 0, 91, A.ItemId, A.NCCIAgreedCodes, A.HISDescription, 0, 1, A.HISCode
--FROM (
--SELECT
--	A.*, B.ItemID AS ExistItemId
--FROM RCM.TMP_NCCI_MAP A
--LEFT JOIN (
--	SELECT * FROM CompanyProceduresMapping A
--	WHERE CategoryId = 91
--	and ipop = 1
--) B ON A.ServiceId = B.ServiceID AND A.ItemId = B.ItemID
--) A 
--WHERE A.ExistItemId IS NULL

-- select * from opbservice where deleted = 0
-- delete from CompanyProceduresMapping where categoryid IN (24, 91) and ipop = 2 and serviceid in(1,6,10,13)


-- OP



--UPDATE A
--	SET A.Itemid = B.Id
----SELECT A.* 
--FROM RCM.TMP_NCCI_MAP_OP A
--INNER JOIN RCM.All_OPItems B ON A.ServiceId = B.ServiceId ANd A.HISCode = B.Code


--INSERT INTO CompanyProceduresMapping

--SELECT
--	A.ServiceId, 0, 91, A.ItemId, A.NCCIAgreedCodes, A.HISDescription, 0, 2, A.HISCode
--FROM (
--SELECT
--	A.*, B.ItemID AS ExistItemId
--FROM RCM.TMP_NCCI_MAP_OP A
--LEFT JOIN (
--	SELECT * FROM CompanyProceduresMapping A
--	WHERE CategoryId = 91
--	and ipop = 2
--) B ON A.ServiceId = B.ServiceID AND A.ItemId = B.ItemID
--) A 
--WHERE A.ExistItemId IS NULL


