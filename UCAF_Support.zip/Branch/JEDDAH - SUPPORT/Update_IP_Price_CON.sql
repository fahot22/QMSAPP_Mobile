
select * from ARIPBillItemDetail 
--update ARIPBillItemDetail set editprice = 130
where itemcode = 'CON'
	and billno in (select billno from aripbill where categoryid = 11 and InvoiceDateTime >= '01-MAR-2021'
)