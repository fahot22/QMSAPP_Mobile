--UPDATE a
--	SET a.opamount = b.NET
--FROM ARCompanyLetter a
--INNER JOIN
--(
--	select X.Id, X.CompanyId, SUM(X.CL) AS CL, SUM(X.NET) AS NET
--	FROM (
--	select A.id, A.companyid, ISNULL(A.OPAmount,0) CL,
--		ISNULL(SUM(b.billamount - b.Discount - b.PaidAmount), 0) AS NET
--	from ARCompanyLetter a
--	left join dbo.ArCompanyBillDetail b 
--	ON A.id = b.CompanyLetterId and b.BillDateTime >= '01-JAN-2021' and b.BillDateTime < '01-FEB-2021'
--	where a.prefix like '%01/21%' --and a.categoryid = 
--	group by A.companyid, A.OPAmount, A.id
--	) X 
--	GROUP BY X.Id, X.CompanyId
--) b on a.id = b.id and a.companyid = b.companyid
--where a.prefix like '%01/21%'



--UPDATE a
--	SET a.ipamount = b.NET
--FROM ARCompanyLetter a
--INNER JOIN
--(

--	select X.Id, X.CompanyId, SUM(X.CL) AS CL, SUM(X.NET) AS NET
--	FROM (
--	select A.id, A.companyid, ISNULL(A.IPAmount,0) CL,
--		ISNULL(
--		SUM((b.editprice * b.EditQuantity) - (b.Discount * b.EditQuantity) - (b.DeductableAmount * b.EditQuantity)), 
--		0) AS NET
--	from ARCompanyLetter a
--	left join dbo.ARIPBillItemDetail b 
--	left join dbo.aripbill c on b.billno = c.BillNo
--	ON A.id = c.CompanyLetterId and c.InvoiceDateTime >= '01-JAN-2021' and c.InvoiceDateTime < '01-FEB-2021'
--	where a.prefix like '%01/21%' --and a.categoryid = 
--	group by A.companyid, A.IPAmount, A.id
--	) X 
--	GROUP BY X.Id, X.CompanyId


--) b on a.id = b.id and a.companyid = b.companyid
--where a.prefix like '%01/21%'





