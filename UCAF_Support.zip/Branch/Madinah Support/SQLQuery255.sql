select SUM(opamount) from ARCompanyLetter where id in (

select distinct CompanyLetterId
from ArCompanyBillDetail 
where categoryid = 55 and HasCompanyLetter = 1
and BillDateTime >= '01-JAN-2021' and BillDateTime < '01-FEB-2021'


)



select SUM(Billamount - Discount - PaidAmount)
from ArCompanyBillDetail 
where categoryid = 55 and HasCompanyLetter = 1
and BillDateTime >= '01-JAN-2021' and BillDateTime < '01-FEB-2021'
and BillAmount <> 0

select * from arcompanyletter where id in (

select distinct b.id  --SUM(Billamount - Discount - PaidAmount) 
from ArCompanyBillDetail A
LEFT JOIN ARCompanyLetter B ON a.CompanyLetterId = B.id
WHERE A.BillAmount <> 0
and b.prefix like '%01/21%'
and A.CategoryId = 55
--and A.BillDateTime >= '01-JAN-2021' and A.BillDateTime < '01-FEB-2021'
) order by datetime


select * from aradmin.CL_Generation_Log where companyid = 31127

select * from ArCompanyBillDetail where BillDateTime <= '01-JAN-2021'

select distinct opbillid from ArCompanyBillDetail where companyletterid = 103741

select * from ARCompanyLetterDetail where CompanyLetterID = 103741


select * from ArCompanyBillDetail A
INNER JOIN dbo.arcompanyletter B ON A.CompanyLetterId = B.id
where  b.prefix like '%01/21%'
and a.CompanyId <> b.companyid








