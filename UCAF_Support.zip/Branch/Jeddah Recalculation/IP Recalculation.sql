


/*

	EXEC ARADMIN.RECALCULATE_FULL_IP 363852, 140, '01-MAR-2021', '31-MAR-2021'
	EXEC ARADMIN.RECALCULATE_FULL_IP 363856, 140, '01-MAR-2021', '31-MAR-2021'
	EXEC ARADMIN.RECALCULATE_FULL_IP 364016, 140, '01-MAR-2021', '31-MAR-2021'
	

	140

	select billno from aripbill A  
	where  A.BillDate >= '01-MAR-2021'  and A.BillDate < dateadd(M,1,'01-MAR-2021') 
	AND A.CategoryId = 79

*/
-- select * from aripbillitemdetail where billno = 363891 and editprice = 0

-- SELECT Id, Code,  Name, TariffId, ValidTill FROM CATEGORY WHERE id in (79, 51, 25, 72, 70, 78) order by id