select * from category where id = 79


select * from opcompanydeptdiscount where categoryid = 79 and serviceid in (3,7) and percentage > 0
select * from opcompanyitemdiscount where categoryid = 79 and serviceid in (3,7) and percentage > 0


select * from opcompanydeptdiscount where categoryid = 79 and serviceid in (3,7) and percentage > 0
select * from opcompanyitemdiscount where categoryid = 79 and serviceid in (3,7) and percentage > 0