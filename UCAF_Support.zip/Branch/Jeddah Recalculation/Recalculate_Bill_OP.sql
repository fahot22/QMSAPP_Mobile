DECLARE @TariffID INT = 72, @CategoryID INT = 72,
		@Date DATETIME = '01-MAR-2021'

SELECT DISTINCT GradeId
INTO #TMP_BILLGRADE
FROM ARCompanyBillDetail WHERE CategoryId = @CategoryID
AND BillDateTime >= @Date AND BillDateTime < DATEADD(M,1,@Date)

SELECT Id, FixedConCharges 
INTO #TMP_CONPRICE
FROM GRADE WHERE ID IN (SELECT GradeId FROM #TMP_BILLGRADE)

-- select id from #TMP_CONPRICE 
-- group by id
-- having count(id) > 1

--RETURN
-- SELECT Id, Code,  Name, TariffId, ValidTill FROM CATEGORY WHERE id in (79, 51, 25, 72, 70, 78) order by id
-- SELECT * FROM CATEGORY order by code
-- SELECT * FROM OPBService where deleted = 0
-- select * from tariff where id = 89
-- update CATEGORY set tariffid = 72 WHERE id = 78
-- select distinct tariffid from company where categoryid = 79

SELECT A.*
INTO #TMP_OPPRICE
FROM (
SELECT 3 AS ServiceID, ID AS Itemid, price FROM OP_P_72_Test WHERE Price > 0
UNION ALL
SELECT 5 AS ServiceID, ID AS Itemid, Price FROM OP_P_72_PTProcedure WHERE Price > 0
UNION ALL
SELECT 7 AS ServiceID, ID AS Itemid, Price FROM OP_P_72_OtherProcedure WHERE Price > 0
UNION ALL
SELECT 14 AS ServiceID, ID AS Itemid, Price FROM OP_P_72_FoodItem WHERE Price > 0
) A


--SELECT P.Price * A.Quantity as NewPrice, A.billAMount as OldPrice, A.ItemCode,A. ItemName, *  
--FROM ARCompanyBillDetail A
--	INNER JOIN #TMP_OPPRICE P ON A.ServiceId = P.ServiceID AND A.ItemId = P.Itemid
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11,2)
--AND (P.Price - A.billAMount) < -50

--SELECT P.FixedConCharges as NEWPRICE, A.billAMount as oldprice, *  
--FROM ARCompanyBillDetail A
--	INNER JOIN #TMP_CONPRICE P ON A.GradeId = P.ID 
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId IN (2)

--SELECT 
--((dbo.get_item_discount_op_invoice_serviceonly
--	(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.itemid, A.billamount, A.departmentid)
--) / 100.00) * A.BillAmount AS NewDisc, 
-- A.discount as oldiscount, A.*  
--FROM ARCompanyBillDetail A
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11,2) AND A.Discount > 0


UPDATE A
	SET BillAmount = P.price * A.Quantity
FROM ARCompanyBillDetail A
INNER JOIN #TMP_OPPRICE P ON A.ServiceId = P.ServiceID AND A.ItemId = P.Itemid AND P.price > 0
WHERE A.CategoryId = @CategoryID
AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
AND A.ServiceId NOT IN (11,2)

PRINT 'OTHER SERVICES DONE'

UPDATE A
	SET BillAmount = P.FixedConCharges
FROM ARCompanyBillDetail A
INNER JOIN #TMP_CONPRICE P ON A.GradeId = P.ID 
WHERE A.CategoryId = @CategoryID
AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
AND A.ServiceId IN (2)

PRINT 'CONSULTATION DONE'

-- discounts

UPDATE A
	SET Discount = ((dbo.get_item_discount_op_invoice_serviceonly(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.itemid, A.billamount, A.departmentid)) / 100.00) * A.BillAmount
FROM ARCompanyBillDetail A
WHERE A.CategoryId = @CategoryID
AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)

UPDATE A
	SET Balance = BillAmount - Discount - PaidAmount
FROM ARCompanyBillDetail A
WHERE A.CategoryId = @CategoryID
AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)

PRINT 'DISCOUNTS DONE'

DROP TABLE #TMP_BILLGRADE
DROP TABLE #TMP_OPPRICE
DROP TABLE #TMP_CONPRICE

