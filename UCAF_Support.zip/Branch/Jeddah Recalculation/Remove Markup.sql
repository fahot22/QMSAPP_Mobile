
--select * from category order by code  

--25, 51, 79


select * from IpCompanyServiceMarkUp where categoryid in (25, 51, 79)
select * from IpCompanyDeptMarkUp where categoryid in (25, 51, 79)
select * from IpCompanyItemMarkUp where categoryid in (25, 51, 79)


select * from OpCompanyServiceMarkUp where categoryid in (25, 51, 79)
select * from OpCompanyDeptMarkUp where categoryid in (25, 51, 79)
select * from OpCompanyItemMarkUp where categoryid in (25, 51, 79)