DECLARE @Date DATETIME = '01-MAR-2021'

DECLARE @StartDateTime DATETIME
DECLARE @EndDateTime DATETIME

DECLARE @TMP_THISWEEK AS TABLE(
	DATE DATETIME
)

DECLARE @TMP_LASTWEEK AS TABLE(
	DATE DATETIME
)
 
WITH DateRange(DateData) AS 
(
    SELECT @Date as Date
    UNION ALL
    SELECT DATEADD(d,1,DateData)
    FROM DateRange 
    WHERE DateData < DATEADD(D,6,@Date)
)
INSERT INTO @TMP_THISWEEK
SELECT DateData
FROM DateRange
OPTION (MAXRECURSION 0)


WITH DateRangeX(DateDataX) AS 
(
    SELECT DATEADD(D,-7,@Date) as Date
    UNION ALL
    SELECT DATEADD(d,1,DateDataX)
    FROM DateRangeX
    WHERE DateDataX < DATEADD(D,6,(DATEADD(D,-7,@Date)))
)

INSERT INTO @TMP_LASTWEEK
SELECT DateDataX
FROM DateRangeX
OPTION (MAXRECURSION 0)



SELECT
	1 AS Type,
	CONVERT(DATE,A.DATE) AS Date, 
	DATENAME(WEEKDAY, CONVERT(DATE,A.DATE)) AS DName,
	B.GrossAmount
FROM @TMP_THISWEEK A LEFT JOIN (

	SELECT CONVERT(DATE, Billdatetime) AS BillDate,
		SUM(BillAmount) AS GrossAmount
	FROM dbo.OPCompanyBillDetail
	WHERE Billdatetime >= @Date AND Billdatetime < DATEADD(D, 7, @Date)
	GROUP BY CONVERT(DATE, Billdatetime)
) B ON CONVERT(DATE,A.DATE) = B.BillDate


SELECT
	2 AS Type,
	CONVERT(DATE,A.DATE) AS Date, 
	DATENAME(WEEKDAY, CONVERT(DATE,A.DATE)) AS DName,
	B.GrossAmount
FROM @TMP_LASTWEEK A LEFT JOIN (

	SELECT CONVERT(DATE, Billdatetime) AS BillDate,
		SUM(BillAmount) AS GrossAmount
	FROM dbo.OPCompanyBillDetail
	WHERE Billdatetime >= DATEADD(D,-7,@Date) AND Billdatetime < DATEADD(D, 7, DATEADD(D,-7,@Date))
	GROUP BY CONVERT(DATE, Billdatetime)
) B ON CONVERT(DATE,A.DATE) = B.BillDate