SELECT * FROM OPCompanyServiceDiscount where categoryid = 78
SELECT * FROM opcompanydeptdiscount where categoryid = 78
SELECT * FROM opcompanyitemdiscount where categoryid = 78

SELECT * FROM iPCompanyServiceDiscount where categoryid = 78
SELECT * FROM ipcompanydeptdiscount where categoryid = 78
SELECT * FROM ipcompanyitemdiscount where categoryid = 78

/*

select * from tariff where id = 4
update company set TariffID = 4 where categoryid = 78

*/