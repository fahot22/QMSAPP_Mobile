/*
	Service Level
*/
SELECT * FROM IPCompanyServiceDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS A%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%VIP%'
) AND ServiceId NOT IN (11)

SELECT * FROM IPCompanyServiceDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS A%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%VIP%'
) AND ServiceId  IN (11)

-- B AND C
SELECT * FROM IPCompanyServiceDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS B%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS C%'
) AND ServiceId NOT IN (11)

SELECT * FROM IPCompanyServiceDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS B%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS C%'
) AND ServiceId IN(11)

/*
	Department Level
*/

SELECT * FROM IPCompanyDeptDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS A%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%VIP%'
) AND ServiceId NOT IN (11)

SELECT * FROM IPCompanyDeptDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS A%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%VIP%'
) AND ServiceId  IN (11)

-- B AND C
SELECT * FROM IPCompanyDeptDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS B%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS C%'
) AND ServiceId NOT IN (11)

SELECT * FROM IPCompanyDeptDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS B%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS C%'
) AND ServiceId IN(11)

/*
	Item Level
*/

SELECT * FROM IPCompanyItemDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS A%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%VIP%'
) AND ServiceId NOT IN (11)

SELECT * FROM IPCompanyItemDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS A%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%VIP%'
) AND ServiceId  IN (11)

-- B AND C
SELECT * FROM IPCompanyItemDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS B%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS C%'
) AND ServiceId NOT IN (11)

SELECT * FROM IPCompanyItemDiscount WHERE CategoryID = 78
AND GradeId IN (
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS B%'
	UNION ALL
	select id from grade where categoryid = 78 and LTRIM(RTRIM(GRADENAME)) LIKE '%CLASS C%'
) AND ServiceId IN(11)