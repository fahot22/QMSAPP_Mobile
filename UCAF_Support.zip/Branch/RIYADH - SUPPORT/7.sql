--select distinct BedTypeid from master.IPPrice where TariffId = 23
--and IpbServiceId = 13 order by BedTypeid
DECLARE @Counter INT = 1, @RCount INT = 0, @SelectedBedTypeId INT = 0, 
		@TariffId INT = 23, @IPBServiceId INT = 20

DECLARE @TMP_BED AS TABLE(
	Id INT PRIMARY KEY IDENTITY(1,1),
	BedTypeId INT 
)

INSERT INTO @TMP_BED (BedTypeId)
select distinct BedTypeid from master.IPPrice where TariffId = 23
and IpbServiceId = 13 order by BedTypeid

SELECT @RCount = COUNT(*) FROM @TMP_BED


WHILE @Counter <= @RCount
BEGIN
	SELECT @SelectedBedTypeId = BedTypeId FROM @TMP_BED WHERE Id = @Counter
	
	INSERT INTO master.IPPrice
	select @TariffId, @SelectedBedTypeId, @IPBServiceId, B.Id As ItemId, A.Price,
	0, GETDATE(), 1, NULL, NULL, NULL, NULL, 0, GETDATE(), NULL
	from rcm.TMP_IP_PRICE A
	inner join rcm.All_IPItems B
	ON A.ItemCode = B.Code AND B.ServiceId = @IPBServiceId
	and b.id not in 
	(
		select itemid from master.IPPrice where TariffId = @TariffId and IpbServiceId = @IPBServiceId
		and BedTypeId = @SelectedBedTypeId
	)
	PRINT @SelectedBedTypeId
	SET @Counter = @Counter + 1
END


--SELECT * FROM master.IPPrice_TMP
--SELECT top 1 * FROM master.IPPrice

/*
	EXEC ARADMIN.[RECALCULATE_FULL_IP_SERVICEWISE] 
213615, 23, 13, '01-MAY-2021', '31-MAY-2021'
*/
