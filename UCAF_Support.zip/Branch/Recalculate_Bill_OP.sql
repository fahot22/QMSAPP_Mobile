DECLARE @TariffID INT = 135, @CategoryID INT = 11,
		@Date DATETIME = '01-JAN-2022'


--SELECT *
--INTO #ARCompanyBillDetail_BUPA_JAN2022
--FROM ARCompanyBillDetail WHERE CategoryId = @CategoryID
--AND BillDateTime >= @Date AND BillDateTime < DATEADD(M,1,@Date)

SELECT DISTINCT GradeId
INTO #TMP_BILLGRADE
FROM ARCompanyBillDetail WHERE CategoryId = @CategoryID
AND BillDateTime >= @Date AND BillDateTime < DATEADD(M,1,@Date)

SELECT Id, FixedConCharges 
INTO #TMP_CONPRICE
FROM GRADE WHERE ID IN (SELECT GradeId FROM #TMP_BILLGRADE)

SELECT A.*
INTO #TMP_OPPRICE
FROM (
SELECT 3 AS ServiceID, ID AS Itemid, price FROM OP_P_135_Test WHERE Price > 0
UNION ALL
SELECT 5 AS ServiceID, ID AS Itemid, Price FROM OP_P_135_PTProcedure WHERE Price > 0
UNION ALL
SELECT 7 AS ServiceID, ID AS Itemid, Price FROM OP_P_135_OtherProcedure WHERE Price > 0
UNION ALL
SELECT 14 AS ServiceID, ID AS Itemid, Price FROM OP_P_135_FoodItem WHERE Price > 0
) A

 /* VIEW */

--SELECT P.Price * A.Quantity as NewPrice, A.billAMount as OldPrice, A.ItemCode, A. ItemName, *  
--FROM ARCompanyBillDetail A
--	INNER JOIN #TMP_OPPRICE P ON A.ServiceId = P.ServiceID AND A.ItemId = P.Itemid
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11,2)
--AND (P.Price * A.Quantity) <> A.BillAmount

--SELECT P.FixedConCharges as NEWPRICE, A.billAMount as oldprice, *  
--FROM ARCompanyBillDetail A
--	INNER JOIN #TMP_CONPRICE P ON A.GradeId = P.ID 
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId IN (2)
--AND P.FixedConCharges <> A.BillAmount

--SELECT 
--(dbo.get_CompanyDiscount_OP(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.departmentid, A.itemid) / 100.0 ) * A.BillAmount AS NewDisc, 
-- A.discount as oldiscount, A.*  
--FROM ARCompanyBillDetail A
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11,2) AND A.Discount > 0


/* 1. OTHER SERVICE */

--UPDATE A
--	SET BillAmount = P.price * A.Quantity
--FROM ARCompanyBillDetail A
--INNER JOIN #TMP_OPPRICE P ON A.ServiceId = P.ServiceID AND A.ItemId = P.Itemid AND P.price > 0
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11, 2)
--AND (P.Price * A.Quantity) <> A.BillAmount

--PRINT 'OTHER SERVICES DONE'

/* 2. CONSULTATION */

--UPDATE A
--	SET BillAmount = P.FixedConCharges
--FROM ARCompanyBillDetail A
--INNER JOIN #TMP_CONPRICE P ON A.GradeId = P.ID 
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId IN (2)
--AND P.FixedConCharges <> A.BillAmount

--PRINT 'CONSULTATION DONE'

/* 3. DISCOUNTS */

--UPDATE A
--	SET Discount = (dbo.get_CompanyDiscount_OP(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.departmentid, A.itemid) / 100.0 ) * A.BillAmount
--FROM ARCompanyBillDetail A
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11) AND A.Discount > 0

--PRINT 'DISCOUNT DONE'

/* 4. BALANCE */

--UPDATE A
--	SET Balance = BillAmount - Discount - PaidAmount
--FROM ARCompanyBillDetail A
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11) 

--PRINT 'BALANCE DONE'

DROP TABLE #TMP_BILLGRADE
DROP TABLE #TMP_OPPRICE
DROP TABLE #TMP_CONPRICE

/*
-- select id from #TMP_CONPRICE 
-- group by id
-- having count(id) > 1

--RETURN
-- SELECT Id, Code,  Name, TariffId, ValidTill FROM CATEGORY WHERE id in (79, 51, 25, 72, 70, 78) order by id
-- SELECT * FROM CATEGORY order by code
-- SELECT * FROM OPBService where deleted = 0
-- select * from tariff where id = 89
-- update CATEGORY set tariffid = 140 WHERE id = 78
-- select distinct tariffid from company where categoryid = 79


*/

