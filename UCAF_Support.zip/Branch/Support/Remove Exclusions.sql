--select * from OPCompanyItemServices

--select * from OPCompanyDeptServices where serviceid = 11 and DepartmentId = 88

--select * from department 

--select * from item where Name LIKE '%VAXI%'


--select * from PharmacyItem where Name LIKE '%PREVE%'

select * from OPCompanyItemServices 
where 
serviceid = 11
and
itemid in(
SELECT id 
FROM PharmacyItem 
WHERE ItemCode IN (
'P11ENGER1J',
'P11ORALP4J',
'P11ENGER2J',         
'P11PRIOR2J',
'P11HAVRI1J',
'P11ACTAC1J',
'P11INFAN1J',
'P11INFAN2J',
'P11VARIL1J',
'P11ROUVA3J',
'P11PEDIA1J',
'P11PRIOR3J',
'P11INFAN3J',
'P11PREVE2J',
'P11ROTAR1J',
'P11AVAXI2J',
'P11TRIPA1J',
'P11MENAC1J',
'P11VAXIG1J',
'P11ARAPE1J',
'P11HEXAM1J',
'P11ARAME1J',
'P11MEASL1J'
)
)