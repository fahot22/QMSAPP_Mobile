
SELECT COUNT(A.InvoiceId) AS OPClaim, SUM(A.Net) AS OPAmount, A.CategoryId,
(
	SELECT SUM(OPVAT) AS VAT 
	FROM dbo.ARCompanyLetter 
	WHERE CategoryId = 11 AND (0 = 0 OR CompanyID = 0) AND CONVERT(DATE, CoveringLetterDate) >= '01-JAN-2021' AND  CONVERT(DATE, CoveringLetterDate) < '01-FEB-2021'
) AS VAT
FROM (
	SELECT InvoiceId, A.CategoryId, SUM(BillAmount - PaidAmount - Discount) AS Net
	FROM dbo.ArCompanyBillDetail A
	WHERE A.HasCompanyLetter = 1
	AND CONVERT(DATE,BillDateTime) >= '01-JAN-2021' AND  CONVERT(DATE,BillDateTime) < '01-FEB-2021'
	AND A.CategoryId = 11 AND (0 = 0 OR A.CompanyID = 0)
	GROUP BY A.InvoiceId, A.CategoryId
) A
GROUP BY A.CategoryId


SELECT COUNT(A.SlNo) AS OPClaim, A.CategoryId  

FROM (
SELECT A.SlNo, A.CategoryId 
FROM dbo.ARIPBillItemDetail A
INNER JOIN dbo.ARIPBill B ON A.BillNo = B.BillNo
WHERE B.HasCompanyLetter = 1
	AND CONVERT(DATE, B.InvoiceDateTime) >= '01-JAN-2021' AND  CONVERT(DATE, B.InvoiceDateTime) < '01-FEB-2021'
	AND B.CategoryId = 11 AND (0 = 0 OR B.CompanyID = 0) 
	AND B.EditBillAmount > 0.01
GROUP BY B.SlNo, B.CategoryId 
) A
GROUP BY A.CategoryID
