-- SELECT * FROM ARADMIN.DHS_ClaimBAtch

DECLARE @ClaimBatchId INT = 33

DELETE FROM ARADMIN.DHS_Mid_OPBill_Diagnosis
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Lab
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Rad
WHERE ProIdClaim IN 
(
	SELECT Id
	FROM ARADMIN.DHS_Mid_OPBill_Header 
		WHERE ClaimBatchId = @ClaimBatchId
)

DELETE FROM ARADMIN.DHS_Mid_OPBill_Details
WHERE ClaimBatchId = @ClaimBatchId

DELETE FROM ARADMIN.DHS_Mid_OPBill_Header 
WHERE ClaimBatchId = @ClaimBatchId