DECLARE @CategoryId INT = 11,
		@FDate DATETIME = '01-FEB-2020',
		@TDate DATETIME = '01-MAR-2020',
		@CatName VARCHAR(50) = 'BUPA'

DELETE FROM DHSService_Details WHERE ProIdClaim IN(
	SELECT ProIdClaim  FROM DHSClaim_Header WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSLab_Details WHERE ProIdClaim IN(
	SELECT ProIdClaim FROM DHSClaim_Header WHERE CompanyCode = @CatName AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSRadiology_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

DELETE FROM DHSDiagnosis_Details
WHERE ProIdClaim IN(
	SELECT 
		ProIdClaim 
	FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
)

-- LAST



--DELETE
--FROM DHSClaim_Header
--	WHERE CompanyCode = @CatName
--AND BatchStartDate >= @FDate AND BatchEndDate < @TDate



-- SELECT DISTINCT CompanyCode FROM DHSClaim_Header WHERE BAtchStartDate >= '01-JAN-2020'
