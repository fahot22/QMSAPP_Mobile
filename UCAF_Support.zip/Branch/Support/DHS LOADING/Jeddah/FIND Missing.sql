DECLARE @ClaimBatchId INT = 33,
		@CategoryId INT = 84,
		@Date DATETIME = '01-AUG-2019',
		@TDate DATETIME

SET		@TDate = DATEADD(M,1,@Date)


SELECT OPBILLID 
INTO #Tmp_OPBILL
FROM arcompanybilldetail 
WHERE categoryid = @CategoryId
AND BillDateTime >= @Date AND BillDateTime < @TDate


SELECT opbillid FROM ARADMIN.DHS_OPBill
WHERE ClaimBatchId = @ClaimBatchId
AND OPBillId NOT IN (SELECT OPBILLID FROM #Tmp_OPBILL)


SELECT * FROM #Tmp_OPBILL WHERE Opbillid NOT IN (SELECT opbillid FROM ARADMIN.DHS_OPBill
WHERE ClaimBatchId = @ClaimBatchId)



SELECT SUM(BillAmount - Discount - PaidAmount)  AS CL
FROM arcompanybilldetail 
WHERE categoryid = @CategoryId
AND BillDateTime >= @Date AND BillDateTime < @TDate



 
DROP TABLE #Tmp_OPBILL