/*

	DECLARE @ClaimBatchId INT = 36
	SELECT
		SUM(TotalNetAmount)  AS Net
	
	FROM ARADMIN.DHS_Mid_OPBill_Header WHERE ClaimBatchId = @ClaimBatchId

	SELECT 
			SUM(NetAmount)  AS Net, SUM(NetVatAmount) AS VAT
	FROM ARADMIN.DHS_Mid_OPBill_Details   WHERE ClaimBatchId = @ClaimBatchId

*/

/*

SELECT
InvoiceId, DoctorId,AuthorityId, PatientNo, categoryid, companyid, gradeid
FROM ARADMIN.DHS_Mid_OPBill_Header
WHERE ClaimBatchId = 36
GROUP BY InvoiceId, DoctorId, AuthorityId, PatientNo, categoryid, companyid, gradeid
HAVING COUNT(*) > 1

*/


--SELECT * FROM ARADMIN.DHS_OPBill where authorityid = 4816603

--UPDATE ARADMIN.DHS_OPBill 
--SET InsuranceCardNo = '7558654'
--where authorityid = 4816603
