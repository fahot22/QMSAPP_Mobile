	DECLARE @ClaimCode VARCHAR(256) = 'BUPA-ARAMCO', @Date DATETIME = '01-10-2019', @TDate DATETIME
	
	SET @TDate = DATEADD(M,1,@Date)

	SELECT 
		 SUM(TotalNetAmount)
	FROM DHSClaim_Header WHERE BatchStartDate >= @Date and BatchEndDate < @TDate
	AND CompanyCode = @ClaimCode


	SELECT SUM(NetAmount) AS Net , SUM(NetVatAmount) AS Vat
	FROM DHSService_Details WHERE ProIdClaim In 
	(
		SELECT ProIdClaim
		FROM DHSClaim_Header WHERE BatchStartDate >= @Date and BatchEndDate < @TDate
		AND CompanyCode = @ClaimCode
	)
