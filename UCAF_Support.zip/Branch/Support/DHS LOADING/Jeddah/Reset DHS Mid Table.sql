DECLARE @CategoryId INT = 83,
		@FDate DATETIME = '01-AUG-2019',
		@TDate DATETIME = '01-SEP-2019',
		@CatName VARCHAR(50) = 'BUPA-ARAMCO'

--DELETE FROM DHSService_Details
--WHERE ProIdClaim IN(
--	SELECT 
--		ProIdClaim 
--	FROM DHSClaim_Header
--	WHERE CompanyCode = @CatName
--	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
--)

--DELETE FROM DHSLab_Details
--WHERE ProIdClaim IN(
--	SELECT 
--		ProIdClaim 
--	FROM DHSClaim_Header
--	WHERE CompanyCode = @CatName
--	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
--)

--DELETE FROM DHSRadiology_Details
--WHERE ProIdClaim IN(
--	SELECT 
--		ProIdClaim 
--	FROM DHSClaim_Header
--	WHERE CompanyCode = @CatName
--	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
--)

--DELETE FROM DHSDiagnosis_Details
--WHERE ProIdClaim IN(
--	SELECT 
--		ProIdClaim 
--	FROM DHSClaim_Header
--	WHERE CompanyCode = @CatName
--	AND BatchStartDate >= @FDate AND BatchEndDate < @TDate
--)

---- LAST

DELETE
FROM DHSClaim_Header
	WHERE CompanyCode = @CatName
AND BatchStartDate >= @FDate AND BatchEndDate < @TDate