SELECT
Sum(Z.ZeroToThirty) AS ZeroToThirty,
Sum(Z.ThirtyToSixty) AS ThirtyToSixty,
Sum(Z.SixtyAbove) AS SixtyAbove

FROM(
	SELECT
	
		CASE WHEN X.Duration <= 30 THEN 1 ELSE  0 END ZeroToThirty, 
		CASE WHEN X.Duration > 30 AND X.Duration <= 60   THEN 1 ELSE 0 END ThirtyToSixty,
		CASE WHEN X.Duration > 60   THEN 1 ELSE 0 END SixtyAbove,

	FROM
	(
		SELECT 
		DATEDIFF(MI, B.CreatedAt, A.ApprovalDateTime) AS Duration,
		
		from ucaf.OPApprovalRequest_Details A 
		INNER JOIN ucaf.OPApprovalRequest B ON A.ApprovalRequestId = B.Id
		WHERE 
			B.CreatedAt >= '01-JUN-2019' AND B.CreatedAt < '17-JUN-2019'
			AND A.ApprovalDateTime IS NOT NULL
		GROUP BY CONVERT(DATE, B.CreatedAt)
	) X

) Z