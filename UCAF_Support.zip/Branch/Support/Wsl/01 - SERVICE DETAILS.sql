
DECLARE @FromDate DATETIME = '01-JAN-2020', @ToDate DATETIME = '01-FEB-2020',
		@xCatID INT = 24, @TMPVAT NUMERIC(18,2) = 0.05


SELECT 
	--CONVERT(VARCHAR, J.CounterX) + 
	
	j.InvoiceNo AS InvoiceNo,
	J.ServiceCode, J.ServiceDate, J.ServiceDesc,                 
	(J.UnitServicePrice)  , J.UnitServiceType,                                              
	(J.Qty) , J.ToothNo, (J.TotServiceGrsAmt) ,                                            
    (J.TotServiceDisc) ,  (J.TotServicePatShare) ,
	(J.TotServiceNetAmt) , 
	J.CompanyVATRate, 
	(J.CompanyVAT) ,
	J.PatientVATRate,
	(J.PatientVAT)
FROM(
	SELECT 
	--ROW_NUMBER() OVER (ORDER BY X.InvoiceNo) AS CounterX,
	X.InvoiceNo, X.ServiceCode, X.ServiceDate, X.ServiceDesc,                                        
	SUM(X.UnitServicePrice) AS UnitServicePrice , X.UnitServiceType,                                              
	SUM(X.Qty)  AS Qty, X.ToothNo, SUM(X.TotServiceGrsAmt)  AS TotServiceGrsAmt,                                            
    SUM(X.TotServiceDisc)  AS TotServiceDisc,  SUM(X.TotServicePatShare)  As TotServicePatShare,
	SUM(X.TotServiceNetAmt)  AS TotServiceNetAmt, 
	X.CompanyVATRate, 
	SUM(X.CompanyVAT) AS CompanyVAT,
	X.PatientVATRate, SUM(X.PatientVAT)   As PatientVAT                         
FROM

(
                                           
select  
--ROW_NUMBER() OVER (ORDER BY A.BillNo) AS CounterX,
a.billno +
convert(nvarchar,month(@FromDate)) + right(convert(nvarchar,a.AuthorityID),3) 
+ convert(nvarchar,day(@FromDate)) + RIGHT(CONVERT(NVARCHAR, YEAR(@FromDate)), 2) 

InvoiceNo, 

                                       
--a.itemcode 

CASE WHEN A.ServiceId IN (11) THEN
	ISNULL(SFDA.SFDA_Code, A.ItemCode)
ELSE
	ISNULL(M.ItemCode, A.ItemCode)
END AS ServiceCode,   
                              
convert(datetime,convert(nvarchar,a.billdatetime,105),105) ServiceDate,                                                   
substring(a.itemname,1,80) ServiceDesc,                                        
convert(numeric(12,2),sum((a.billamount/a.quantity))) UnitServicePrice,                                              
'N/A' UnitServiceType,                                              
convert(numeric(12,2),Sum(a.quantity)) Qty,                              
'' ToothNo,                                              
convert(numeric(12,2),Sum(BillAmount)) TotServiceGrsAmt,                                                  
convert(numeric(12,2),Sum(Discount)) TotServiceDisc,                                                  
convert(numeric(12,2),Sum(PaidAmount)) TotServicePatShare,convert(numeric(12,2),Sum(Balance)) TotServiceNetAmt,

CASE WHEN A.ServiceId IN (11) THEN 0
ELSE
	5
END AS CompanyVATRate,

--

CASE WHEN P.Nationality IN (25) THEN 0
ELSE
			
CASE WHEN A.ServiceId IN (11) THEN 0
ELSE
5
END
END PatientVATRate,

--

CASE WHEN A.ServiceId IN (11) THEN 0
ELSE
	SUM(BillAmount - Discount) * @TMPVAT
END AS CompanyVAT,

CASE WHEN P.Nationality IN (25) THEN 0
ELSE
			
CASE WHEN A.ServiceId IN (11) THEN 0
ELSE
	SUM(PaidAmount) * @TMPVAT
END
END PatientVAT

 
                                       
from HIS..arcompanybilldetail a  
left join HIS..patient P on a.RegistrationNo = P.Registrationno                                                 
left join HIS..employee b on a.doctorid = b.id                                                  
left join HIS..department c on b.departmentid = c.id    

LEFT JOIN HIS..CompanyProceduresMapping M ON A.ItemId = M.ItemID 
	AND A.CompanyId = 0 AND A.CategoryId = M.CategoryID AND A.ServiceId = M.ServiceID AND M.IPOP = 2

-- SFDA

LEFT JOIN HIS..MOHInv_CodeMappings SFDA ON A.ITEMCODE = SFDA.SGH_Code and SFDA.Deleted = 0


                                              
where a.categoryid = @xCatID and a.companyid <> 0 and                        
a.billdatetime >= @FromDate and a.billdatetime < @ToDate                            
and a.posted > 1 and 
a.CompanyId not in(
	17563,
	22540,
	19235,
	32503,
	--34112,
	15520,
	30758
	--,38342
)
--(a.companyid <> 17563 and a.CompanyId<>30758)                     
group by 
P.Nationality, a.ServiceId,
A.BillNo +
convert(nvarchar,month(@FromDate)) + right(convert(nvarchar,a.AuthorityID),3) + 
convert(nvarchar,day(@FromDate))
+ RIGHT(CONVERT(NVARCHAR, YEAR(@FromDate)), 2) 
,a.itemcode,convert(datetime,convert(nvarchar,a.billdatetime,105),105),a.itemname ,
ISNULL(SFDA.SFDA_Code, A.ItemCode), ISNULL(M.ItemCode, A.ItemCode)
                                      
) X

GROUP BY X.InvoiceNo, X.ServiceCode, X.ServiceDate, X.ServiceDesc, 
X.UnitServiceType, X.ToothNo, X.CompanyVATRate, X.PatientVATRate
)
J
