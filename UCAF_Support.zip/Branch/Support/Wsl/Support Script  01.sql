--UPDATE HIS..XXWSL_GENINFO SET MainSymptom =       
--		(
--			SELECT TOP 1 SUBSTRING(e.description,1,1000) FROM HIS..opbill a      
--			LEFT JOIN HIS..opdoctororder b ON a.id=b.opbillid      
--			LEFT JOIN HIS..opdoctororderdetail c ON b.id=c.opdoctororderid      
--			LEFT JOIN HIS..clinicalvisit d ON c.opdoctororderid=d.scheduleid      
--			LEFT JOIN HIS..clinicaldetails e ON d.id = e.visitid      
--			WHERE a.id=XXWSL_GENINFO.opbillid      
--			AND e.tableid=1 AND e.mainsymptomid=0 AND e.subsymptomid=0),  
--			VISITID= (SELECT TOP 1 d.id 
--			FROM HIS..opbill a      
--			LEFT JOIN HIS..opdoctororder b ON a.id=b.opbillid      
--			LEFT JOIN HIS..opdoctororderdetail c ON b.id=c.opdoctororderid      
--			LEFT JOIN HIS..clinicalvisit d ON c.opdoctororderid=d.scheduleid      
--			LEFT JOIN HIS..clinicaldetails e ON d.id = e.visitid      
--			WHERE a.id=XXWSL_GENINFO.opbillid)      
--		--and e.tableid=1 and e.mainsymptomid=0 and e.subsymptomid=0)     
--		WHERE serviceid=2      


SELECT  replace(AuthorityID, 'ATH', '')  AS AuthorityID
INTO #TMP_WSLAUTHID
FROM HIS..XXWSL_GENINFO
where claimdate >='01-SEP-2019' and ClaimDate < '01-OCT-2019'
group BY replace(AuthorityID, 'ATH', '') 

--SELECT
--	LEFT(PROVCLAIMNO, 7) AS AuthorityId 
--INTO #TMP_WSLAUTHID
--FROM wsl_geninfo
--where claimdate >='01-SEP-2019' and ClaimDate < '01-OCT-2019'
--and MAINSYMPTOM IS NULL
--group by LEFT(PROVCLAIMNO, 7)

-- CONSULTATION
SELECT
A.AuthorityId, 
(
	SELECT TOP 1 OpBillId FROM his..OPCompanyBilldetail 
	WHERE BillAmount > 0
	AND ServiceId = 2 AND AuthorityId = A.AuthorityID
	--AND Billdatetime >= '01-APR-2019'
	ORDER BY billdatetime DESC
) AS OPBillId
INTO #TMP_WSLCONS
FROM #TMP_WSLAUTHID A


SELECT
A.AuthorityId,
(
	SELECT TOP 1 OpBillId FROM his..OPCompanyBilldetail 
	WHERE BillAmount = 0
	AND ServiceId = 2 AND AuthorityId = A.AuthorityId
	--AND Billdatetime >= '01-APR-2019'
	ORDER BY billdatetime DESC
) AS OPBillId
INTO #TMP_WSLCONSREV
FROM #TMP_WSLCONS A
WHERE A.OPBillId IS NULL

SELECT 
A.*
INTO #TMP_CONSOPBILL
FROM (

SELECT * FROM #TMP_WSLCONS
WHERE ISNULL(OPBillId,0) > 0
UNION ALL
SELECT * FROM #TMP_WSLCONSREV
) A
WHERE A.OPBillId IS NOT NULL

-- 671
SELECT
	A.AuthorityId, B.Id as ScheduleId
INTO #TMP_CONSSCHED
FROM #TMP_CONSOPBILL A
 INNER JOIN his..OPDoctorOrder B ON A.opbillid = b.OPBillID


 SELECT 
	A.AuthorityId, B.Id As VisitId, B.DoctorID
 INTO #TMP_CLINICALDETAILS
 FROM #TMP_CONSSCHED A
 INNER JOIN his..ClinicalVisit B ON A.ScheduleId = B.ScheduleID

 -- 549 | Having Clinical Details

 SELECT A.AuthorityId, SUBSTRING(B.Description, 1, 1000) AS ClinicalData, A.DoctorID
 FROM #TMP_CLINICALDETAILS A
 INNER JOIN HIS..ClinicalDetails B ON A.VisitId = B.VisitId and TableId = 1 and MainSymptomId = 0
 ORDER BY A.AuthorityId
-- 6662
-- 6268

DROP TABLE #TMP_WSLAUTHID
DROP TABLE #TMP_WSLCONS
DROP TABLE #TMP_WSLCONSREV
DROP TABLE #TMP_CONSOPBILL
DROP TABLE #TMP_CONSSCHED
DROP TABLE #TMP_CLINICALDETAILS

