SELECT * FROM Company WHERE Code = '31Q6'  -- 16944

SELECT * FROM Grade WHERE CompanyId = 16944 -- 31679

SELECT S.Name, A.* 
FROM OPCompanyServices A
	LEFT JOIN OPBService S ON A.ServiceID = S.Id
WHERE GradeId = 31679

SELECT S.ServiceName, A.* 
FROM IPCompanyServices A
	LEFT JOIN IPBService S ON A.ServiceID = S.Id
WHERE GradeId = 31679



SELECT 
	UPPER(S.Name) AS ServiceName, 
	D.Name AS Department,
	A.*
FROM OPCompanyDeptServices A
	LEFT JOIN OPBService S ON A.ServiceID = S.Id
	LEFT JOIN Department D ON A.DepartmentId = D.ID
WHERE A.GradeId = 31679 and A.IncludeType = 0


SELECT 
	UPPER(S.ServiceName) AS ServiceName, 
	D.Name AS Department,
	A.*
FROM IPCompanyDeptServices A
	LEFT JOIN IPBService S ON A.ServiceID = S.Id
	LEFT JOIN Department D ON A.DepartmentId = D.ID
WHERE A.GradeId = 31679 and A.IncludeType = 0

-- select * from opbservice where id = 18
SELECT DISTINCT Serviceid  FROM OPCompanyItemServices WHERE GradeId = 31679

SELECT 
S.Name AS ServiceName, D.Name AS Department,
I.Code AS ItemCode, I.Name as ItemName,
A.*
FROM OPCompanyItemServices A
	LEFT JOIN OPBService S ON A.ServiceID = S.Id
	LEFT JOIN Department D ON A.DepartmentId = D.ID
	LEFT JOIN test I ON A.ItemId = I.ID
WHERE GradeId = 31679 AND A.ServiceId = 3
UNION ALL
SELECT 
S.Name AS ServiceName, D.Name AS Department,
I.Code AS ItemCode, I.Name as ItemName,
A.*
FROM OPCompanyItemServices A
	LEFT JOIN OPBService S ON A.ServiceID = S.Id
	LEFT JOIN Department D ON A.DepartmentId = D.ID
	LEFT JOIN OtherProcedures I ON A.ItemId = I.ID
WHERE GradeId = 31679 AND A.ServiceId = 7
UNION ALL
SELECT 
S.Name AS ServiceName, D.Name AS Department,
I.Code AS ItemCode, I.Name as ItemName,
A.*
FROM OPCompanyItemServices A
	LEFT JOIN OPBService S ON A.ServiceID = S.Id
	LEFT JOIN Department D ON A.DepartmentId = D.ID
	LEFT JOIN BloodIssueMaster I ON A.ItemId = I.ID
WHERE GradeId = 31679 AND A.ServiceId = 18
UNION ALL

SELECT 
S.Name AS ServiceName, D.Name AS Department,
I.ItemCode AS ItemCode, I.Name as ItemName,
A.*
FROM OPCompanyItemServices A
	LEFT JOIN OPBService S ON A.ServiceID = S.Id
	LEFT JOIN Department D ON A.DepartmentId = D.ID
	LEFT JOIN Item I ON A.ItemId = I.ID
WHERE GradeId = 31679 AND A.ServiceId = 11


--select * from BloodIssueMaster                                            