SELECT * , 0 AS IsUpdate
INTO ArCompanyBillDetail_NCCI_PH_JAN2021
FROM ArCompanyBillDetail WHERE BillDateTime >= '01-JAN-2020' and BillDateTime < '01-FEB-2020'
AND serviceid = 11 AND CategoryId IN (24, 89)


SELECT A.* , 0 AS IsUpdate
INTO ARIPBillItemDetail_NCCI_PH_JAN2021
FROM ARIPBillItemDetail A 
INNER JOIN ARIPBILL B ON A.BillNo = B.BillNo
WHERE B.InvoiceDateTime >= '01-JAN-2020' and B.InvoiceDateTime < '01-FEB-2020'
AND A.serviceid IN (5, 37) AND B.CategoryId IN (24, 89)



