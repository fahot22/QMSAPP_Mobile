SELECT 
	A.Id,
	A.IPApprovalRequestId,
	A.BedTypeId,
	ISNULL(BT.name, '') AS BedTypeName,
	A.ServiceId,
	CASE WHEN A.IPApprovalTypeId = 1 THEN 'ADMISSION' ELSE
	UPPER(LTRIM(RTRIM(S.ServiceName))) END AS ServiceName,
	A.DepartmentId,
	ISNULL(DE.Name,'') AS DepartmentName,
	A.ItemId,
	CASE WHEN A.IPApprovalTypeId = 1 THEN 'ADM' ELSE
	I.Code END AS ItemCode,
	CASE WHEN A.IPApprovalTypeId = 1 THEN 'Admission Request' ELSE
	I.Description END AS ItemName,
	A.ReqAmount AS RequestPrice,
	A.ReqQuantity AS RequestQuantity,
	ISNULL(A.ExpectedLengthOfStay,0) AS ExpectedLengthOfStay,
	PlannedAdmissionDate AS PlannedAdmissionDate,


	A.RequestRemarks AS OrderRemarks,
	ISNULL(A.AppAmount,0) AS ApprovedPrice

FROM UCAF.IPApprovalRequest_Detail A
	LEFT JOIN RCM.All_IPItems I ON A.ServiceId = I.ServiceId AND A.ItemId = I.Id
	LEFT JOIN dbo.IPBService S ON A.ServiceId = S.Id
	LEFT JOIN dbo.ARApprovalStatus ST ON A.ApprovalStatusId = ST.ID
	LEFT JOIN dbo.BedType BT ON A.BedTypeId = BT.Id
	LEFT JOIN dbo.Department DE ON A.DepartmentId = DE.Id
WHERE A.IPApprovalRequestId = 5
	AND A.ServiceId NOT IN (5, 37) AND A.Deleted = 0
