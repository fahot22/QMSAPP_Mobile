--select * from category where id = 72

--select * from arcompanybilldetail where categoryid = 72 and serviceid = 2
--and BillDateTime >= '10-MAY-2021'

--select * from arcompanybilldetail where categoryid = 72 and serviceid = 2
--and BillDateTime >= '10-MAY-2021'

--select * from IPBService


--update arcompanybilldetail 
--set BillAmount = 180, Balance = 180 - PaidAmount
--where categoryid = 72 and serviceid = 2
--and BillDateTime >= '10-MAY-2021'


--update ARIPBillItemDetail set EditPrice = 180 where billno in (
--select billno from aripbill where categoryid = 72 
--and InvoiceDateTime >= '10-MAY-2021'
--) and serviceid = 15