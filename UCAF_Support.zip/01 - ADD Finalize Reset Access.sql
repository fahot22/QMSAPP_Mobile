/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Id]
      ,[OperatorId]
      ,[CanReset]
      ,[Deleted]
  FROM [HIS].[ARADMIN].[IpBillFinalization_Access]

  INSERT INTO [HIS].[ARADMIN].[IpBillFinalization_Access]
  (OperatorId, CanReset, Deleted)
  VALUES(1888, 1, 0)

    INSERT INTO [HIS].[ARADMIN].[IpBillFinalization_Access]
  (OperatorId, CanReset, Deleted)
  VALUES(1807, 1, 0)

  select * from employee where id = 365

  select * from employee where EmployeeID IN ('20211264','20212260')