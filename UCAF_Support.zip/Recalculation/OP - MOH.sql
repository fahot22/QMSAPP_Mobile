DECLARE @TariffID INT = 119, @CategoryID INT = 41, @CompanyId INT = 40632,
		@Date DATETIME = '01-APR-2022'

--SELECT * FROM ArCompanyBillDetail WHERE CategoryId = @CategoryID AND CompanyId = @CompanyId
--AND  BillDateTime >= @Date AND BillDateTime < DATEADD(M,1,@Date)

/*
	JED
	select * from company where id in (
	5237,
	40632)
*/
--- JED

-- select * from category where id = 78 -- 84
-- select * from category where id = 84
-- select * from category order by code
-- select * from tariff where id = 119
-- select * from OP_P_138_Test
-- select * from aradmin.moh_company


--SELECT *
--INTO #ARCompanyBillDetail_BUPA_JAN2022
--FROM ARCompanyBillDetail WHERE CategoryId = @CategoryID
--AND BillDateTime >= @Date AND BillDateTime < DATEADD(M,1,@Date)

SELECT DISTINCT GradeId
INTO #TMP_BILLGRADE
FROM ARCompanyBillDetail WHERE CategoryId = @CategoryID AND COmpanyId = @CompanyId
AND BillDateTime >= @Date AND BillDateTime < DATEADD(M,1,@Date)

SELECT Id, FixedConCharges 
INTO #TMP_CONPRICE
FROM GRADE WHERE ID IN (SELECT GradeId FROM #TMP_BILLGRADE)

SELECT A.*
INTO #TMP_OPPRICE
FROM (
SELECT 3 AS ServiceID, ID AS Itemid, price FROM OP_P_119_Test WHERE Price > 0
UNION ALL
SELECT 5 AS ServiceID, ID AS Itemid, Price FROM OP_P_119_PTProcedure WHERE Price > 0
UNION ALL
SELECT 7 AS ServiceID, ID AS Itemid, Price FROM OP_P_119_OtherProcedure WHERE Price > 0
UNION ALL
SELECT 14 AS ServiceID, ID AS Itemid, Price FROM OP_P_119_FoodItem WHERE Price > 0
) A

 /* VIEW */

--SELECT P.Price * A.Quantity as NewPrice, A.billAMount as OldPrice, A.ItemCode, A. ItemName, *  
--FROM ARCompanyBillDetail A
--	INNER JOIN #TMP_OPPRICE P ON A.ServiceId = P.ServiceID AND A.ItemId = P.Itemid
--WHERE A.CategoryId = @CategoryID AND A.CompanyId = @CompanyId
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11,2)
--AND (P.Price * A.Quantity) <> A.BillAmount

--SELECT P.FixedConCharges as NEWPRICE, A.billAMount as oldprice, *  
--FROM ARCompanyBillDetail A
--	INNER JOIN #TMP_CONPRICE P ON A.GradeId = P.ID 
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId IN (2)
--AND P.FixedConCharges <> A.BillAmount

--SELECT 
--(dbo.get_CompanyDiscount_OP(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.departmentid, A.itemid) / 100.0 ) AS Percentage,
--(dbo.get_CompanyDiscount_OP(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.departmentid, A.itemid) / 100.0 ) * A.BillAmount AS NewDisc, 
-- A.discount as oldiscount, A.*  
--FROM ARCompanyBillDetail A
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11,2) AND A.Discount > 0
--AND A.ServiceId = 3



--/* 1. OTHER SERVICE */

UPDATE A
	SET BillAmount = P.price * A.Quantity
FROM ARCompanyBillDetail A
INNER JOIN #TMP_OPPRICE P ON A.ServiceId = P.ServiceID AND A.ItemId = P.Itemid AND P.price > 0
WHERE A.CategoryId = @CategoryID
AND A.CompanyId = @CompanyId
AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
AND A.ServiceId NOT IN (11, 2)
AND (P.Price * A.Quantity) <> A.BillAmount
--AND  A.ITEMCODE IN ('FMLAB-7007', 'FMNEP-0004')

----PRINT 'OTHER SERVICES DONE'

--/* 2. CONSULTATION */

----UPDATE A
----	SET BillAmount = P.FixedConCharges
----FROM ARCompanyBillDetail A
----INNER JOIN #TMP_CONPRICE P ON A.GradeId = P.ID 
----WHERE A.CategoryId = @CategoryID
----AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
----AND A.ServiceId IN (2)
----AND P.FixedConCharges <> A.BillAmount

----PRINT 'CONSULTATION DONE'

--/* 3. DISCOUNTS */

--UPDATE A
--	SET Discount = (dbo.get_CompanyDiscount_OP(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.departmentid, A.itemid) / 100.0 ) * A.BillAmount
--FROM ARCompanyBillDetail A
--WHERE A.CategoryId = @CategoryID
--AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
--AND A.ServiceId NOT IN (11) AND A.Discount > 0
------AND  A.ITEMCODE IN ('FMLAB-7007', 'FMNEP-0004')

----PRINT 'DISCOUNT DONE'

----/* 4. BALANCE */

UPDATE A
	SET Balance = BillAmount - Discount - PaidAmount
FROM ARCompanyBillDetail A
WHERE A.CategoryId = @CategoryID
AND A.CompanyId = @CompanyId
AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
AND A.ServiceId NOT IN (11) 
--AND  A.ITEMCODE IN ('FMLAB-7007', 'FMNEP-0004')

----PRINT 'BALANCE DONE'

DROP TABLE #TMP_BILLGRADE
DROP TABLE #TMP_OPPRICE
DROP TABLE #TMP_CONPRICE

/*
-- select id from #TMP_CONPRICE 
-- group by id
-- having count(id) > 1

--RETURN
-- SELECT Id, Code,  Name, TariffId, ValidTill FROM CATEGORY WHERE id in (79, 51, 25, 72, 70, 78) order by id
-- SELECT * FROM CATEGORY order by code
-- SELECT * FROM OPBService where deleted = 0
-- select * from tariff where id = 89
-- update CATEGORY set tariffid = 140 WHERE id = 78
-- select distinct tariffid from company where categoryid = 79


*/

-- MANUAL

--SELECT C.ItemCode, C.Price, --C.Price * .15 AS NEWDISCOUNT,  
--A.BillAmount, A.Discount,  (A.Discount/A.BillAmount) * 100,   A.* 
--FROM ArCompanyBillDetail A
--INNER JOIN ARADMIN.TMP_RECALCULATION_TBL C ON A.ItemCode = C.Itemcode --AND A.BillAmount <> C.Price
--WHERE A.BillDateTime >= '01-JAN-2022' AND A.BillDateTime < '01-FEB-2022'
--AND A.CategoryId = 11
--AND A.ServiceID in (3, 7)
--AND A.ITEMCODE IN (--'FMLAB-7007', 
--'FMNEP-0004')




