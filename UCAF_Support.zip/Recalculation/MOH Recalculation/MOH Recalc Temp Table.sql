/*

create table RCM.TMP_MOH_RECALC
(
	ItemCode NVARCHAR(256),
	Price DECIMAL(18,2),
	IsPD BIT
)




*/

/*

	select * from company where id in (select companyid from aradmin.MOH_Company)

*/

-- select * from aradmin.MOH_Company
-- select * from company where categoryid in (51)
-- select * from category  order by code
-- OP
--SELECT 
--P.Price  AS NewPrice,
--A.BillAmount,
--A.* 
--FROM dbo.ArCompanyBillDetail A 
--INNER JOIN RCM.TMP_MOH_RECALC P ON P.ItemCode = A.ITEMCODE
--WHERE A.Companyid IN (276)
--AND A.BillDateTime >= '10-MAR-2022'
--AND A.BillDateTime < '01-MAY-2022'

---- IP | NPD
--SELECT 
--P.Price + (P.Price * (34.5/100)) AS NewPrice,
--A.EditPrice, A.*

--UPDATE A
--SET 
--A.EditPrice = P.Price

--FROM dbo.ARIPBillItemDetail A
--INNER JOIN dbo.ARIPBill B ON B.BillNo = A.BillNo
--INNER JOIN RCM.TMP_MOH_RECALC P ON P.ItemCode = A.ITEMCODE AND A.EditPrice <> P.Price
--WHERE B.Companyid IN (276)
--AND B.InvoiceDateTime >= '10-MAR-2022'
--AND B.InvoiceDateTime < '01-MAY-2022'
--AND A.ServiceId NOT IN (5, 37)
--AND A.SerialNo NOT IN (Select ISNULL(PDSerialNo,0) from ARPackageBill)

SELECT 
P.Price AS NewPrice,
A.EditPrice, A.*

--UPDATE A
--SET 
--A.EditPrice = P.Price

FROM dbo.ARIPBillItemDetail A
INNER JOIN dbo.ARIPBill B ON B.BillNo = A.BillNo
INNER JOIN RCM.TMP_MOH_RECALC P ON P.ItemCode = A.ITEMCODE
WHERE B.Companyid IN (27462,30510)
AND B.InvoiceDateTime >= '10-MAR-2022'
AND B.InvoiceDateTime < '01-MAY-2022'
AND A.SerialNo IN (Select ISNULL(PDSerialNo,0) from ARPackageBill)

