--SELECT C.ItemCode, C.Price, C.Price * .15 AS NEWDISCOUNT,  A.EditPRice, A.Discount,  (A.Discount/A.EditPRice) * 100,   A.* FROM ARIPBillItemDetail A
--INNER JOIN aripbill B ON A.BillNo = B.BillNo
--INNER JOIN ARADMIN.TMP_RECALCULATION_TBL C ON A.ItemCode =C.Itemcode AND A.EditPrice <> C.Price
--WHERE B.InvoiceDatetime >= '01-JAN-2022' AND B.InvoiceDateTime < '01-FEB-2022'
--AND B.CategoryID = 84
--AND A.ServiceID in (2, 4, 6, 8, 12, 13, 15, 16, 20, 24, 26, 29)

--UPDATE A
--SET 
--	A.Discount = A.EditPrice * .25
----SELECT A.EditPrice * .25, A.*
--FROM ARIPBillItemDetail A
--INNER JOIN aripbill B ON A.BillNo = B.BillNo
--WHERE B.InvoiceDatetime >= '01-MAR-2022' AND B.InvoiceDateTime < '01-APR-2022'
--AND B.CategoryID = 6
--AND A.ServiceID in (6, 8, 10, 13, 16, 25)
--AND A.SerialNO NOT IN (SELECT PDSerialNo FROM ARPackageBill)


-- SELECT * FROM IPBService
select * from department where id in (
SELECT distinct departmentid --A.EditPrice * .25, A.*
FROM ARIPBillItemDetail A
INNER JOIN aripbill B ON A.BillNo = B.BillNo
WHERE B.InvoiceDatetime >= '01-MAR-2022' AND B.InvoiceDateTime < '01-APR-2022'
AND B.CategoryID = 6
AND A.ServiceID in (22)
AND A.SerialNO NOT IN (SELECT PDSerialNo FROM ARPackageBill)
)
-- 106
-- 111
-- 13

--SELECT A.EditPrice * .25, A.*

--UPDATE A
--SET 
--	A.Discount = A.EditPrice * .25

--FROM ARIPBillItemDetail A
--INNER JOIN aripbill B ON A.BillNo = B.BillNo
--WHERE B.InvoiceDatetime >= '01-MAR-2022' AND B.InvoiceDateTime < '01-APR-2022'
--AND B.CategoryID = 6
--AND A.ServiceID in (22)
--AND A.DepartmentID IN (13,26,85, 106, 111)
--AND A.SerialNO NOT IN (SELECT PDSerialNo FROM ARPackageBill)




