select * from OPCompanyBillDetail where billno = '0' --18498435
 -- 10606

select * from employee where id = 10606


select * from title

select * from  CANCELBILLREASON


select * from  CANCELBILLREASON_B

select * from  CANCELBILLREASONDetails where MainReasonId = 5

select * from CANOPBILLAPPROVER where deleted = 0

/*
	EXEC [FRONTOFFICE].[N_OpBillCancellation_CancelBill_V2] 18498435,10606, 1186369, 'Requested by OPD to IT', '1186369', 5, 56, 0, ''
*/

