SELECT * FROM Employee WHERE employeeid = '20219716'

select * from ARADMIN.IpBillFinalization_Access 



--insert into ARADMIN.IpBillFinalization_Access  (OperatorId, CanReset, Deleted)
--values(7648, 1, 0)

