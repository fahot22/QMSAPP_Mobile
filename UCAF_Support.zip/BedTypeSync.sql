﻿--truncate table bedtype

SET IDENTITY_INSERT dbo.bedtype ON;

INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (1, 'FIRST CLASS','Oct 19 2021 12:36PM', 0, NULL,'FC',1,N'',N'"','FC',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (2, 'SECONDCLASS','Oct 19 2021 12:36PM', 0, NULL,'SC',1,N'درجة ثانية',N'','SC',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (3, 'THIRDCLASS','Oct 19 2021 12:36PM', 0, NULL,'TC',1,N'درجة ثالثة',N'','TC',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (4, 'ISOLATION','Oct 19 2021 12:36PM', 0, NULL,'ISO',1,N'',N'','ISO',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (5, 'ICU DAILY RATE','Oct 19 2021 12:36PM', 0, NULL,'ICU',2,N'عناية مركزة',N'','FMANA-0029',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (6, 'NICU1','Oct 19 2021 12:36PM', 0, NULL,'NICU1',2,N'',N'','NICU1',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (7, 'NICU2','Oct 19 2021 12:36PM', 0, NULL,'NICU2',2,N'',N'','NICU2',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (8, 'TICU','Oct 19 2021 12:36PM', 0, NULL,'TICU',2,N'',N'','TICU',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (9, 'PICU1','Oct 19 2021 12:36PM', 0, NULL,'PICU1',2,N'',N'','PICU1',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (10, 'SUITE','Oct 19 2021 12:36PM', 0, NULL,'SUITE',1,N'جناح',N'','SUITE',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (11, 'ROYAL SUITE','Oct 19 2021 12:36PM', 0, NULL,'R SUITE',1,N'جناح ملكي ',N'','R SUITE',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (12, 'NORMAL BABY CRIB','Oct 19 2021 12:36PM', 0, NULL,'NBC',2,N'',N'','NBC',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (13, 'EMERGENCY','Oct 19 2021 12:36PM', 0, NULL,'ER',3,N'',N'','ER',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (15, 'DELIVERY ROOM','Oct 19 2021 12:36PM', 0, NULL,'DR',2,N'',N'','DR',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (16, 'INTERMEDIATE CLASS','Oct 19 2021 12:36PM', 0, NULL,'INT CLS',1,N'',N'','INT CLS',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (17, 'DAY CASE','Oct 19 2021 12:36PM', 0, NULL,'D CASE',2,N'',N'','D CASE',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (18, 'PICU2','Oct 19 2021 12:36PM', 0, NULL,'PICU2',2,N'',N'','PICU2',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (19, 'NICU','Oct 19 2021 12:36PM', 0, NULL,'NICU',2,N'',N'','NICU',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (20, 'SCBU','Oct 19 2021 12:36PM', 0, NULL,'SCBU',2,N'',N'','SCBU',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (21, 'ESCORT','Oct 19 2021 12:36PM', 0, NULL,'ES',1,N'',N'','ES',0,0)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (22, 'OHU','Oct 19 2021 12:36PM', 0, NULL,'OHU',2,N'',N'','OHU',1412,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (23, 'NICU3','Oct 19 2021 12:36PM', 0, NULL,'NICU3',2,N'',N'','',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (24, 'PICU3','Oct 19 2021 12:36PM', 0, NULL,'PICU3',2,N'',N'','',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (25, 'DELUXE','Oct 19 2021 12:36PM', 0, NULL,'DELUXE',1,N'',N'','',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (26, 'PSY WARD','Oct 19 2021 12:36PM', 0, NULL,'SC',1,N'',N'"','SECOND CLASS',139,0)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (27, 'ICU RATE EXT.','Oct 19 2021 12:36PM', 0, NULL,'ICU2',2,N'',N'"','ICU2',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (28, 'DELUXE-R','Oct 19 2021 12:36PM', 0, NULL,'DELUXE-R',1,N'',N'"','',0,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (37, 'DELUXE-R-6FL','Oct 19 2021 12:36PM', 0, NULL,'DELUXER6',1,N'',N'','DELUXE-R-6FL',1,1)
INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabiccode, Code, operatorid, billable) VALUES (40, 'ICU 6th Floor','Oct 19 2021 12:36PM', 0, NULL,'ICU6F',2,N'',N'','ICU6F',1,1)

SET IDENTITY_INSERT dbo.bedtype OFF;


