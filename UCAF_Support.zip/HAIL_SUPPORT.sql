--SELECT * FROM ARIPBILL WHERE SLNO = 9575

--78 35739		76106

--select * from IPCompanyServiceDiscount where GradeID = 76106
--select * from IPCompanyDeptDiscount where GradeID = 76106
--select * from IPCompanyItemDiscount where GradeID = 76106

--select *  from ARIPBillItemDetail where billno = 18969

select
(EditPrice * EditQuantity)
-- * .12
from ARIPBillItemDetail where billno = 18969 and ItemCode IN ( 
'MS-S-000151',
'MS-S-000006',
'MS-N-000003',
'MS-C-000051',
'MS-N-000002',
'MS-N-000005',
'MS-S-000144',
'MS-N-000002',
'MS-S-000144',
'MS-N-000003',
'MS-N-000004',
'MS-S-000006',
'MS-I-000002',
'MS-N-000005',
'MS-N-000004',
'MS-S-000006',
'MS-S-000144')