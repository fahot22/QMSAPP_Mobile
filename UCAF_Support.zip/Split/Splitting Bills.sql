--select * from OldInPatient where RegistrationNo = 1811426 -- -- 284166

--select * from aripbill where ipid = 284166

--delete from aripbill where billno = 383068

--select * from ARIPBillItemDetail where billno = 383068





