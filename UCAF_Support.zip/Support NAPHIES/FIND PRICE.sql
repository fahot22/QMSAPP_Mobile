select * from company where policyno = 'GRH/13852751-0' -- COmpanyId 7129 tariff id = 27

select * from grade where companyid = 7129 -- GradeId 13711

select * from OtherProcedures where Code = 'FMDNTM0004'
select * from OtherProcedures where Code = 'FMDNTS0004'
select * from OtherProcedures where Code = 'FMDNTF0007'

select * from OP_P_27_OtherProcedure where id in (406, 557, 2293)

select * from OP_P_1_OtherProcedure where id in (406, 557, 2293)
