select * from category where id = 6


select
	distinct serviceid 
from CompanyProceduresMapping where categoryid = 6
and ipop = 1


select itemid from CompanyProceduresMapping
where ipop = 1 and serviceid = 20 and  categoryid = 6
group by itemid
having count(*) > 1

select
	*
from CompanyProceduresMapping where categoryid = 6
and ipop = 1 and serviceid = 20
and itemid = 25

-- delete CompanyProceduresMapping where id = 1197

/*
	WITH EmployeesCTE as  
	(  
	   SELECT categoryid, itemid, serviceid, ROW_NUMBER() over (PARTITION BY Itemid, serviceid ORDER BY Itemid) as RowNumber  
	   FROM CompanyProceduresMapping  
	   WHERE Categoryid = 6
	   AND IPOP = 1
	   --AND serviceid = 1
	)  

	DELETE FROM EmployeesCTE WHERE RowNumber>1  
*/