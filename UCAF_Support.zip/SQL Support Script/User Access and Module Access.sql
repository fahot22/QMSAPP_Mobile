EXEC HISGLOBAL.EMPLOYEE_FEATURE 10521, 307

select * from HISGLOBAL.MENU_ACCESS where name like '%approval%'
-- 3207
select * from HISGLOBAL.ACCESS_MODULEFEATURES where moduleid = 307

--

select * from HISGLOBAL.ACCESS_USERFEATURES where userid = 10521
and module_Id = 307

select * from HISGLOBAL.HIS_MODULES

select * from employee where employeeid = '1734026'