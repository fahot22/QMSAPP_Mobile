DECLARE @CategoryId INT = 24, @Date DATETIME = '01-NOV-2021'
	

SELECT
A.OPBillId, A.ServiceId, CASE WHEN A.Discount > 0 THEN A.BillAmount / A.Discount  ELSE 0 END As CurrentDiscount,
(dbo.get_item_discount_op_invoice_serviceonly(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.itemid, A.billamount, A.departmentid))  AS Discount
FROM ARCompanyBillDetail A
WHERE A.CategoryId = @CategoryID
AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
AND A.ServiceId NOT IN (2)

/*

		

SELECT
A.OPBillId, A.ServiceId, CASE WHEN A.Discount > 0 THEN A.BillAmount / A.Discount  ELSE 0 END As CurrentDiscount,
(dbo.get_item_discount_op_invoice_serviceonly(A.categoryid, A.companyid, A.gradeid, A.serviceid, A.itemid, A.billamount, A.departmentid))  AS Discount
FROM ARCompanyBillDetail A
WHERE A.CategoryId = @CategoryID
AND A.BillDateTime >= @Date AND A.BillDateTime < DATEADD(M,1,@Date)
AND A.ServiceId NOT IN (2)

*/