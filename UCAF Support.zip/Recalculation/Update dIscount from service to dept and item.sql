
UPDATE A SET A.Percentage = B.Percentage
-- SELECT COUNT(*)
from OPCompanyItemDiscount A
INNER JOIN OPCompanyServiceDiscount B ON B.CategoryID = A.CategoryID
AND B.CompanyID = A.CompanyID
AND B.GradeID = A.GradeID AND B.ServiceID = A.ServiceID
WHERE A.CategoryID = 78 AND A.ServiceID IN (3)
AND A.Percentage <> B.Percentage

UPDATE A SET A.Percentage = B.Percentage
-- SELECT COUNT(*)
from OPCompanyItemDiscount A
INNER JOIN OPCompanyServiceDiscount B ON B.CategoryID = A.CategoryID
AND B.CompanyID = A.CompanyID
AND B.GradeID = A.GradeID AND B.ServiceID = A.ServiceID
WHERE A.CategoryID = 78 AND A.ServiceID IN (5)
AND A.Percentage <> B.Percentage

UPDATE A SET A.Percentage = B.Percentage
-- SELECT COUNT(*)
from OPCompanyItemDiscount A
INNER JOIN OPCompanyServiceDiscount B ON B.CategoryID = A.CategoryID
AND B.CompanyID = A.CompanyID
AND B.GradeID = A.GradeID AND B.ServiceID = A.ServiceID
WHERE A.CategoryID = 78 AND A.ServiceID IN (7)
AND A.Percentage <> B.Percentage


select COUNT(*)
	--A.CategoryID,
	-- UPDATE A SET A.Percentage = B.Percentage
from OPCompanyDeptDiscount A
INNER JOIN OPCompanyServiceDiscount B ON B.CategoryID = A.CategoryID
AND B.CompanyID = A.CompanyID
AND B.GradeID = A.GradeID AND B.ServiceID = A.ServiceID
WHERE A.CategoryID = 78 AND A.ServiceID IN (3,5,7)

