/*

UPDATE  A
	SET A.BillAmount = GR.FixedConCharges,
		A.Balance =  GR.FixedConCharges - A.PaidAmount
FROM ARCompanyBillDetail A
	LEFT JOIN Grade GR ON A.GradeId = GR.Id
WHERE A.CategoryId in (24) 
	AND A.ServiceId = 2
	AND A.BillDateTime >= '01-NOV-2021'
	AND A.BillDateTime < '01-DEC-2021'
	AND A.BillAmount < 120
	AND (A.BillAmount - A.Discount) > 0
*/

--SELECT 
--	A.*
--INTO #BAK_NCCI_NOV2021
--FROM ARCompanyBillDetail A
--WHERE A.CategoryId in (24)
--	AND A.BillDateTime >= '01-NOV-2021'
--	AND A.BillDateTime < '01-DEC-2021'


SELECT * FROM ARIPBillItemDetail
WHERE BillNo IN (
SELECT BillNo FROM aripbill where InvoiceDateTime >= '01-NOV-2021'
AND InvoiceDateTime < '01-DEC-2021'
AND CategoryId = 24
)
AND Itemname LIKE '%CT%' 

/*
	UPDATE A
		SET A.EditPrice = 120
	FROM ARIPBillItemDetail A
	WHERE A.BillNo IN (
	SELECT BillNo FROM aripbill where InvoiceDateTime >= '01-NOV-2021'
	AND InvoiceDateTime < '01-DEC-2021'
	AND CategoryId = 24
	)
	AND A.ServiceId = 15
*/
