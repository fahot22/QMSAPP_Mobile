/* UCAF

TRUNCATE TABLE UCAF.ConsultationRequestLogs
TRUNCATE TABLE UCAF.ConsultationRequest_SMS
TRUNCATE TABLE UCAF.IP_Approval_XML_Request

TRUNCATE TABLE UCAF.IPProcessLock_Logs
TRUNCATE TABLE UCAF.OPApprovalRequest_ProcessLock_Logs
TRUNCATE TABLE UCAF.IPApprovalRequest_Detail_Logs
TRUNCATE TABLE UCAF.IPApprovalRequest_Logs
TRUNCATE TABLE UCAF.OPApprovalRequest_Details_Logs

TRUNCATE TABLE UCAF.OPDoctorsOrder_Logs
TRUNCATE TABLE UCAF.NAPHIES_Eligibility_Request

DELETE FROM UCAF.IPProcessLocks

TRUNCATE TABLE UCAF.ConsultationRequest

DELETE FROM UCAF.IPApprovalRequest_Detail

DELETE FROM UCAF.IPApprovalRequests

TRUNCATE TABLE UCAF.OPApprovalRequest_Authorized

DELETE FROM UCAF.OPApprovalRequest_ProcessLock

DELETE FROM UCAF.OPApprovalRequest_Details
DELETE FROM UCAF.OPApprovalRequest

DELETE FROM UCAF.OPDoctorsOrder_Logs WHERE CreatedAt <= '01-SEP-2022'
DELETE FROM UCAF.OPDoctorsOrder WHERE CreatedAt <= '01-SEP-2022'

*/

/* RCMS
	
TRUNCATE TABLE RCM.Integration_Claim_Attachment
TRUNCATE TABLE RCM.Integration_Claim_BatchLogs
TRUNCATE TABLE RCM.Integration_Claim_Cancellation_Request
TRUNCATE TABLE RCM.Integration_Claim_DiagnosisLogs
TRUNCATE TABLE RCM.Integration_Claim_Generation_Logs

TRUNCATE TABLE RCM.Integration_Claim_IP_MedicalReport
TRUNCATE TABLE RCM.Integration_Claim_IP_ProgressNotes
TRUNCATE TABLE RCM.Integration_Claim_IP_SurgeryReport
TRUNCATE TABLE RCM.Integration_Claim_ItemsLogs
TRUNCATE TABLE RCM.Integration_Claim_Items


TRUNCATE TABLE RCM.Integration_Claim_Lab_IPResult_Culture
TRUNCATE TABLE RCM.Integration_Claim_Lab_IPResult_HistoPat
TRUNCATE TABLE RCM.Integration_Claim_Lab_IPResult_Standard
TRUNCATE TABLE RCM.Integration_Claim_Lab_OPResult_Culture
TRUNCATE TABLE RCM.Integration_Claim_Lab_OPResult_HistoPat
TRUNCATE TABLE RCM.Integration_Claim_Lab_OPResult_Standard
TRUNCATE TABLE RCM.Integration_Claim_PreGeneration_Bill
TRUNCATE TABLE RCM.Integration_Claim_PreGeneration_ClinicalData


TRUNCATE TABLE RCM.Integration_Claim_Xray_IPResult
TRUNCATE TABLE RCM.Integration_Claim_Xray_OPResult

DELETE FROM RCM.Integration_Claim_Xray_IPHeader
DELETE FROM RCM.Integration_Claim_Xray_OPHeader
DELETE FROM RCM.Integration_Claim_Lab_IPHeader
DELETE FROM RCM.Integration_Claim_Lab_OPHeader

TRUNCATE TABLE RCM.Integration_Claim_PreGeneration_Diagnosis
TRUNCATE TABLE RCM.Integration_Claim_RequestLogs
TRUNCATE TABLE RCM.Integration_Claim_Request
TRUNCATE TABLE RCM.Integration_Claim_Request_JSON
TRUNCATE TABLE RCM.Integration_Claim_Request_JSON_BATCH

TRUNCATE TABLE RCM.Integration_Claim_Request_NPHIES
TRUNCATE TABLE RCM.Integration_Claim_Request_Resend


TRUNCATE TABLE RCM.Integration_Communication_Response
TRUNCATE TABLE RCM.Integration_Eligibility_Request
TRUNCATE TABLE RCM.Integration_Naphies_Action_Logs
TRUNCATE TABLE RCM.Integration_Pooling_Request
TRUNCATE TABLE RCM.Integration_PreAuthorization_Diagnosis
TRUNCATE TABLE RCM.Integration_PreAuthorization_Items
TRUNCATE TABLE RCM.Integration_PreAuthorization_Reason
TRUNCATE TABLE RCM.Integration_PreAuthorization_Request


DELETE FROM RCM.Integration_Claim_Batch



*/