select * from ucaf.OPDoctorsOrder where RegistrationNo = 1637311
and createdat >= '31-AUG-2021' and serviceid = 11
order by CreatedAt desc

--update ucaf.OPDoctorsOrder 
--set NeedsApproval = 1
--where RegistrationNo = 1637311
--and createdat >= '31-AUG-2021' and serviceid = 11





select * from ucaf.OPDoctorsOrder_Logs where RegistrationNo = 1637311
and createdat >= '31-AUG-2021'
order by CreatedAt desc


--select * from ucaf.OPApprovalRequest where VisitId = 7245988

--select * from ucaf.OPApprovalRequest_Details where ApprovalRequestId = 544045
