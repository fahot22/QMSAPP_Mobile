/*
	EXEC UCAF.IPApprovalRequest_New_AdmissionRequest
	123456,
	6954186, 
	9321,
	9321,
	9321,
	1,
	5,
	'10-JUN-2021',
	1,
	1,
	0,
	'33 Test admission revision hashd ahsdh liong text'


*/

/*

EXEC UCAF.New_IP_ServiceRequest
1719975, 
6954186, 
12345,
9321,
1,
0,
0,
5,
4796,
25.0,
1,
3,
0,
'THIS IS A TEST PH'

*/
-- select * from Surgery where id = 3175
-- select * from department where id = 74
/*

	select * from UCAF.IPApprovalRequests

	select * from UCAF.IPApprovalRequest_Detail

	
	truncate table UCAF.IPApprovalRequest_Detail_Logs
	truncate table UCAF.IPApprovalRequest_Logs

	delete from UCAF.IPApprovalRequest_Detail
	delete from  UCAF.IPApprovalRequests


*/



--select * from grade where id = 14606

--select * from company where id = 9053


