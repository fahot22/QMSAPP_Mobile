select serviceid, Percentage  
from OPCompanyServiceDiscount
where serviceid in (3, 5, 7)
and categoryid = 6

select companyid, serviceid, Percentage  
from OPCompanyItemDiscount
where serviceid in (3)
and categoryid = 6
and itemid in (
select id 
from test where name like 'C.T%'
UNION ALL
select id 
from test where name like 'CT%'
UNION ALL
select id 
from test where name like '%MRI%'
UNION ALL
select id 
from test where name like '%M.R.I%'
)


select * from IPBService

--update  IPCompanyServiceDiscount
--set DateTime = '01-MAR-2022'
--where serviceid in (6, 8, 10, 13, 16, 25)
--and categoryid = 6

--select companyid, serviceid, Percentage  
--from OPCompanyItemDiscount
--where serviceid in (3)
--and categoryid = 6
--and itemid in (
--select id 
--from test where name like 'CT%'
--UNION ALL
--select id 
--from test where name like '%MRI%'
--)