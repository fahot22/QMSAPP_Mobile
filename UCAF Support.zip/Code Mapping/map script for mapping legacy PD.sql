

--UPDATE A
--	SET A.Code = B.MappedCode
--FROM ARADMIN.arpackagemaster A
--INNER JOIN  RCM.TMP_PD_MAPPING B ON A.Code = B.InternalCode
--WHERE A.CategoryId = 72


--SELECT * FROM RCM.TMP_PD_MAPPING
--WHERE InternalCode IN (SELECT Code FROM ARADMIN.arpackagemaster WHERE CategoryId = 72)