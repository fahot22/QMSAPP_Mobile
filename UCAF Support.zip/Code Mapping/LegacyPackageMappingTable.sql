create table RCM.TMP_PD_MAPPING
(
	Id INT PRIMARY KEY IDENTITY(1,1),
	InternalCode NVARCHAR(256),
	MappedCode NVARCHAR(512),
	MappedDescription NVARCHAR(512)
)