DECLARE @CategoryId INT = 72

-- OP
-- select * from CompanyProceduresMapping where categoryid = 72 and ipop = 1 and serviceid = 15
-- delete from CompanyProceduresMapping where categoryid = 72 and ipop = 1
-- 

/*
 RUN THIS TO MAP NEW DOCTOR
 CONSULTATION
 select * from ipbservice where deleted = 0

 select * from CompanyProceduresMapping where categoryid = 72
*/

--INSERT INTO CompanyProceduresMapping (ServiceId, CategoryId, CompanyId, Itemid, ItemCode, ItemName, Price, IPOP, SGH_Code)
--SELECT 
--	15 AS ServiceId, @CategoryId AS CategoryId, 0 AS CompanyId, Id AS ItemId,
--	'CON' AS ItemCode, Name AS Itemname, 0 AS Price, 1 AS IPOP, EmpCode AS SGH_Code
--FROM DOCTOR
--WHERE Deleted = 0 
--AND Id NOT IN (select ItemId from CompanyProceduresMapping where categoryid = 72 and ipop = 1 and serviceid = 15)


/*
 NON CONS
*/
--INSERT INTO CompanyProceduresMapping (ServiceId, CategoryId, CompanyId, Itemid, ItemCode, ItemName, Price, IPOP, SGH_Code)
SELECT
	B.ServiceId AS ServiceId, @CategoryId AS CategoryId, 0 AS CompanyId, B.Id AS ItemId,
	A.Code AS ItemCode, A.NphiesDescription AS Itemname, 0 AS Price, 1 AS IPOP,  B.Code AS SGH_Code
FROM ARCompanyMapFile A
INNER JOIN RCM.All_IPItems B ON A.MasterCode = B.Code AND B.Deleted = 0