select

'INSERT INTO dbo.bedtype(id, name, startdatetime, deleted, enddatetime, label, type, arabicname, arabicode, Code, operatorid, billable) VALUES (' + CONVERT(VARCHAR(256), id) + ', ''' 
+ name + ''',''' + CONVERT(VARCHAR(256),GETDATE()) 
+ ''', 0, NULL,''' + label + ''',' +  CONVERT(VARCHAR(256), type) 
+ ',N''' + ISNULL(arabicname,'') + ''',N''' + ISNULL(arabiccode,'') + ''',''' 
+ ISNULL(code,'') + ''',' 
+ CONVERT(VARCHAR(256), ISNULL(operatorid,0)) 
+ ',' + CONVERT(VARCHAR(256),BILLABLE) 
+ ')'

AS InsertSQL

from bedtype

-- select * from bedtype 