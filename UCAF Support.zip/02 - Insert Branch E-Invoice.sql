/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Id]
      ,[Code]
      ,[Description]
      ,[CreatedAt]
      ,[Deleted]
      ,[ModifiedAt]
  FROM [HIS].[RCMONP].[Branches]


SET IDENTITY_INSERT RCMONP.Branches ON;

INSERT INTO RCMONP.Branches (Id, Code, Description, CreatedAt, Deleted, ModifiedAt)
VALUES (9, 'ASR', 'SGH Aseer', '2022-02-24 13:00:12.0300000', 0, NULL)


INSERT INTO RCMONP.Branches (Id, Code, Description, CreatedAt, Deleted, ModifiedAt)
VALUES (10, 'DAM', 'SGH Dammam', '2022-02-24 13:00:34.3733333', 0, NULL)

SET IDENTITY_INSERT RCMONP.Branches OFF;

